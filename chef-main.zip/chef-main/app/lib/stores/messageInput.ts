import { atom } from 'nanostores';

export const messageInputStore = atom('');
