import { atom } from 'nanostores';

export const description = atom<string | undefined>(undefined);
