import rulesContent from './convex_rules.mdc?raw';

export const cursorRulesContent = rulesContent;
