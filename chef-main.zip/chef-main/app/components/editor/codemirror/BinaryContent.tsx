export function BinaryContent() {
  return (
    <div className="absolute inset-0 z-10 flex items-center justify-center bg-bolt-elements-background-depth-1 text-sm text-content-primary">
      File format cannot be displayed.
    </div>
  );
}
