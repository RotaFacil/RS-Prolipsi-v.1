export default {
  plugins: {
    'postcss-nesting': {},
    'postcss-mixins': {},
    'tailwindcss/nesting': {},
    tailwindcss: {},
    autoprefixer: {},
  },
};
