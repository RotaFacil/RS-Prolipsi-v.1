import { Order } from '../types';

export const initialOrders: Order[] = [];
