
export const initialDownloads = {
  marketingPlanPages: [
    'https://picsum.photos/seed/plan1/827/1169',
    'https://picsum.photos/seed/plan2/827/1169',
    'https://picsum.photos/seed/plan3/827/1169',
  ],
  productCatalogPages: [
    'https://picsum.photos/seed/cat1/827/1169',
    'https://picsum.photos/seed/cat2/827/1169',
    'https://picsum.photos/seed/cat3/827/1169',
    'https://picsum.photos/seed/cat4/827/1169',
  ],
};
