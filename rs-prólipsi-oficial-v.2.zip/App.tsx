
import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

// Layouts
import ConsultantLayout, { UserContext, DashboardConfigContext } from './consultant/ConsultantLayout';
import AdminLayout from './admin/AdminLayout';
import GlobalAdminLayout from './admin/GlobalAdminLayout';
import ShopLayout from './consultant/shop/ShopLayout';
import MarketplaceLayout from './consultant/marketplace/MarketplaceLayout';
import { LayoutProvider } from './context/LayoutContext';

// Pages - Auth
import Login from './auth/Login';
import Register from './auth/Register';
import AdminLogin from './auth/AdminLogin';

// Pages - Consultant Main
import Dashboard from './consultant/Dashboard';
import RsShop from './consultant/RsShop'; // Studio
import Comunicacao from './consultant/Comunicacao';
import Relatorios from './consultant/Relatorios';
import Configuracoes from './consultant/Configuracoes';

// Pages - Wallet
import WalletLayout from './consultant/wallet/WalletLayout';
import SaldoExtrato from './consultant/wallet/SaldoExtrato';
import Cobrancas from './consultant/wallet/Cobrancas';
import Assinaturas from './consultant/wallet/Assinaturas';
import Transferir from './consultant/wallet/Transferir';
import Saque from './consultant/wallet/Saque';
import RelatoriosFinanceiros from './consultant/wallet/RelatoriosFinanceiros';
import ConfiguracoesFinanceiras from './consultant/wallet/ConfiguracoesFinanceiras';

// Pages - Shop (Buyer/Affiliate)
import MarketplaceBuyer from './consultant/shop/Marketplace';
import CentroDistribuicao from './consultant/shop/CentroDistribuicao';
import Dropshipping from './consultant/shop/Dropshipping';
import LinksAfiliado from './consultant/shop/LinksAfiliado';
import PixelsMarketing from './consultant/shop/PixelsMarketing';
import EncurtadorLink from './consultant/shop/EncurtadorLink';
import MeusDados from './consultant/shop/MeusDados';
import MeusPedidos from './consultant/shop/MeusPedidos';
import StoreBuilder from './consultant/shop/StoreBuilder';
import StoreFront from './consultant/shop/StoreFront';
import VitrineHome from './consultant/shop/VitrineHome';
import StoreSetupWizard from './consultant/shop/StoreSetupWizard';

// Pages - Marketplace (Seller)
import MarketplaceDashboard from './consultant/marketplace/Dashboard';
import MarketplaceProducts from './consultant/marketplace/Products';
import ProductEditor from './consultant/marketplace/ProductEditor';
import MarketplaceOrders from './consultant/marketplace/Orders';
import MarketplaceFinanceiro from './consultant/marketplace/Financeiro';
import MarketplaceRelatorios from './consultant/marketplace/Relatorios';
import MarketplaceConfiguracoes from './consultant/marketplace/Configuracoes';
import MarketplaceVisualLoja from './consultant/marketplace/VisualLoja';

// Pages - SIGME
import CicloGlobal from './consultant/sigme/CicloGlobal';
import BonusProfundidade from './consultant/sigme/BonusProfundidade';
import BonusFidelidade from './consultant/sigme/BonusFidelidade';
import PlanoCarreira from './consultant/sigme/PlanoCarreira';
import TopSigme from './consultant/sigme/TopSigme';
import MatrizSigma, { ArvoreInterativaPage } from './consultant/sigme/MatrizSigma';

// Pages - Admin
import AdminDashboard from './admin/pages/AdminDashboard';
import ConsultantsList from './admin/pages/ConsultantsList';
import FinancialClosing from './admin/pages/FinancialClosing';
// ... sigma configs ...
import MatrixConfig from './admin/pages/sigma/MatrixConfig';
import DepthBonusConfig from './admin/pages/sigma/DepthBonusConfig';
import TopSigmaConfig from './admin/pages/sigma/TopSigmaConfig';
import FidelityBonusConfig from './admin/pages/sigma/FidelityBonusConfig';
import CareerPlanConfig from './admin/pages/sigma/CareerPlanConfig';
import MarketplaceConfig from './admin/pages/tools/MarketplaceConfig';
import DashboardEditor from './admin/DashboardEditor';
import AdminPersonalData from './admin/PersonalData';

import { mockUser, mockDashboardConfig, mockSystemMessages } from './consultant/data';
import { User, SystemMessage, DashboardConfig } from './types';
import { SystemSettingsProvider } from './context/SystemSettingsContext';

const App: React.FC = () => {
    const [user, setUser] = useState<User>(mockUser);
    const [messages, setMessages] = useState<SystemMessage[]>(mockSystemMessages);
    const [credits, setCredits] = useState(10);
    const [isAuthenticated, setIsAuthenticated] = useState(true);
    const [dashboardConfig, setDashboardConfig] = useState<DashboardConfig>(mockDashboardConfig);

    const updateUser = (data: Partial<User>) => setUser(prev => ({ ...prev, ...data }));
    const markMessageAsRead = (id: string) => setMessages(prev => prev.map(m => m.id === id ? { ...m, read: true } : m));
    const login = async (email: string, pass: string) => { setIsAuthenticated(true); return { error: null }; };
    const logout = async () => { setIsAuthenticated(false); };

    return (
        <LayoutProvider>
            <UserContext.Provider value={{ user, updateUser, messages, markMessageAsRead, credits, setCredits, isAuthenticated, login, logout, isLoading: false }}>
                <DashboardConfigContext.Provider value={{ config: dashboardConfig, setConfig: setDashboardConfig }}>
                    <SystemSettingsProvider>
                        <Routes>
                            {/* ROTA DA LOJA RAIZ - FORA DE QUALQUER LAYOUT ADMINISTRATIVO */}
                            <Route path="/store/:storeSlug" element={<StoreFront />} />
                            
                            <Route path="/" element={<Login />} />
                            <Route path="/login" element={<Login />} />
                            <Route path="/register" element={<Register />} />
                            <Route path="/admin-login" element={<AdminLogin />} />

                            <Route path="consultant" element={<ConsultantLayout />}>
                                <Route index element={<Navigate to="dashboard" replace />} />
                                <Route path="dashboard" element={<Dashboard />} />
                                <Route path="studio" element={<RsShop />} />
                                <Route path="comunicacao" element={<Comunicacao />} />
                                <Route path="relatorios" element={<Relatorios />} />
                                <Route path="configuracoes" element={<Configuracoes />} />

                                <Route path="wallet" element={<WalletLayout />}>
                                    <Route index element={<Navigate to="saldo-extrato" replace />} />
                                    <Route path="saldo-extrato" element={<SaldoExtrato />} />
                                    <Route path="cobrancas" element={<Cobrancas />} />
                                    <Route path="assinaturas" element={<Assinaturas />} />
                                    <Route path="transferir" element={<Transferir />} />
                                    <Route path="saque" element={<Saque />} />
                                    <Route path="relatorios" element={<RelatoriosFinanceiros />} />
                                    <Route path="configuracoes" element={<ConfiguracoesFinanceiras />} />
                                </Route>

                                <Route path="shop" element={<ShopLayout />}>
                                    <Route index element={<Navigate to="marketplace" replace />} />
                                    <Route path="marketplace" element={<MarketplaceBuyer />} />
                                    <Route path="vitrine" element={<VitrineHome />} />
                                    <Route path="setup" element={<StoreSetupWizard />} />
                                    <Route path="centro-distribuicao" element={<CentroDistribuicao />} />
                                    <Route path="dropshipping" element={<Dropshipping />} />
                                    <Route path="links-afiliado" element={<LinksAfiliado />} />
                                    <Route path="pixels" element={<PixelsMarketing />} />
                                    <Route path="encurtador" element={<EncurtadorLink />} />
                                    <Route path="store-builder" element={<StoreBuilder />} />
                                    <Route path="meus-pedidos" element={<MeusPedidos />} />
                                    <Route path="meus-dados" element={<MeusDados />} />
                                </Route>

                                <Route path="sigme">
                                    <Route path="ciclo-global" element={<CicloGlobal />} />
                                    <Route path="bonus-profundidade" element={<BonusProfundidade />} />
                                    <Route path="bonus-fidelidade" element={<BonusFidelidade />} />
                                    <Route path="plano-carreira" element={<PlanoCarreira />} />
                                    <Route path="top-sigme" element={<TopSigme />} />
                                    <Route path="arvore-interativa/:type" element={<ArvoreInterativaPage />} />
                                    <Route path="relatorios-rede" element={<Relatorios />} />
                                </Route>
                            </Route>

                            <Route path="marketplace" element={<MarketplaceLayout />}>
                                <Route index element={<MarketplaceDashboard />} />
                                <Route path="produtos" element={<MarketplaceProducts />} />
                                <Route path="produtos/new" element={<ProductEditor />} />
                                <Route path="produtos/edit/:id" element={<ProductEditor />} />
                                <Route path="pedidos" element={<MarketplaceOrders />} />
                                <Route path="financeiro" element={<MarketplaceFinanceiro />} />
                                <Route path="relatorios" element={<MarketplaceRelatorios />} />
                                <Route path="configuracoes" element={<MarketplaceConfiguracoes />} />
                                <Route path="loja-visual" element={<MarketplaceVisualLoja />} />
                                <Route path="marketing" element={<LinksAfiliado />} />
                            </Route>

                            <Route path="global-admin" element={<GlobalAdminLayout />}>
                                <Route index element={<Navigate to="dashboard" replace />} />
                                <Route path="dashboard" element={<AdminDashboard />} />
                                <Route path="consultants" element={<ConsultantsList />} />
                                <Route path="financial-closing" element={<FinancialClosing />} />
                                
                                <Route path="sigma/matrix" element={<MatrixConfig />} />
                                <Route path="sigma/depth" element={<DepthBonusConfig />} />
                                <Route path="sigma/top" element={<TopSigmaConfig />} />
                                <Route path="sigma/fidelity" element={<FidelityBonusConfig />} />
                                <Route path="sigma/career" element={<CareerPlanConfig />} />
                                
                                <Route path="tools/marketplace" element={<MarketplaceConfig />} />
                                <Route path="tools/dashboard-editor" element={<DashboardEditor />} />
                                <Route path="personal-data" element={<AdminPersonalData />} />
                            </Route>

                            <Route path="admin" element={<AdminLayout />}>
                                <Route path="personal-data" element={<AdminPersonalData />} />
                                <Route path="dashboard-editor" element={<DashboardEditor />} />
                            </Route>
                        </Routes>
                    </SystemSettingsProvider>
                </DashboardConfigContext.Provider>
            </UserContext.Provider>
        </LayoutProvider>
    );
};

export default App;
