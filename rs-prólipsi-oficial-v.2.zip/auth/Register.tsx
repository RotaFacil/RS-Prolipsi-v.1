
import React, { useState, FormEvent } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { IconLock, IconUser, IconWhatsapp, IconGitFork } from '../components/icons';

const Register: React.FC = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [whatsapp, setWhatsapp] = useState('');
    const [sponsorId, setSponsorId] = useState(''); // Novo campo para o Patrocinador
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const navigate = useNavigate();

    const handleSubmit = async (e: FormEvent) => {
        e.preventDefault();
        setError('');

        if (password !== confirmPassword) {
            setError('As senhas não coincidem.');
            return;
        }

        if (password.length < 6) {
            setError('A senha deve ter pelo menos 6 caracteres.');
            return;
        }

        if (!sponsorId.trim()) {
            setError('O ID do Patrocinador é obrigatório para entrar na rede.');
            return;
        }

        setIsLoading(true);

        try {
            // 1. Criar usuário na Autenticação do Supabase
            const { data: authData, error: authError } = await supabase.auth.signUp({
                email,
                password,
                options: {
                    data: {
                        name: name,
                        whatsapp: whatsapp
                    }
                }
            });

            if (authError) throw authError;

            if (authData.user) {
                // Gerar um username a partir do email (ex: joao.silva de joao.silva@email.com)
                const generatedUsername = email.split('@')[0].toLowerCase().replace(/[^a-z0-9]/g, '');

                // 2. Criar registro na tabela 'consultores'
                const { error: profileError } = await supabase
                    .from('consultores')
                    .insert([
                        { 
                            id: authData.user.id, // O ID de autenticação
                            name, 
                            email,
                            username: generatedUsername,
                            whatsapp,
                            sponsor_id: sponsorId, // Vincula ao pai na rede
                            pin: 'Iniciante',
                            avatar_url: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=FFD700&color=121212`,
                            status: 'active',
                            created_at: new Date().toISOString()
                        }
                    ]);

                if (profileError) {
                    console.error("Erro ao criar perfil em 'consultores':", profileError);
                    throw new Error("Erro ao salvar dados do consultor: " + profileError.message);
                }

                alert('Cadastro realizado com sucesso! Bem-vindo à RS Prólipsi.');
                navigate('/consultant/dashboard');
            }
        } catch (err: any) {
            console.error("Erro no cadastro:", err);
            setError(err.message || 'Erro ao realizar cadastro. Tente novamente.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-brand-dark flex items-center justify-center p-4 font-sans">
            <div className="w-full max-w-md">
                <div className="text-center mb-8">
                    <h1 className="text-5xl font-extrabold text-brand-gold" style={{ textShadow: '0 0 15px rgba(255, 215, 0, 0.3)' }}>RS Prólipsi</h1>
                    <p className="text-brand-text-dim mt-2">Escritório do Consultor</p>
                </div>
                <div className="bg-brand-gray p-8 rounded-2xl shadow-lg shadow-black/30 border border-brand-gray-light">
                    <h2 className="text-2xl font-bold text-center text-white mb-6">Crie sua conta</h2>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <label className="text-sm font-medium text-brand-text-dim mb-1 block">Nome Completo</label>
                            <div className="relative">
                                <IconUser className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-text-dim" size={20} />
                                <input 
                                    type="text" 
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    className="w-full bg-brand-dark text-white p-3 pl-10 rounded-lg border border-brand-gray-light focus:outline-none focus:ring-2 focus:ring-brand-gold transition-all"
                                    placeholder="Seu nome"
                                    required
                                />
                            </div>
                        </div>
                        <div>
                            <label className="text-sm font-medium text-brand-text-dim mb-1 block">E-mail</label>
                            <div className="relative">
                                <IconUser className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-text-dim" size={20} />
                                <input 
                                    type="email" 
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    className="w-full bg-brand-dark text-white p-3 pl-10 rounded-lg border border-brand-gray-light focus:outline-none focus:ring-2 focus:ring-brand-gold transition-all"
                                    placeholder="seuemail@exemplo.com"
                                    required
                                />
                            </div>
                        </div>
                        
                        {/* Campo Novo: Patrocinador */}
                        <div>
                            <label className="text-sm font-medium text-brand-gold mb-1 block">ID do Patrocinador (Quem indicou)</label>
                            <div className="relative">
                                <IconGitFork className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-gold" size={20} />
                                <input 
                                    type="text" 
                                    value={sponsorId}
                                    onChange={(e) => setSponsorId(e.target.value)}
                                    className="w-full bg-brand-dark text-white p-3 pl-10 rounded-lg border border-brand-gold/50 focus:outline-none focus:ring-2 focus:ring-brand-gold transition-all placeholder-gray-600"
                                    placeholder="ID ou Username do Líder"
                                    required
                                />
                            </div>
                        </div>

                        <div>
                            <label className="text-sm font-medium text-brand-text-dim mb-1 block">WhatsApp</label>
                            <div className="relative">
                                <IconWhatsapp className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-text-dim" size={20} />
                                <input 
                                    type="tel" 
                                    value={whatsapp}
                                    onChange={(e) => setWhatsapp(e.target.value)}
                                    className="w-full bg-brand-dark text-white p-3 pl-10 rounded-lg border border-brand-gray-light focus:outline-none focus:ring-2 focus:ring-brand-gold transition-all"
                                    placeholder="(99) 99999-9999"
                                    required
                                />
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-sm font-medium text-brand-text-dim mb-1 block">Senha</label>
                                <div className="relative">
                                    <IconLock className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-text-dim" size={20} />
                                    <input 
                                        type="password"
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        className="w-full bg-brand-dark text-white p-3 pl-10 rounded-lg border border-brand-gray-light focus:outline-none focus:ring-2 focus:ring-brand-gold transition-all"
                                        placeholder="Min 6 chars"
                                        required
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="text-sm font-medium text-brand-text-dim mb-1 block">Confirmar</label>
                                <div className="relative">
                                    <IconLock className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-text-dim" size={20} />
                                    <input 
                                        type="password"
                                        value={confirmPassword}
                                        onChange={(e) => setConfirmPassword(e.target.value)}
                                        className="w-full bg-brand-dark text-white p-3 pl-10 rounded-lg border border-brand-gray-light focus:outline-none focus:ring-2 focus:ring-brand-gold transition-all"
                                        placeholder="Confirme"
                                        required
                                    />
                                </div>
                            </div>
                        </div>

                        {error && <p className="text-sm text-red-400 text-center animate-shake">{error}</p>}
                        
                        <button 
                            type="submit" 
                            disabled={isLoading}
                            className="w-full bg-brand-gold text-brand-dark font-bold py-3 rounded-lg hover:bg-yellow-400 transition-all duration-300 shadow-lg shadow-brand-gold/20 transform hover:scale-105 disabled:bg-brand-gray disabled:cursor-not-allowed disabled:scale-100 flex items-center justify-center mt-6"
                        >
                            {isLoading ? (
                                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-brand-dark"></div>
                            ) : (
                                "Finalizar Cadastro"
                            )}
                        </button>
                    </form>
                </div>
                <div className="text-center text-sm text-brand-text-dim mt-8">
                    Já tem uma conta? <Link to="/login" className="font-semibold text-brand-gold hover:underline">Entre</Link>
                </div>
            </div>
             <style>{`
                @keyframes shake {
                    0%, 100% { transform: translateX(0); }
                    10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
                    20%, 40%, 60%, 80% { transform: translateX(5px); }
                }
                .animate-shake {
                    animation: shake 0.5s ease-in-out;
                }
            `}</style>
        </div>
    );
};

export default Register;
