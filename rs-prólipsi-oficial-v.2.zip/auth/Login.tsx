
import React, { useState, FormEvent } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useUser } from '../consultant/ConsultantLayout';
import { IconLock, IconUser, IconEye, IconEyeOff } from '../components/icons';

const Login: React.FC = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isRecovering, setIsRecovering] = useState(false);
    
    const { login } = useUser();
    const navigate = useNavigate();
    const location = useLocation();

    const from = location.state?.from?.pathname || '/consultant/dashboard';

    const handleSubmit = async (e: FormEvent) => {
        e.preventDefault();
        setError('');
        setIsLoading(true);

        try {
            const { error } = await login(email, password);
            if (error) {
                console.error("Login failed:", error);
                setError('E-mail ou senha inválidos. Tente novamente.');
                setIsLoading(false);
            } else {
                navigate(from, { replace: true });
            }
        } catch (err) {
            console.error("Unexpected error:", err);
            setError('Ocorreu um erro inesperado.');
            setIsLoading(false);
        }
    };

    const handleForgotPassword = (e: FormEvent) => {
        e.preventDefault();
        if (!email) {
            setError('Por favor, digite seu e-mail para recuperar a senha.');
            return;
        }
        setIsLoading(true);
        // Simulate API call
        setTimeout(() => {
            setIsLoading(false);
            setIsRecovering(false);
            alert(`Um e-mail de recuperação foi enviado para ${email}. Verifique sua caixa de entrada.`);
        }, 1500);
    };

    return (
        <div className="min-h-screen bg-brand-dark flex items-center justify-center p-4 font-sans">
            <div className="w-full max-w-md">
                <div className="text-center mb-8">
                    <h1 className="text-5xl font-extrabold text-brand-gold" style={{ textShadow: '0 0 15px rgba(255, 215, 0, 0.3)' }}>RS Prólipsi</h1>
                    <p className="text-brand-text-dim mt-2">Escritório do Consultor</p>
                </div>
                
                <div className="bg-brand-gray p-8 rounded-2xl shadow-lg shadow-black/30 border border-brand-gray-light">
                    {!isRecovering ? (
                        <>
                            <h2 className="text-2xl font-bold text-center text-white mb-6">Acesse sua conta</h2>
                            <form onSubmit={handleSubmit} className="space-y-6">
                                <div>
                                    <label className="text-sm font-medium text-brand-text-dim mb-2 block">E-mail</label>
                                    <div className="relative">
                                        <IconUser className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-text-dim" size={20} />
                                        <input 
                                            type="email" 
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            className="w-full bg-brand-dark text-white p-3 pl-10 rounded-lg border border-brand-gray-light focus:outline-none focus:ring-2 focus:ring-brand-gold transition-all"
                                            placeholder="seuemail@exemplo.com"
                                            required
                                            autoComplete="email"
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label className="text-sm font-medium text-brand-text-dim mb-2 block">Senha</label>
                                    <div className="relative">
                                        <IconLock className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-text-dim" size={20} />
                                        <input 
                                            type={showPassword ? "text" : "password"}
                                            value={password}
                                            onChange={(e) => setPassword(e.target.value)}
                                            className="w-full bg-brand-dark text-white p-3 pl-10 pr-10 rounded-lg border border-brand-gray-light focus:outline-none focus:ring-2 focus:ring-brand-gold transition-all"
                                            placeholder="Sua senha"
                                            required
                                            autoComplete="current-password"
                                        />
                                        <button 
                                            type="button" 
                                            onClick={() => setShowPassword(!showPassword)}
                                            className="absolute right-3 top-1/2 -translate-y-1/2 text-brand-text-dim hover:text-white transition-colors"
                                        >
                                            {showPassword ? <IconEyeOff size={20} /> : <IconEye size={20} />}
                                        </button>
                                    </div>
                                </div>
                                {error && <p className="text-sm text-red-400 text-center animate-shake">{error}</p>}
                                <button 
                                    type="submit" 
                                    disabled={isLoading}
                                    className="w-full bg-brand-gold text-brand-dark font-bold py-3 rounded-lg hover:bg-yellow-400 transition-all duration-300 shadow-lg shadow-brand-gold/20 transform hover:scale-105 disabled:bg-brand-gray disabled:cursor-not-allowed disabled:scale-100 flex items-center justify-center"
                                >
                                    {isLoading ? (
                                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-brand-dark"></div>
                                    ) : (
                                        "Entrar"
                                    )}
                                </button>
                            </form>
                            <div className="text-center text-sm text-brand-text-dim mt-6">
                                <button onClick={() => { setIsRecovering(true); setError(''); }} className="hover:text-brand-gold bg-transparent border-none cursor-pointer underline">
                                    Esqueceu sua senha?
                                </button>
                            </div>
                            
                            {/* ACESSO RÁPIDO PARA DESENVOLVIMENTO */}
                            <div className="mt-6 p-3 bg-brand-dark/50 rounded-lg border border-brand-gray-light/50 text-xs text-gray-400 transition-all hover:border-brand-gold/50 cursor-pointer" onClick={() => { setEmail('rsprolipsioficial@gmail.com'); setPassword('Yannis784512@'); }}>
                                <p className="font-bold text-brand-gold mb-1 uppercase tracking-wider text-[10px]">Acesso Rápido (Clique para preencher)</p>
                                <div className="flex flex-col gap-1">
                                    <div className="flex justify-between"><span>E-mail:</span> <span className="font-mono text-white">rsprolipsioficial@gmail.com</span></div>
                                    <div className="flex justify-between"><span>Senha:</span> <span className="font-mono text-white">Yannis784512@</span></div>
                                </div>
                            </div>
                        </>
                    ) : (
                        // RECOVERY MODE
                        <>
                            <h2 className="text-2xl font-bold text-center text-white mb-4">Recuperar Senha</h2>
                            <p className="text-sm text-gray-400 text-center mb-6">Digite seu e-mail abaixo para receber as instruções de redefinição de senha.</p>
                            <form onSubmit={handleForgotPassword} className="space-y-6">
                                <div>
                                    <label className="text-sm font-medium text-brand-text-dim mb-2 block">E-mail Cadastrado</label>
                                    <div className="relative">
                                        <IconUser className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-text-dim" size={20} />
                                        <input 
                                            type="email" 
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            className="w-full bg-brand-dark text-white p-3 pl-10 rounded-lg border border-brand-gray-light focus:outline-none focus:ring-2 focus:ring-brand-gold transition-all"
                                            placeholder="seuemail@exemplo.com"
                                            required
                                        />
                                    </div>
                                </div>
                                {error && <p className="text-sm text-red-400 text-center animate-shake">{error}</p>}
                                <button 
                                    type="submit" 
                                    disabled={isLoading}
                                    className="w-full bg-brand-gold text-brand-dark font-bold py-3 rounded-lg hover:bg-yellow-400 transition-all duration-300 shadow-lg shadow-brand-gold/20 flex items-center justify-center"
                                >
                                    {isLoading ? (
                                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-brand-dark"></div>
                                    ) : (
                                        "Enviar E-mail de Recuperação"
                                    )}
                                </button>
                            </form>
                            <div className="text-center text-sm text-brand-text-dim mt-6">
                                <button onClick={() => { setIsRecovering(false); setError(''); }} className="hover:text-white bg-transparent border-none cursor-pointer">
                                    Voltar para o Login
                                </button>
                            </div>
                        </>
                    )}
                </div>
                {!isRecovering && (
                    <div className="text-center text-sm text-brand-text-dim mt-8">
                        Não tem uma conta? <Link to="/register" className="font-semibold text-brand-gold hover:underline">Cadastre-se</Link>
                    </div>
                )}
            </div>
             <style>{`
                @keyframes shake {
                    0%, 100% { transform: translateX(0); }
                    10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
                    20%, 40%, 60%, 80% { transform: translateX(5px); }
                }
                .animate-shake {
                    animation: shake 0.5s ease-in-out;
                }
            `}</style>
        </div>
    );
};

export default Login;
