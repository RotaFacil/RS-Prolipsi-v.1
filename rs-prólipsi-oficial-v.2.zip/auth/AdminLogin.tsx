
import React, { useState, FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../consultant/ConsultantLayout';
import { IconLock, IconShield } from '../components/icons';

const AdminLogin: React.FC = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const { login } = useUser();
    const navigate = useNavigate();

    const handleSubmit = async (e: FormEvent) => {
        e.preventDefault();
        setError('');
        setIsLoading(true);

        try {
            const { error } = await login(email, password);
            if (error) {
                console.error("Login failed:", error);
                setError('Credenciais administrativas inválidas.');
                setIsLoading(false);
            } else {
                // Here you would check specifically for admin role: if (user.role === 'super_admin')
                navigate('/global-admin');
            }
        } catch (err) {
            console.error("Unexpected error:", err);
            setError('Ocorreu um erro de conexão.');
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-black flex items-center justify-center p-4 font-sans relative overflow-hidden">
            {/* Background Effect */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-gray-800 via-black to-black opacity-50"></div>
            
            <div className="w-full max-w-md z-10">
                <div className="text-center mb-8">
                    <IconShield size={64} className="mx-auto text-brand-gold mb-4" />
                    <h1 className="text-4xl font-extrabold text-white tracking-wider">ACESSO GLOBAL</h1>
                    <p className="text-gray-500 mt-2 text-sm uppercase tracking-widest">Painel Administrativo Mestre</p>
                </div>
                
                <div className="bg-gray-900/80 backdrop-blur-md p-8 rounded-2xl border border-gray-800 shadow-2xl">
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div>
                            <label className="text-xs font-bold text-gray-500 mb-2 block uppercase">ID Administrativo / E-mail</label>
                            <input 
                                type="email" 
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="w-full bg-black text-white p-4 rounded-lg border border-gray-700 focus:outline-none focus:border-brand-gold transition-colors"
                                placeholder="admin@rsprolipsi.com"
                                required
                            />
                        </div>
                         <div>
                            <label className="text-xs font-bold text-gray-500 mb-2 block uppercase">Chave de Acesso</label>
                            <div className="relative">
                                <input 
                                    type="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    className="w-full bg-black text-white p-4 pl-12 rounded-lg border border-gray-700 focus:outline-none focus:border-brand-gold transition-colors"
                                    placeholder="••••••••••••"
                                    required
                                />
                                <IconLock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={20} />
                            </div>
                        </div>
                        {error && <p className="text-sm text-red-500 text-center font-semibold">{error}</p>}
                        
                        <button 
                            type="submit" 
                            disabled={isLoading}
                            className="w-full bg-brand-gold text-black font-extrabold py-4 rounded-lg hover:bg-white transition-all duration-300 transform hover:scale-[1.02] shadow-lg shadow-brand-gold/20 flex items-center justify-center uppercase tracking-wider"
                        >
                            {isLoading ? (
                                <span className="animate-pulse">Autenticando...</span>
                            ) : (
                                "Acessar Sistema"
                            )}
                        </button>
                    </form>
                    
                    {/* ACESSO RÁPIDO PARA DESENVOLVIMENTO */}
                    <div className="mt-6 p-3 bg-black/50 rounded-lg border border-gray-700/50 text-xs text-gray-400 transition-all hover:border-brand-gold/50 cursor-pointer" onClick={() => { setEmail('rsprolipsioficial@gmail.com'); setPassword('Yannis784512@'); }}>
                        <p className="font-bold text-brand-gold mb-1 uppercase tracking-wider text-[10px]">Acesso Rápido (Clique para preencher)</p>
                        <div className="flex flex-col gap-1">
                            <div className="flex justify-between"><span>E-mail:</span> <span className="font-mono text-white">rsprolipsioficial@gmail.com</span></div>
                            <div className="flex justify-between"><span>Senha:</span> <span className="font-mono text-white">Yannis784512@</span></div>
                        </div>
                    </div>
                </div>
                <p className="text-center text-gray-600 text-xs mt-8">Acesso restrito. Todas as ações são monitoradas e logadas.</p>
            </div>
        </div>
    );
};

export default AdminLogin;
