
import React, { useState, useEffect } from 'react';
import Card from '../components/Card';
import { useSystemSettings } from '../context/SystemSettingsContext';
import { IconSave, IconPlus, IconTrash, IconEdit, IconAward } from '../components/icons';
import type { CareerPinRule } from '../types';

const MarketingPlanEditor: React.FC = () => {
    const { settings, updateSettings, isLoading } = useSystemSettings();
    const [pins, setPins] = useState<CareerPinRule[]>([]);
    const [isDirty, setIsDirty] = useState(false);

    useEffect(() => {
        if (settings.careerPlan?.pins) {
            setPins(settings.careerPlan.pins);
        }
    }, [settings]);

    const handlePinChange = (index: number, field: keyof CareerPinRule, value: string | number) => {
        const newPins = [...pins];
        // @ts-ignore
        newPins[index][field] = value;
        setPins(newPins);
        setIsDirty(true);
    };

    const addPin = () => {
        const newPin: CareerPinRule = {
            pin: 'Novo Nível',
            cycles: 1000,
            minLines: 2,
            vmec: '50/50',
            bonus: 0,
            iconColor: '#ffffff'
        };
        setPins([...pins, newPin]);
        setIsDirty(true);
    };

    const removePin = (index: number) => {
        const newPins = pins.filter((_, i) => i !== index);
        setPins(newPins);
        setIsDirty(true);
    };

    const handleSave = async () => {
        await updateSettings({
            careerPlan: {
                ...settings.careerPlan,
                pins: pins
            }
        });
        setIsDirty(false);
        alert('Plano de Marketing atualizado com sucesso! As alterações já estão valendo para todos os consultores.');
    };

    if (isLoading) return <div className="text-white text-center mt-20">Carregando configurações do sistema...</div>;

    return (
        <div className="space-y-8 pb-20">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-white">Editor do Plano de Marketing</h1>
                    <p className="text-gray-400 mt-2">
                        Ajuste as regras de qualificação e bônus. <span className="text-brand-gold font-bold">Cuidado:</span> Alterações aqui afetam o cálculo de todos os consultores imediatamente.
                    </p>
                </div>
                <button 
                    onClick={handleSave} 
                    disabled={!isDirty}
                    className={`flex items-center gap-2 px-6 py-3 rounded-lg font-bold transition-all ${isDirty ? 'bg-brand-gold text-black hover:bg-white shadow-lg shadow-brand-gold/30' : 'bg-gray-700 text-gray-400 cursor-not-allowed'}`}
                >
                    <IconSave />
                    Salvar Alterações Globais
                </button>
            </div>

            <div className="grid grid-cols-1 gap-6">
                {pins.map((pin, index) => (
                    <Card key={index} className="bg-gray-800 border border-gray-700 relative group">
                        <div className="absolute -left-3 top-6 bg-gray-900 border border-gray-700 rounded-full w-8 h-8 flex items-center justify-center font-bold text-gray-500">
                            {index + 1}
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-6 gap-4 items-end">
                            <div className="md:col-span-1">
                                <label className="text-xs text-gray-500 uppercase font-bold block mb-1">Nome do PIN</label>
                                <div className="flex items-center bg-gray-900 rounded-lg border border-gray-700 p-2">
                                    <IconAward style={{ color: pin.iconColor }} className="mr-2" size={20} />
                                    <input 
                                        type="text" 
                                        value={pin.pin} 
                                        onChange={(e) => handlePinChange(index, 'pin', e.target.value)}
                                        className="bg-transparent text-white w-full focus:outline-none font-bold"
                                    />
                                </div>
                            </div>

                            <div className="md:col-span-1">
                                <label className="text-xs text-gray-500 uppercase font-bold block mb-1">Ciclos Necessários</label>
                                <input 
                                    type="number" 
                                    value={pin.cycles} 
                                    onChange={(e) => handlePinChange(index, 'cycles', Number(e.target.value))}
                                    className="bg-gray-900 text-white w-full p-2 rounded-lg border border-gray-700 focus:border-brand-gold focus:outline-none"
                                />
                            </div>

                            <div className="md:col-span-1">
                                <label className="text-xs text-gray-500 uppercase font-bold block mb-1">Linhas Mínimas</label>
                                <input 
                                    type="number" 
                                    value={pin.minLines} 
                                    onChange={(e) => handlePinChange(index, 'minLines', Number(e.target.value))}
                                    className="bg-gray-900 text-white w-full p-2 rounded-lg border border-gray-700 focus:border-brand-gold focus:outline-none"
                                />
                            </div>

                            <div className="md:col-span-1">
                                <label className="text-xs text-gray-500 uppercase font-bold block mb-1">Regra VMEc</label>
                                <input 
                                    type="text" 
                                    value={pin.vmec} 
                                    onChange={(e) => handlePinChange(index, 'vmec', e.target.value)}
                                    className="bg-gray-900 text-white w-full p-2 rounded-lg border border-gray-700 focus:border-brand-gold focus:outline-none"
                                />
                            </div>

                            <div className="md:col-span-1">
                                <label className="text-xs text-gray-500 uppercase font-bold block mb-1">Bônus (R$)</label>
                                <input 
                                    type="number" 
                                    value={pin.bonus} 
                                    onChange={(e) => handlePinChange(index, 'bonus', Number(e.target.value))}
                                    className="bg-gray-900 text-green-400 font-mono w-full p-2 rounded-lg border border-gray-700 focus:border-brand-gold focus:outline-none"
                                />
                            </div>

                            <div className="md:col-span-1 flex justify-end">
                                <div className="flex items-center gap-2">
                                    <input 
                                        type="color" 
                                        value={pin.iconColor} 
                                        onChange={(e) => handlePinChange(index, 'iconColor', e.target.value)}
                                        className="h-10 w-10 bg-transparent cursor-pointer rounded overflow-hidden border-none"
                                        title="Cor do Ícone"
                                    />
                                    <button onClick={() => removePin(index)} className="bg-red-900/30 text-red-500 p-2 rounded-lg hover:bg-red-500 hover:text-white transition-colors">
                                        <IconTrash size={20} />
                                    </button>
                                </div>
                            </div>
                        </div>
                    </Card>
                ))}
            </div>

            <button 
                onClick={addPin} 
                className="w-full py-4 border-2 border-dashed border-gray-700 rounded-xl text-gray-400 font-bold hover:border-brand-gold hover:text-brand-gold transition-colors flex items-center justify-center gap-2"
            >
                <IconPlus /> Adicionar Novo Nível de Carreira
            </button>
        </div>
    );
};

export default MarketingPlanEditor;
