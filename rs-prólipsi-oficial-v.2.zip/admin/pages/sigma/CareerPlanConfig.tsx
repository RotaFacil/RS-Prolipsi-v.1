
import React, { useState, useEffect } from 'react';
import Card from '../../../components/Card';
import { useSystemSettings } from '../../../context/SystemSettingsContext';
import { IconSave, IconPlus, IconTrash, IconEdit, IconAward, IconCheckCircle, IconUpload } from '../../../components/icons';
import type { CareerPinRule } from '../../../types';

const CareerPlanConfig: React.FC = () => {
    const { settings, updateSettings, isLoading } = useSystemSettings();
    const [config, setConfig] = useState(settings.careerPlan);
    const [isDirty, setIsDirty] = useState(false);

    useEffect(() => {
        if (settings.careerPlan) setConfig(settings.careerPlan);
    }, [settings]);

    const handleConfigChange = (field: keyof typeof config, value: any) => {
        setConfig(prev => ({ ...prev, [field]: value }));
        setIsDirty(true);
    };

    const handlePinChange = (index: number, field: keyof CareerPinRule, value: string | number) => {
        const newPins = [...config.pins];
        // @ts-ignore
        newPins[index][field] = value;
        setConfig(prev => ({ ...prev, pins: newPins }));
        setIsDirty(true);
    };

    const addPin = () => {
        const newPin: CareerPinRule = {
            pin: 'Novo Nível',
            cycles: 1000,
            minLines: 2,
            vmec: '50/50',
            bonus: 0,
            iconColor: '#ffffff'
        };
        setConfig(prev => ({ ...prev, pins: [...prev.pins, newPin] }));
        setIsDirty(true);
    };

    const removePin = (index: number) => {
        const newPins = config.pins.filter((_, i) => i !== index);
        setConfig(prev => ({ ...prev, pins: newPins }));
        setIsDirty(true);
    };

    const handleSave = async () => {
        await updateSettings({ careerPlan: config });
        setIsDirty(false);
        alert('Plano de Carreira atualizado com sucesso!');
    };

    if (isLoading) return <div>Carregando...</div>;

    return (
        <div className="space-y-8 pb-24">
            <h1 className="text-3xl font-bold text-brand-gold mb-2 flex items-center gap-2">
                <IconAward /> Plano de Carreira — {config.pins.length} PINs Oficiais
            </h1>

            {/* Regras Gerais */}
            <Card className="border-l-4 border-brand-gold">
                <h3 className="text-lg font-bold text-brand-gold mb-6 flex items-center gap-2"><IconEdit size={20}/> Regras Gerais do Plano de Carreira</h3>
                
                <div className="grid grid-cols-1 gap-6">
                    <div className="flex items-center justify-between border-b border-gray-700 pb-4">
                        <label className="text-gray-300 font-semibold w-1/3">Valor Base do Ciclo (Fator Bônus)</label>
                        <div className="flex items-center bg-brand-gray rounded-lg border border-gray-700 overflow-hidden w-full max-w-md">
                            <input 
                                type="number" 
                                value={config.cycleValue} 
                                onChange={e => handleConfigChange('cycleValue', parseFloat(e.target.value))}
                                className="w-full bg-transparent p-3 text-white text-right focus:outline-none"
                            />
                            <span className="px-3 text-gray-500 font-bold border-l border-gray-700 bg-gray-900 h-full flex items-center">R$</span>
                        </div>
                    </div>

                    <div className="flex items-center justify-between border-b border-gray-700 pb-4">
                        <label className="text-gray-300 font-semibold w-1/3">Percentual para Bônus de Carreira</label>
                        <div className="flex items-center bg-brand-gray rounded-lg border border-gray-700 overflow-hidden w-full max-w-md">
                            <input 
                                type="number" 
                                value={config.bonusPercentage} 
                                onChange={e => handleConfigChange('bonusPercentage', parseFloat(e.target.value))}
                                className="w-full bg-transparent p-3 text-white text-right focus:outline-none"
                            />
                            <span className="px-3 text-gray-500 font-bold border-l border-gray-700 bg-gray-900 h-full flex items-center">%</span>
                        </div>
                    </div>

                    <div className="flex items-center justify-between border-b border-gray-700 pb-4">
                        <label className="text-gray-300 font-semibold w-1/3">Valor Líquido por Ciclo</label>
                        <div className="text-2xl font-bold text-white w-full max-w-md text-right">
                            R$ {config.netValuePerCycle.toFixed(2)}
                        </div>
                    </div>

                    <div className="flex items-center justify-between border-b border-gray-700 pb-4">
                        <label className="text-gray-300 font-semibold w-1/3">Período de Apuração</label>
                        <select 
                            value={config.period}
                            onChange={e => handleConfigChange('period', e.target.value)}
                            className="w-full max-w-md bg-brand-gray border border-gray-700 rounded-lg p-3 text-white focus:outline-none"
                        >
                            <option value="Mensal">Mensal</option>
                            <option value="Trimestral">Trimestral</option>
                            <option value="Semestral">Semestral</option>
                            <option value="Anual">Anual</option>
                        </select>
                    </div>

                    <div className="flex items-center justify-between border-b border-gray-700 pb-4">
                        <label className="text-gray-300 font-semibold w-1/3">Reconhecimento do PIN</label>
                        <p className="text-gray-400 text-sm text-right w-full max-w-md">
                            O PIN é conquistado e permanece válido durante o período de apuração ({config.period.toLowerCase()}).
                        </p>
                    </div>

                    <div className="flex items-center justify-between border-b border-gray-700 pb-4">
                        <label className="text-gray-300 font-semibold w-1/3">Pagamento do Bônus</label>
                        <p className="text-gray-400 text-sm text-right w-full max-w-md">
                            Pago ao atingir a meta, com valor liberado imediatamente.
                        </p>
                    </div>

                    <div className="flex items-center justify-between border-b border-gray-700 pb-4">
                        <label className="text-gray-300 font-semibold w-1/3">VMEC (Definição)</label>
                        <p className="text-gray-400 text-sm text-right w-full max-w-md">
                            Volume Máximo por Equipe e por Ciclo.
                        </p>
                    </div>

                    <div className="flex items-center justify-between">
                        <label className="text-gray-300 font-semibold w-1/3">Pontuação</label>
                        <p className="text-gray-400 text-sm text-right w-full max-w-md">
                            Cada ciclo ativo na matriz SIGMA gera 1 ponto/ciclo para o plano de carreira.
                        </p>
                    </div>
                </div>
            </Card>

            {/* Tabela de PINs */}
            <Card>
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-bold text-white flex items-center gap-2"><IconAward size={24} className="text-brand-gold" /> Tabela Oficial de PINs</h3>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="bg-brand-gray border-b border-gray-700 text-xs font-bold text-brand-gold uppercase">
                            <tr>
                                <th className="p-4">PIN</th>
                                <th className="p-4">Ciclos</th>
                                <th className="p-4">Linhas Mín.</th>
                                <th className="p-4">VMEC %</th>
                                <th className="p-4">Recompensa</th>
                                <th className="p-4 text-center">Imagem</th>
                                <th className="p-4 text-center">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            {config.pins.map((pin, index) => (
                                <tr key={index} className="border-b border-gray-800 hover:bg-gray-800/50">
                                    <td className="p-2">
                                        <input 
                                            type="text" 
                                            value={pin.pin} 
                                            onChange={(e) => handlePinChange(index, 'pin', e.target.value)}
                                            className="bg-gray-900 border border-gray-700 rounded p-2 text-white font-bold w-full focus:border-brand-gold focus:outline-none"
                                        />
                                    </td>
                                    <td className="p-2">
                                        <input 
                                            type="number" 
                                            value={pin.cycles} 
                                            onChange={(e) => handlePinChange(index, 'cycles', Number(e.target.value))}
                                            className="bg-gray-900 border border-gray-700 rounded p-2 text-white w-24 focus:border-brand-gold focus:outline-none"
                                        />
                                    </td>
                                    <td className="p-2">
                                        <input 
                                            type="number" 
                                            value={pin.minLines} 
                                            onChange={(e) => handlePinChange(index, 'minLines', Number(e.target.value))}
                                            className="bg-gray-900 border border-gray-700 rounded p-2 text-white w-16 focus:border-brand-gold focus:outline-none"
                                        />
                                    </td>
                                    <td className="p-2">
                                        <input 
                                            type="text" 
                                            value={pin.vmec} 
                                            onChange={(e) => handlePinChange(index, 'vmec', e.target.value)}
                                            className="bg-gray-900 border border-gray-700 rounded p-2 text-white w-24 focus:border-brand-gold focus:outline-none"
                                        />
                                    </td>
                                    <td className="p-2">
                                        <div className="flex items-center bg-gray-900 border border-gray-700 rounded overflow-hidden">
                                            <span className="px-2 text-gray-500 text-xs font-bold">R$</span>
                                            <input 
                                                type="number" 
                                                value={pin.bonus} 
                                                onChange={(e) => handlePinChange(index, 'bonus', Number(e.target.value))}
                                                className="bg-transparent p-2 text-green-400 font-bold w-24 focus:outline-none"
                                            />
                                        </div>
                                    </td>
                                    <td className="p-2 text-center">
                                        <div className="flex flex-col items-center gap-1">
                                            <div className="w-8 h-8 rounded bg-gray-800 flex items-center justify-center text-xs text-gray-500">Sem Imagem</div>
                                            <button className="text-gray-400 hover:text-white"><IconUpload size={14}/></button>
                                        </div>
                                    </td>
                                    <td className="p-2 text-center">
                                        <button onClick={() => removePin(index)} className="p-2 text-gray-500 hover:text-red-500 transition-colors">
                                            <IconTrash size={18} />
                                        </button>
                                        <input 
                                            type="color" 
                                            value={pin.iconColor} 
                                            onChange={(e) => handlePinChange(index, 'iconColor', e.target.value)}
                                            className="w-6 h-6 bg-transparent border-none cursor-pointer mt-1 inline-block"
                                            title="Cor do Ícone"
                                        />
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                
                <button 
                    onClick={addPin} 
                    className="mt-6 flex items-center gap-2 px-4 py-2 border border-gray-600 rounded-lg text-gray-400 hover:text-white hover:border-brand-gold hover:bg-gray-800 transition-all"
                >
                    <IconPlus size={18} /> Adicionar Novo PIN
                </button>
            </Card>

            <div className="fixed bottom-8 right-8 z-40">
                <button 
                    onClick={handleSave} 
                    disabled={!isDirty}
                    className={`flex items-center gap-2 px-6 py-4 rounded-full font-bold shadow-2xl transition-all transform hover:scale-105 ${isDirty ? 'bg-brand-gold text-brand-dark hover:bg-white' : 'bg-gray-600 text-gray-400 cursor-not-allowed'}`}
                >
                    <IconSave size={20} />
                    Salvar Todas as Alterações
                </button>
            </div>
        </div>
    );
};

export default CareerPlanConfig;
