
import React, { useState, useEffect } from 'react';
import Card from '../../../components/Card';
import { useSystemSettings } from '../../../context/SystemSettingsContext';
import { IconSave, IconGitFork, IconSettings } from '../../../components/icons';

const MatrixConfig: React.FC = () => {
    const { settings, updateSettings, isLoading } = useSystemSettings();
    const [config, setConfig] = useState(settings.matrixSigma);
    const [isDirty, setIsDirty] = useState(false);

    useEffect(() => {
        if (settings.matrixSigma) {
            setConfig(settings.matrixSigma);
        }
    }, [settings]);

    const handleChange = (field: keyof typeof config, value: any) => {
        setConfig(prev => ({ ...prev, [field]: value }));
        setIsDirty(true);
    };

    const handleSave = async () => {
        await updateSettings({ matrixSigma: config });
        setIsDirty(false);
        alert('Configurações da Matriz atualizadas!');
    };

    if (isLoading) return <div className="text-white text-center mt-20">Carregando...</div>;

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-brand-gold">Configurações do Plano SIGMA</h1>
            
            <Card className="max-w-4xl border-l-4 border-l-brand-gold">
                <div className="flex items-center gap-3 mb-6 pb-4 border-b border-gray-700">
                    <IconGitFork className="text-brand-gold" size={28} />
                    <h2 className="text-xl font-bold text-white">Ciclo da Matriz</h2>
                </div>

                <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6 items-center">
                        <label className="text-gray-300 font-semibold">Valor Total do Ciclo</label>
                        <div className="flex items-center bg-brand-gray rounded-lg border border-gray-700 overflow-hidden">
                            <span className="px-3 text-gray-500 font-bold">R$</span>
                            <input 
                                type="number" 
                                value={config.cycleValue} 
                                onChange={e => handleChange('cycleValue', parseFloat(e.target.value))}
                                className="w-full bg-transparent p-3 text-white focus:outline-none"
                            />
                        </div>

                        <label className="text-gray-300 font-semibold">Payout do Ciclo (Valor)</label>
                        <div className="flex items-center bg-brand-gray rounded-lg border border-gray-700 overflow-hidden">
                            <span className="px-3 text-gray-500 font-bold">R$</span>
                            <input 
                                type="number" 
                                value={config.payoutValue} 
                                onChange={e => handleChange('payoutValue', parseFloat(e.target.value))}
                                className="w-full bg-transparent p-3 text-white focus:outline-none"
                            />
                        </div>

                        <label className="text-gray-300 font-semibold">Payout do Ciclo (%)</label>
                        <div className="flex items-center bg-brand-gray rounded-lg border border-gray-700 overflow-hidden">
                            <input 
                                type="number" 
                                value={config.payoutPercent} 
                                onChange={e => handleChange('payoutPercent', parseFloat(e.target.value))}
                                className="w-full bg-transparent p-3 text-white focus:outline-none text-right"
                            />
                            <span className="px-3 text-gray-500 font-bold">%</span>
                        </div>

                        <label className="text-gray-300 font-semibold">Reentrada Automática</label>
                        <div className="flex items-center gap-4">
                            <span className="text-green-400 font-bold">{config.reentry}</span>
                            <p className="text-xs text-gray-500">Kit Ativação Essencial, Entrega em casa</p>
                            <button className="ml-auto text-xs bg-gray-700 px-3 py-1 rounded text-white hover:bg-gray-600">Configurar</button>
                        </div>

                        <label className="text-gray-300 font-semibold">Limite de Reentradas/Mês</label>
                        <div className="flex items-center bg-brand-gray rounded-lg border border-gray-700 overflow-hidden">
                            <input 
                                type="number" 
                                value={config.reentryLimit} 
                                onChange={e => handleChange('reentryLimit', parseInt(e.target.value))}
                                className="w-full bg-transparent p-3 text-white focus:outline-none text-right"
                            />
                            <span className="px-3 text-gray-500 font-bold">vezes</span>
                        </div>

                        <label className="text-gray-300 font-semibold">Derramamento (Spillover)</label>
                        <select 
                            value={config.spillover} 
                            onChange={e => handleChange('spillover', e.target.value)}
                            className="w-full bg-brand-gray border border-gray-700 rounded-lg p-3 text-white focus:outline-none"
                        >
                            <option value="Linha Ascendente">Linha Ascendente</option>
                            <option value="Diretos">Diretos</option>
                            <option value="Equipe">Equipe</option>
                        </select>

                        <label className="text-gray-300 font-semibold">Pontos para Carreira</label>
                        <div className="flex items-center bg-brand-gray rounded-lg border border-gray-700 overflow-hidden">
                            <input 
                                type="number" 
                                value={config.careerPoints} 
                                onChange={e => handleChange('careerPoints', parseFloat(e.target.value))}
                                className="w-full bg-transparent p-3 text-white focus:outline-none text-right"
                            />
                            <span className="px-3 text-gray-500 font-bold">ponto(s)</span>
                        </div>
                    </div>
                </div>
            </Card>

            <div className="fixed bottom-8 right-8 z-40">
                <button 
                    onClick={handleSave} 
                    disabled={!isDirty}
                    className={`flex items-center gap-2 px-6 py-4 rounded-full font-bold shadow-2xl transition-all transform hover:scale-105 ${isDirty ? 'bg-brand-gold text-brand-dark hover:bg-white' : 'bg-gray-600 text-gray-400 cursor-not-allowed'}`}
                >
                    <IconSave size={20} />
                    Salvar Alterações
                </button>
            </div>
        </div>
    );
};

export default MatrixConfig;
