
import React, { useState, useEffect } from 'react';
import Card from '../../../components/Card';
import { useSystemSettings } from '../../../context/SystemSettingsContext';
import { IconSave, IconStar } from '../../../components/icons';

const TopSigmaConfig: React.FC = () => {
    const { settings, updateSettings, isLoading } = useSystemSettings();
    const [config, setConfig] = useState(settings.topSigma);
    const [isDirty, setIsDirty] = useState(false);

    useEffect(() => {
        if (settings.topSigma) setConfig(settings.topSigma);
    }, [settings]);

    const handleBaseChange = (val: number) => {
        setConfig(prev => ({ ...prev, baseCalculation: val }));
        setIsDirty(true);
    };

    const handleRankChange = (index: number, val: number) => {
        const newRanking = [...config.ranking];
        newRanking[index] = { ...newRanking[index], percent: val };
        setConfig(prev => ({ ...prev, ranking: newRanking }));
        setIsDirty(true);
    };

    const handleSave = async () => {
        await updateSettings({ topSigma: config });
        setIsDirty(false);
        alert('Configurações Top SIGMA salvas!');
    };

    const totalCalculated = (config.baseCalculation / 100) * 360; 

    if (isLoading) return <div>Carregando...</div>;

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-brand-gold flex items-center gap-3">
                <IconStar className="text-brand-gold" />
                TOP SIGMA (Pool Global de Liderança)
            </h1>

            <Card>
                <div className="flex items-center gap-4 mb-6 bg-brand-gray-dark p-4 rounded-lg border border-gray-700">
                    <label className="text-white font-bold">Base de Cálculo (%)</label>
                    <input 
                        type="number" 
                        value={config.baseCalculation} 
                        onChange={e => handleBaseChange(parseFloat(e.target.value))}
                        className="bg-brand-gray text-brand-gold font-bold text-xl w-24 p-2 rounded border border-brand-gold focus:outline-none text-center"
                    />
                    <span className="text-gray-400">sobre R$ 360.00 = <span className="text-white font-bold">R$ {totalCalculated.toFixed(2)}</span></span>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="bg-brand-gray border-b border-gray-700 text-xs text-gray-500 uppercase">
                            <tr>
                                <th className="p-4 text-center">Ranking</th>
                                <th className="p-4 text-right">% do Pool</th>
                            </tr>
                        </thead>
                        <tbody>
                            {config.ranking.map((rank, idx) => (
                                <tr key={rank.position} className="border-b border-gray-800 last:border-0 hover:bg-gray-800/30">
                                    <td className="p-4 text-center font-bold text-white">{rank.position}º</td>
                                    <td className="p-4 text-right">
                                        <div className="inline-flex items-center bg-gray-900 rounded border border-gray-700 px-2 ml-auto">
                                            <input 
                                                type="number" 
                                                value={rank.percent} 
                                                onChange={e => handleRankChange(idx, parseFloat(e.target.value))}
                                                className="bg-transparent w-20 text-right text-white p-2 focus:outline-none"
                                            />
                                            <span className="text-gray-500 ml-1">%</span>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                            <tr className="bg-brand-gray-dark font-bold text-white">
                                <td className="p-4 text-center">TOTAL</td>
                                <td className="p-4 text-right text-brand-gold">{config.ranking.reduce((a,b)=>a+b.percent,0).toFixed(2)}%</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </Card>

            <div className="fixed bottom-8 right-8 z-40">
                <button 
                    onClick={handleSave} 
                    disabled={!isDirty}
                    className={`flex items-center gap-2 px-6 py-4 rounded-full font-bold shadow-2xl transition-all transform hover:scale-105 ${isDirty ? 'bg-brand-gold text-brand-dark hover:bg-white' : 'bg-gray-600 text-gray-400 cursor-not-allowed'}`}
                >
                    <IconSave size={20} />
                    Salvar Alterações
                </button>
            </div>
        </div>
    );
};

export default TopSigmaConfig;
