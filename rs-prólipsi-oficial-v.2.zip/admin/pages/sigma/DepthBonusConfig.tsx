
import React, { useState, useEffect } from 'react';
import Card from '../../../components/Card';
import { useSystemSettings } from '../../../context/SystemSettingsContext';
import { IconSave, IconUsers, IconStar, IconRepeat } from '../../../components/icons';

const DepthBonusConfig: React.FC = () => {
    const { settings, updateSettings, isLoading } = useSystemSettings();
    const [config, setConfig] = useState(settings.depthBonus);
    const [cycleBaseValue, setCycleBaseValue] = useState(360); // Default base
    const [isDirty, setIsDirty] = useState(false);

    useEffect(() => {
        if (settings.depthBonus) setConfig(settings.depthBonus);
        if (settings.matrixSigma?.cycleValue) setCycleBaseValue(settings.matrixSigma.cycleValue);
    }, [settings]);

    const handleBaseChange = (val: number) => {
        setConfig(prev => ({ ...prev, baseCalculation: val }));
        setIsDirty(true);
    };

    const handleLevelChange = (index: number, val: number) => {
        const newLevels = [...config.levels];
        newLevels[index] = { ...newLevels[index], percent: val };
        
        // Auto-calc value based on new percent
        const totalPool = (config.baseCalculation / 100) * cycleBaseValue;
        newLevels[index].value = totalPool * (val / 100);

        setConfig(prev => ({ ...prev, levels: newLevels }));
        setIsDirty(true);
    };

    const handleSave = async () => {
        await updateSettings({ depthBonus: config });
        setIsDirty(false);
        alert('Configurações de Profundidade salvas!');
    };

    const totalPool = (config.baseCalculation / 100) * cycleBaseValue;

    if (isLoading) return <div>Carregando...</div>;

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-brand-gold flex items-center gap-3">
                Bônus de Profundidade (L1-L6)
            </h1>

            <Card className="border-t-4 border-brand-gold">
                <div className="mb-6 space-y-2">
                    <h3 className="text-lg font-bold text-brand-gold flex items-center gap-2"><IconStar size={20} /> Regras e Fonte do Bônus</h3>
                    <p className="text-sm text-gray-400 leading-relaxed">
                        Bônus pago sobre a estrutura de rede. O consultor recebe este bônus quando um indicado em sua rede (até o 6º nível) completa um ciclo.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-brand-gray-dark p-6 rounded-lg mb-8">
                    <div>
                        <label className="text-gray-400 text-sm block mb-1">Base de Cálculo (%)</label>
                        <input 
                            type="number" 
                            value={config.baseCalculation} 
                            onChange={e => handleBaseChange(parseFloat(e.target.value))}
                            className="bg-brand-gray text-white font-bold w-full p-3 rounded border border-gray-700 focus:border-brand-gold focus:outline-none"
                        />
                    </div>
                    <div>
                        <label className="text-gray-400 text-sm block mb-1">Valor Total do Ciclo</label>
                        <div className="relative">
                            <span className="absolute left-3 top-3 text-gray-500">R$</span>
                            <input 
                                type="number" 
                                value={cycleBaseValue} 
                                readOnly
                                className="bg-brand-gray text-white font-bold w-full p-3 pl-10 rounded border border-gray-700 focus:outline-none opacity-70 cursor-not-allowed"
                            />
                        </div>
                    </div>
                    <div className="md:col-span-2 bg-black/30 p-4 rounded border border-gray-800 flex justify-between items-center">
                        <span className="text-gray-300 font-bold">Total do Bônus (Pool)</span>
                        <span className="text-2xl font-extrabold text-brand-gold">R$ {totalPool.toFixed(2)}</span>
                    </div>
                    <div className="md:col-span-2 grid grid-cols-2 gap-4 text-xs text-gray-400">
                        <div>
                            <span className="font-bold text-white block mb-1">Gatilho</span>
                            Fechamento de ciclo por um membro da rede (downline).
                        </div>
                        <div>
                            <span className="font-bold text-white block mb-1">Elegibilidade</span>
                            Estar ativo e qualificado no nível correspondente.
                        </div>
                    </div>
                </div>

                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2"><IconUsers size={18} className="text-brand-gold"/> Distribuição por Nível</h3>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="bg-brand-gray border-b border-gray-700 text-xs text-gray-500 uppercase">
                            <tr>
                                <th className="p-4">Nível</th>
                                <th className="p-4 text-center">% do Bônus</th>
                                <th className="p-4 text-right">Valor/Venda (R$)</th>
                            </tr>
                        </thead>
                        <tbody>
                            {config.levels.map((level, idx) => (
                                <tr key={level.level} className="border-b border-gray-800 last:border-0 hover:bg-gray-800/30">
                                    <td className="p-4 font-bold text-white">L{level.level}</td>
                                    <td className="p-4 text-center">
                                        <div className="inline-flex items-center bg-gray-900 rounded border border-gray-700 px-2">
                                            <input 
                                                type="number" 
                                                value={level.percent} 
                                                onChange={e => handleLevelChange(idx, parseFloat(e.target.value))}
                                                className="bg-transparent w-16 text-center text-white p-2 focus:outline-none"
                                            />
                                            <span className="text-gray-500">%</span>
                                        </div>
                                    </td>
                                    <td className="p-4 text-right font-mono text-white">
                                        {(level.value || 0).toFixed(3)}
                                    </td>
                                </tr>
                            ))}
                            <tr className="bg-brand-gray-dark font-bold text-white">
                                <td className="p-4">TOTAL</td>
                                <td className="p-4 text-center">{config.levels.reduce((a,b)=>a+b.percent,0).toFixed(2)}%</td>
                                <td className="p-4 text-right text-brand-gold">R$ {config.levels.reduce((a,b)=>a+(b.value || 0),0).toFixed(3)}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </Card>

            <Card>
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-bold text-brand-gold flex items-center gap-2">
                        <IconRepeat className="text-brand-gold"/> Relatório de Qualificação (Simulação)
                    </h3>
                </div>
                <div className="flex items-center gap-2 mb-4 text-sm">
                    <label>Filtrar por Nível:</label>
                    <select className="bg-brand-gray border border-gray-700 rounded px-2 py-1 text-white">
                        <option>Todos</option>
                        <option>L1</option>
                        <option>L2</option>
                        <option>L3</option>
                        <option>L4</option>
                        <option>L5</option>
                        <option>L6</option>
                    </select>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs uppercase text-gray-500 font-bold">
                        <thead className="border-b border-gray-700">
                            <tr>
                                <th className="p-3 text-brand-gold">Consultor</th>
                                <th className="p-3 text-brand-gold">Nível</th>
                                <th className="p-3 text-brand-gold">Ciclos Completos</th>
                                <th className="p-3 text-brand-gold text-right">Bônus Gerado (Estimado)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colSpan={4} className="text-center py-8 text-gray-600 font-normal normal-case">
                                    Nenhum dado para exibir.
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </Card>

            <div className="fixed bottom-8 right-8 z-40">
                <button 
                    onClick={handleSave} 
                    disabled={!isDirty}
                    className={`flex items-center gap-2 px-6 py-4 rounded-full font-bold shadow-2xl transition-all transform hover:scale-105 ${isDirty ? 'bg-brand-gold text-brand-dark hover:bg-white' : 'bg-gray-600 text-gray-400 cursor-not-allowed'}`}
                >
                    <IconSave size={20} />
                    Salvar Alterações
                </button>
            </div>
        </div>
    );
};

export default DepthBonusConfig;
