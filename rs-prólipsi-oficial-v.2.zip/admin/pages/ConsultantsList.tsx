
import React, { useState } from 'react';
import Card from '../../components/Card';
import Modal from '../../components/Modal';
import { IconSearch, IconUser, IconUsers, IconGitFork, IconAward, IconUpload, IconEdit, IconLock, IconCheckCircle, IconTrash } from '../../components/icons';
import { mockAllConsultants } from '../../consultant/data'; // Import real data
import type { User } from '../../types';

const ConsultantsList: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'lista' | 'relatorio' | 'rede' | 'metas'>('lista');
    const [searchTerm, setSearchTerm] = useState('');
    
    // Modal States
    const [isUploadModalOpen, setUploadModalOpen] = useState(false);
    const [isEditModalOpen, setEditModalOpen] = useState(false);
    const [isPasswordModalOpen, setPasswordModalOpen] = useState(false);
    const [selectedConsultant, setSelectedConsultant] = useState<User | null>(null);
    const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'success'>('idle');

    // Forms
    const [newPassword, setNewPassword] = useState('');
    const [editFormData, setEditFormData] = useState<Partial<User>>({});

    const tabs = [
        { id: 'lista', label: 'Lista de Consultores', icon: IconUser },
        { id: 'relatorio', label: 'Relatório de Usuários', icon: IconUsers },
        { id: 'rede', label: 'Visualizador de Rede', icon: IconGitFork },
        { id: 'metas', label: 'Metas e Desempenho', icon: IconAward },
    ];

    const filteredConsultants = mockAllConsultants.filter(c => 
        c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        c.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.id.includes(searchTerm)
    );

    // Handlers
    const handleOpenEdit = (consultant: User) => {
        setSelectedConsultant(consultant);
        setEditFormData({ name: consultant.name, email: consultant.email, whatsapp: consultant.whatsapp, pin: consultant.pin });
        setEditModalOpen(true);
    };

    const handleOpenPassword = (consultant: User) => {
        setSelectedConsultant(consultant);
        setNewPassword('');
        setPasswordModalOpen(true);
    };

    const handleSaveEdit = (e: React.FormEvent) => {
        e.preventDefault();
        // Here you would call your API to update the user
        alert(`Dados de ${selectedConsultant?.name} atualizados com sucesso! (Simulação)`);
        setEditModalOpen(false);
    };

    const handleSavePassword = (e: React.FormEvent) => {
        e.preventDefault();
        // Here you would call your API to update the password
        alert(`Senha de ${selectedConsultant?.name} alterada para "${newPassword}"! (Simulação)`);
        setPasswordModalOpen(false);
    };

    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            setUploadStatus('uploading');
            // Simulate upload delay
            setTimeout(() => {
                setUploadStatus('success');
                // Reset after 2 seconds
                setTimeout(() => {
                    setUploadModalOpen(false);
                    setUploadStatus('idle');
                    alert('400+ consultores importados com sucesso para o banco de dados!');
                }, 2000);
            }, 1500);
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-brand-gold">Gestão Profissional de Consultores</h1>
                    <p className="text-gray-400">Total de Registros na Base: {mockAllConsultants.length}</p>
                </div>
                <button 
                    onClick={() => setUploadModalOpen(true)}
                    className="flex items-center gap-2 bg-brand-gold text-brand-dark font-bold py-2 px-4 rounded-lg hover:bg-yellow-400 shadow-lg shadow-brand-gold/20 transition-all transform hover:scale-105"
                >
                    <IconUpload size={20} />
                    Importar Banco de Dados
                </button>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-brand-gray-light overflow-x-auto">
                {tabs.map(tab => (
                    <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as any)}
                        className={`flex items-center gap-2 px-6 py-4 border-b-2 font-medium transition-colors whitespace-nowrap ${
                            activeTab === tab.id 
                            ? 'border-brand-gold text-brand-gold' 
                            : 'border-transparent text-gray-400 hover:text-white'
                        }`}
                    >
                        <tab.icon size={18} />
                        {tab.label}
                    </button>
                ))}
            </div>

            <Card>
                {/* Filters */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mb-6 items-end">
                    <div className="md:col-span-6">
                        <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Buscar por nome, ID ou indicador</label>
                        <div className="relative">
                            <IconSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                            <input 
                                type="text" 
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                                placeholder="Digite para filtrar..." 
                                className="w-full bg-brand-gray-light border border-brand-gray-light rounded-lg py-2.5 pl-10 pr-4 text-white focus:border-brand-gold focus:outline-none"
                            />
                        </div>
                    </div>
                </div>

                <div className="overflow-x-auto max-h-[80vh]">
                    <table className="w-full text-left border-collapse">
                        <thead className="bg-brand-gray border-b border-brand-gray-light text-xs font-bold text-brand-gold uppercase tracking-wider sticky top-0 z-10">
                            <tr>
                                <th className="p-4 bg-brand-gray">ID / Username</th>
                                <th className="p-4 bg-brand-gray">Nome</th>
                                <th className="p-4 bg-brand-gray">Patrocinador</th>
                                <th className="p-4 bg-brand-gray text-center">Status</th>
                                <th className="p-4 bg-brand-gray text-center">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredConsultants.length > 0 ? (
                                filteredConsultants.map(c => (
                                    <tr key={c.id} className="border-b border-brand-gray-light hover:bg-brand-gray-light/30 transition-colors group">
                                        <td className="p-4">
                                            <div className="font-bold text-white">{c.id}</div>
                                            <div className="text-xs text-gray-400">@{c.username}</div>
                                        </td>
                                        <td className="p-4">
                                            <div className="flex items-center gap-3">
                                                <img src={c.avatarUrl} className="w-8 h-8 rounded-full bg-brand-gray" alt=""/>
                                                <div>
                                                    <span className="text-white font-medium block">{c.name}</span>
                                                    <span className="text-xs text-brand-gold">{c.pin}</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="p-4 text-sm text-gray-300">
                                            {c.upline ? (
                                                <div>
                                                    <span className="text-white font-semibold">{c.upline.username}</span>
                                                    <div className="text-xs text-gray-500">{c.upline.name}</div>
                                                </div>
                                            ) : '-'}
                                        </td>
                                        <td className="p-4 text-center">
                                            <span className={`px-2 py-1 rounded text-xs font-bold uppercase ${c.status === 'active' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                                                {c.status}
                                            </span>
                                        </td>
                                        <td className="p-4 text-center">
                                            <div className="flex justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                <button onClick={() => handleOpenEdit(c)} className="p-2 bg-brand-gray text-gray-300 hover:text-white rounded hover:bg-gray-700" title="Editar Dados">
                                                    <IconEdit size={16} />
                                                </button>
                                                <button onClick={() => handleOpenPassword(c)} className="p-2 bg-brand-gray text-gray-300 hover:text-brand-gold rounded hover:bg-gray-700" title="Alterar Senha">
                                                    <IconLock size={16} />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan={5} className="text-center py-12 text-gray-500">
                                        Nenhum consultor encontrado.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>

            {/* Modal Importação */}
            <Modal isOpen={isUploadModalOpen} onClose={() => setUploadModalOpen(false)} title="Importar Base de Dados">
                <div className="space-y-6 text-center py-6">
                    <div className="mx-auto w-16 h-16 bg-brand-gray-light rounded-full flex items-center justify-center mb-4">
                        <IconUpload size={32} className="text-brand-gold"/>
                    </div>
                    <div>
                        <h3 className="text-lg font-bold text-white">Carregar Planilha de Consultores</h3>
                        <p className="text-sm text-gray-400 mt-2">Suporta arquivos .CSV, .XLSX ou .JSON. Certifique-se que o formato contém colunas para ID, Nome e Indicador.</p>
                    </div>
                    
                    {uploadStatus === 'idle' && (
                        <label className="block w-full border-2 border-dashed border-gray-600 rounded-lg p-8 cursor-pointer hover:border-brand-gold hover:bg-brand-gray-light/20 transition-all">
                            <input type="file" className="hidden" accept=".csv,.xlsx,.json" onChange={handleFileUpload} />
                            <p className="text-brand-gold font-bold">Clique para selecionar o arquivo</p>
                            <p className="text-xs text-gray-500 mt-1">ou arraste e solte aqui</p>
                        </label>
                    )}

                    {uploadStatus === 'uploading' && (
                        <div className="space-y-3">
                            <div className="w-full bg-brand-gray h-2 rounded-full overflow-hidden">
                                <div className="bg-brand-gold h-full animate-pulse w-2/3"></div>
                            </div>
                            <p className="text-sm text-gray-300">Processando registros...</p>
                        </div>
                    )}

                    {uploadStatus === 'success' && (
                        <div className="text-green-400 font-bold flex items-center justify-center gap-2">
                            <IconCheckCircle /> Importação concluída!
                        </div>
                    )}
                </div>
            </Modal>

            {/* Modal Editar Dados */}
            <Modal isOpen={isEditModalOpen} onClose={() => setEditModalOpen(false)} title={`Editar: ${selectedConsultant?.name}`}>
                <form onSubmit={handleSaveEdit} className="space-y-4">
                    <div>
                        <label className="text-sm text-gray-400 block mb-1">Nome Completo</label>
                        <input type="text" value={editFormData.name || ''} onChange={e => setEditFormData({...editFormData, name: e.target.value})} className="w-full bg-brand-gray p-2 rounded border border-gray-600 focus:border-brand-gold focus:outline-none"/>
                    </div>
                    <div>
                        <label className="text-sm text-gray-400 block mb-1">E-mail</label>
                        <input type="email" value={editFormData.email || ''} onChange={e => setEditFormData({...editFormData, email: e.target.value})} className="w-full bg-brand-gray p-2 rounded border border-gray-600 focus:border-brand-gold focus:outline-none"/>
                    </div>
                    <div>
                        <label className="text-sm text-gray-400 block mb-1">WhatsApp</label>
                        <input type="text" value={editFormData.whatsapp || ''} onChange={e => setEditFormData({...editFormData, whatsapp: e.target.value})} className="w-full bg-brand-gray p-2 rounded border border-gray-600 focus:border-brand-gold focus:outline-none"/>
                    </div>
                    <div>
                        <label className="text-sm text-gray-400 block mb-1">PIN (Graduação)</label>
                        <select value={editFormData.pin || 'Iniciante'} onChange={e => setEditFormData({...editFormData, pin: e.target.value})} className="w-full bg-brand-gray p-2 rounded border border-gray-600 focus:border-brand-gold focus:outline-none">
                            <option value="Iniciante">Iniciante</option>
                            <option value="Bronze">Bronze</option>
                            <option value="Prata">Prata</option>
                            <option value="Ouro">Ouro</option>
                            <option value="Diamante">Diamante</option>
                            <option value="Diamante Black">Diamante Black</option>
                        </select>
                    </div>
                    <button type="submit" className="w-full bg-brand-gold text-brand-dark font-bold py-3 rounded-lg hover:bg-yellow-400 mt-4">Salvar Alterações</button>
                </form>
            </Modal>

            {/* Modal Alterar Senha */}
            <Modal isOpen={isPasswordModalOpen} onClose={() => setPasswordModalOpen(false)} title="Alterar Senha de Acesso">
                <form onSubmit={handleSavePassword} className="space-y-4">
                    <div className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg text-sm text-yellow-200 mb-4">
                        Você está alterando a senha de <strong>{selectedConsultant?.name}</strong>. Esta ação invalidará a senha anterior imediatamente.
                    </div>
                    <div>
                        <label className="text-sm text-gray-400 block mb-1">Nova Senha</label>
                        <input 
                            type="text" 
                            value={newPassword} 
                            onChange={e => setNewPassword(e.target.value)} 
                            placeholder="Digite a nova senha..."
                            className="w-full bg-brand-gray p-2 rounded border border-gray-600 focus:border-brand-gold focus:outline-none"
                            required
                        />
                    </div>
                    <button type="submit" className="w-full bg-brand-gold text-brand-dark font-bold py-3 rounded-lg hover:bg-yellow-400 mt-4">Confirmar Nova Senha</button>
                </form>
            </Modal>
        </div>
    );
};

export default ConsultantsList;
