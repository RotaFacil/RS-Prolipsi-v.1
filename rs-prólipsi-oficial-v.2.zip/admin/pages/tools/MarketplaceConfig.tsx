
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../../../components/Card';
import { 
    IconStore, IconExternalLink, IconSettings, IconShoppingCart, 
    IconUsers, IconTag, IconChart, IconUser 
} from '../../../components/icons';
import { mockStoreConfig } from '../../../consultant/data';

const StatCard: React.FC<{ title: string; value: string; icon: React.ElementType; color: string }> = ({ title, value, icon: Icon, color }) => (
    <div className="bg-brand-gray-light p-4 rounded-lg border border-brand-gray flex items-center space-x-4">
        <div className={`p-3 rounded-full ${color} bg-opacity-20`}>
            <Icon size={24} className={color.replace('bg-', 'text-')} />
        </div>
        <div>
            <p className="text-gray-400 text-xs uppercase font-bold">{title}</p>
            <p className="text-xl font-bold text-white">{value}</p>
        </div>
    </div>
);

const MarketplaceConfig: React.FC = () => {
    const navigate = useNavigate();

    const handleOpenStore = () => {
        // Lógica robusta: detecta o endereço real do browser para evitar 404
        const origin = window.location.origin;
        const path = window.location.pathname;
        const storeUrl = `${origin}${path}#/store/${mockStoreConfig.slug}`;
        window.open(storeUrl, '_blank');
    };

    return (
        <div className="space-y-8 animate-fade-in">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-brand-gold flex items-center gap-3">
                        <IconStore size={32}/> Gestão do Marketplace
                    </h1>
                    <p className="text-gray-400 mt-1">Configure a loja oficial, gerencie parceiros e acompanhe vendas globais.</p>
                </div>
                <div className="flex gap-3">
                    <button 
                        onClick={() => navigate('/login')}
                        className="flex items-center gap-2 bg-brand-gray text-white font-bold py-3 px-6 rounded-lg hover:bg-brand-gray-light border border-gray-600 transition-transform transform hover:scale-105"
                    >
                        <IconUser size={20} />
                        Login Consultor
                    </button>
                    <button 
                        onClick={handleOpenStore}
                        className="flex items-center gap-2 bg-brand-gold text-brand-dark font-bold py-3 px-6 rounded-lg hover:bg-yellow-400 shadow-lg shadow-brand-gold/20 transition-transform transform hover:scale-105"
                    >
                        <IconExternalLink size={20} />
                        Acessar Loja Oficial
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard title="Produtos Ativos" value="1,245" icon={IconTag} color="text-blue-400" />
                <StatCard title="Lojistas Parceiros" value="42" icon={IconUsers} color="text-purple-400" />
                <StatCard title="Vendas Hoje" value="R$ 12.580" icon={IconShoppingCart} color="text-green-400" />
                <StatCard title="Ticket Médio" value="R$ 185,00" icon={IconChart} color="text-yellow-400" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <Card className="border-t-4 border-brand-gold">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-xl font-bold text-white flex items-center gap-2">
                            <IconSettings className="text-gray-400"/> Configuração da Vitrine
                        </h2>
                        <span className="bg-green-500/20 text-green-400 text-xs font-bold px-2 py-1 rounded uppercase">Online</span>
                    </div>
                    
                    <div className="space-y-4">
                        <div className="p-4 bg-brand-gray-dark rounded-lg border border-gray-700">
                            <h3 className="font-bold text-white mb-2">Tema Atual</h3>
                            <div className="flex items-center gap-4">
                                <div className="h-16 w-24 bg-gray-800 rounded border border-gray-600 flex items-center justify-center text-xs text-gray-500">
                                    Preview
                                </div>
                                <div>
                                    <p className="text-brand-gold font-semibold">Boutique de Luxo (Otimizado)</p>
                                    <p className="text-xs text-gray-400">Última alteração: Hoje</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </Card>

                <Card>
                    <h2 className="text-xl font-bold text-white mb-6">Ações Administrativas</h2>
                    <div className="space-y-3">
                        <button className="w-full flex items-center justify-between p-4 bg-brand-gray-light rounded-lg hover:bg-brand-gray transition-colors group">
                            <div className="flex items-center gap-3">
                                <div className="bg-blue-500/20 p-2 rounded-lg text-blue-400"><IconTag size={20}/></div>
                                <div className="text-left">
                                    <p className="font-bold text-white">Gerenciar Catálogo</p>
                                    <p className="text-xs text-gray-400">Adicionar ou editar produtos</p>
                                </div>
                            </div>
                            <span className="text-gray-500 group-hover:text-white transition-colors">→</span>
                        </button>
                    </div>
                </Card>
            </div>
        </div>
    );
};

export default MarketplaceConfig;
