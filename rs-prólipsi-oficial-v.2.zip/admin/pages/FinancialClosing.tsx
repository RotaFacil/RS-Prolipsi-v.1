
import React, { useState, useEffect } from 'react';
import Card from '../../components/Card';
import Modal from '../../components/Modal';
import { 
    IconFileClock, IconCheckCircle, IconAlertTriangle, IconPlay, 
    IconSettings, IconCalendar, IconDownload, IconRepeat, IconAward, IconStar,
    IconSearch, IconUser, IconFilter, IconGitFork, IconUsers, IconSave
} from '../../components/icons';

// Tipos atualizados para suportar a complexidade
type TargetType = 'global' | 'pin' | 'individual';
type BonusType = 'matrix_sigma' | 'depth' | 'fidelity' | 'career' | 'top_sigma';

interface SimulationResult {
    id: string;
    consultantName: string;
    consultantPin: string;
    bonuses: Partial<Record<BonusType, number>>;
    total: number;
    status: 'pending' | 'ready' | 'error';
    details?: string;
}

interface ClosingLog {
    id: string;
    date: string;
    period: string;
    target: string;
    totalDistributed: number;
    status: 'completed' | 'failed';
}

const mockHistory: ClosingLog[] = [
    { id: '1', date: '01/02/2025', period: '01/01/25 - 31/01/25', target: 'Global', totalDistributed: 45200.00, status: 'completed' },
    { id: '2', date: '15/01/2025', period: 'Trimestral', target: 'Diamantes e Acima', totalDistributed: 12500.00, status: 'completed' },
];

const formatCurrency = (value: number) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const FinancialClosing: React.FC = () => {
    // --- ESTADOS DE CONFIGURAÇÃO ---
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    
    // Seleção de Bônus (Multi-select)
    const [selectedBonuses, setSelectedBonuses] = useState<BonusType[]>([
        'matrix_sigma', 'depth', 'fidelity'
    ]);

    // Seleção de Alvo
    const [targetType, setTargetType] = useState<TargetType>('global');
    const [targetValue, setTargetValue] = useState(''); // ID do usuário ou Nome do PIN

    // --- ESTADOS DE PROCESSO ---
    const [isSimulating, setIsSimulating] = useState(false);
    const [simulationResults, setSimulationResults] = useState<SimulationResult[]>([]);
    const [selectedRows, setSelectedRows] = useState<string[]>([]); // IDs das linhas selecionadas para pagamento
    const [confirmModalOpen, setConfirmModalOpen] = useState(false);
    const [isProcessing, setIsProcessing] = useState(false);

    // Toggle de Bônus
    const toggleBonus = (bonus: BonusType) => {
        setSelectedBonuses(prev => 
            prev.includes(bonus) ? prev.filter(b => b !== bonus) : [...prev, bonus]
        );
    };

    // Toggle de Seleção de Linha na Tabela
    const toggleRowSelection = (id: string) => {
        setSelectedRows(prev => 
            prev.includes(id) ? prev.filter(rowId => rowId !== id) : [...prev, id]
        );
    };

    const toggleSelectAll = () => {
        if (selectedRows.length === simulationResults.length) {
            setSelectedRows([]);
        } else {
            setSelectedRows(simulationResults.map(r => r.id));
        }
    };

    // --- LÓGICA DE SIMULAÇÃO (MOCK) ---
    const handleSimulate = () => {
        setIsSimulating(true);
        setSimulationResults([]); // Limpar anterior

        // Simulando delay de cálculo
        setTimeout(() => {
            let results: SimulationResult[] = [];

            // Gerar dados mockados baseados no filtro
            if (targetType === 'individual' && targetValue) {
                // Cenário: Fechamento Individual
                results.push({
                    id: 'sim-1',
                    consultantName: targetValue || 'Consultor Selecionado',
                    consultantPin: 'Diamante',
                    bonuses: {
                        matrix_sigma: selectedBonuses.includes('matrix_sigma') ? 360.00 : 0,
                        depth: selectedBonuses.includes('depth') ? 125.50 : 0,
                        fidelity: selectedBonuses.includes('fidelity') ? 45.00 : 0,
                        career: selectedBonuses.includes('career') ? 2000.00 : 0,
                        top_sigma: selectedBonuses.includes('top_sigma') ? 150.00 : 0,
                    },
                    total: 0, // Calculado abaixo
                    status: 'ready'
                });
            } else {
                // Cenário: Global ou Grupo
                results = [
                    { id: 'sim-1', consultantName: 'Maria Silva', consultantPin: 'Ouro', bonuses: { matrix_sigma: 360, depth: 50 }, total: 0, status: 'ready' },
                    { id: 'sim-2', consultantName: 'João Santos', consultantPin: 'Prata', bonuses: { matrix_sigma: 0, depth: 25, fidelity: 10 }, total: 0, status: 'ready' },
                    { id: 'sim-3', consultantName: 'Carlos Oliveira', consultantPin: 'Diamante', bonuses: { career: 5000, top_sigma: 800 }, total: 0, status: 'ready' },
                    { id: 'sim-4', consultantName: 'Ana Costa', consultantPin: 'Bronze', bonuses: { depth: 12 }, total: 0, status: 'pending', details: 'Falta validação de ativo' },
                ];
            }

            // Recalcular totais baseados nos bônus selecionados
            results = results.map(r => {
                let total = 0;
                selectedBonuses.forEach(b => total += (r.bonuses[b] || 0));
                return { ...r, total };
            }).filter(r => r.total > 0); // Remove quem não tem nada a receber nos bônus selecionados

            setSimulationResults(results);
            setSelectedRows(results.map(r => r.id)); // Auto-selecionar todos
            setIsSimulating(false);
        }, 1500);
    };

    const handleExecutePayment = () => {
        setConfirmModalOpen(false);
        setIsProcessing(true);
        setTimeout(() => {
            setIsProcessing(false);
            setSimulationResults([]);
            alert(`${selectedRows.length} pagamentos processados com sucesso!`);
        }, 2000);
    };

    const totalSelectedValue = simulationResults
        .filter(r => selectedRows.includes(r.id))
        .reduce((acc, r) => acc + r.total, 0);

    return (
        <div className="space-y-8 pb-20">
            <div>
                <h1 className="text-3xl font-bold text-brand-gold flex items-center gap-2">
                    <IconFileClock /> Gestão de Fechamento de Ciclo
                </h1>
                <p className="text-gray-400 mt-1">Ferramenta profissional para apuração de bônus, fechamento de ciclos e pagamentos de rede.</p>
            </div>

            {/* PAINEL DE CONFIGURAÇÃO */}
            <Card className="border-t-4 border-brand-gold">
                <h2 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                    <IconSettings className="text-gray-400" /> 
                    1. Configuração da Apuração
                </h2>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    {/* Coluna 1: Período e Alvo */}
                    <div className="lg:col-span-4 space-y-6">
                        <div>
                            <label className="text-xs font-bold text-gray-500 uppercase mb-2 block">Período de Cálculo</label>
                            <div className="flex gap-2">
                                <div className="relative flex-1">
                                    <IconCalendar className="absolute left-3 top-3 text-gray-500" size={16} />
                                    <input 
                                        type="date" 
                                        value={startDate}
                                        onChange={(e) => setStartDate(e.target.value)}
                                        className="w-full bg-brand-gray-dark border border-gray-600 rounded-lg py-2 pl-10 pr-2 text-white focus:border-brand-gold focus:outline-none"
                                    />
                                </div>
                                <span className="text-gray-500 self-center">até</span>
                                <div className="relative flex-1">
                                    <IconCalendar className="absolute left-3 top-3 text-gray-500" size={16} />
                                    <input 
                                        type="date" 
                                        value={endDate}
                                        onChange={(e) => setEndDate(e.target.value)}
                                        className="w-full bg-brand-gray-dark border border-gray-600 rounded-lg py-2 pl-10 pr-2 text-white focus:border-brand-gold focus:outline-none"
                                    />
                                </div>
                            </div>
                        </div>

                        <div>
                            <label className="text-xs font-bold text-gray-500 uppercase mb-2 block">Alvo do Fechamento (Quem?)</label>
                            <div className="space-y-3">
                                <select 
                                    value={targetType}
                                    onChange={(e) => setTargetType(e.target.value as TargetType)}
                                    className="w-full bg-brand-gray-dark border border-gray-600 rounded-lg py-2.5 px-3 text-white focus:border-brand-gold focus:outline-none"
                                >
                                    <option value="global">Toda a Rede (Global)</option>
                                    <option value="pin">Por Graduação (PIN)</option>
                                    <option value="individual">Consultor Individual (Específico)</option>
                                </select>

                                {targetType === 'individual' && (
                                    <div className="relative animate-fade-in">
                                        <IconSearch className="absolute left-3 top-3 text-brand-gold" size={18} />
                                        <input 
                                            type="text" 
                                            placeholder="Digite Nome ou ID..."
                                            value={targetValue}
                                            onChange={(e) => setTargetValue(e.target.value)}
                                            className="w-full bg-brand-gray-dark border border-brand-gold rounded-lg py-2.5 pl-10 pr-3 text-white focus:outline-none placeholder-gray-500"
                                        />
                                    </div>
                                )}

                                {targetType === 'pin' && (
                                    <select 
                                        value={targetValue}
                                        onChange={(e) => setTargetValue(e.target.value)}
                                        className="w-full bg-brand-gray-dark border border-gray-600 rounded-lg py-2.5 px-3 text-white focus:border-brand-gold focus:outline-none animate-fade-in"
                                    >
                                        <option value="">Selecione o PIN...</option>
                                        <option value="Bronze">Bronze</option>
                                        <option value="Prata">Prata</option>
                                        <option value="Ouro">Ouro</option>
                                        <option value="Diamante">Diamante</option>
                                        <option value="Diamante Black">Diamante Black</option>
                                    </select>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Coluna 2: Seleção de Bônus */}
                    <div className="lg:col-span-5 bg-brand-gray-dark p-4 rounded-lg border border-gray-700">
                        <label className="text-xs font-bold text-gray-500 uppercase mb-4 block">Selecione os Bônus para Processar</label>
                        <div className="space-y-3">
                            {[
                                { id: 'matrix_sigma', label: 'Bônus Matriz SIGMA (Ciclo)', icon: IconGitFork },
                                { id: 'depth', label: 'Bônus de Profundidade', icon: IconUsers },
                                { id: 'fidelity', label: 'Bônus Fidelidade', icon: IconRepeat },
                                { id: 'career', label: 'Plano de Carreira (PINs)', icon: IconAward },
                                { id: 'top_sigma', label: 'Top SIGMA (Participação)', icon: IconStar },
                            ].map((bonus) => (
                                <label key={bonus.id} className="flex items-center p-2 rounded hover:bg-gray-800 cursor-pointer transition-colors">
                                    <input 
                                        type="checkbox" 
                                        checked={selectedBonuses.includes(bonus.id as BonusType)}
                                        onChange={() => toggleBonus(bonus.id as BonusType)}
                                        className="w-5 h-5 rounded border-gray-600 text-brand-gold focus:ring-brand-gold bg-gray-900 accent-brand-gold"
                                    />
                                    <div className="ml-3 flex items-center gap-2">
                                        <bonus.icon size={18} className={selectedBonuses.includes(bonus.id as BonusType) ? 'text-brand-gold' : 'text-gray-500'} />
                                        <span className={`text-sm font-medium ${selectedBonuses.includes(bonus.id as BonusType) ? 'text-white' : 'text-gray-400'}`}>
                                            {bonus.label}
                                        </span>
                                    </div>
                                </label>
                            ))}
                        </div>
                    </div>

                    {/* Coluna 3: Ação */}
                    <div className="lg:col-span-3 flex flex-col justify-end">
                        <button 
                            onClick={handleSimulate}
                            disabled={isSimulating || selectedBonuses.length === 0}
                            className={`w-full py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all shadow-lg ${
                                isSimulating || selectedBonuses.length === 0
                                ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                                : 'bg-brand-gold text-brand-dark hover:bg-white hover:scale-105 shadow-brand-gold/20'
                            }`}
                        >
                            {isSimulating ? (
                                <span className="animate-pulse">Calculando...</span>
                            ) : (
                                <><IconSearch /> Simular Apuração</>
                            )}
                        </button>
                        <p className="text-center text-xs text-gray-500 mt-2">
                            A simulação não gera pagamentos reais.
                        </p>
                    </div>
                </div>
            </Card>

            {/* RESULTADO DA SIMULAÇÃO */}
            {simulationResults.length > 0 && (
                <Card className="animate-fade-in border-t-4 border-green-500">
                    <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
                        <h2 className="text-lg font-bold text-white flex items-center gap-2">
                            <IconCheckCircle className="text-green-500" /> 
                            2. Resultado da Simulação
                        </h2>
                        <div className="flex items-center gap-4 bg-brand-gray-dark px-4 py-2 rounded-lg border border-gray-700">
                            <div className="text-right">
                                <p className="text-xs text-gray-400 uppercase font-bold">Total Selecionado</p>
                                <p className="text-xl font-bold text-brand-gold">{formatCurrency(totalSelectedValue)}</p>
                            </div>
                            <div className="h-8 w-px bg-gray-600"></div>
                            <button 
                                onClick={() => setConfirmModalOpen(true)}
                                disabled={selectedRows.length === 0}
                                className="bg-green-600 hover:bg-green-500 text-white font-bold py-2 px-6 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                            >
                                <IconPlay size={18} />
                                Processar Pagamentos ({selectedRows.length})
                            </button>
                        </div>
                    </div>

                    <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                            <thead className="bg-brand-gray-dark border-b border-gray-700 text-xs font-bold text-gray-400 uppercase">
                                <tr>
                                    <th className="p-4 w-12 text-center">
                                        <input type="checkbox" checked={selectedRows.length === simulationResults.length} onChange={toggleSelectAll} className="accent-brand-gold cursor-pointer" />
                                    </th>
                                    <th className="p-4">Consultor</th>
                                    <th className="p-4">PIN</th>
                                    {selectedBonuses.includes('matrix_sigma') && <th className="p-4 text-right text-yellow-500">Matriz</th>}
                                    {selectedBonuses.includes('depth') && <th className="p-4 text-right text-blue-400">Profund.</th>}
                                    {selectedBonuses.includes('fidelity') && <th className="p-4 text-right text-purple-400">Fidelidade</th>}
                                    {selectedBonuses.includes('career') && <th className="p-4 text-right text-orange-400">Carreira</th>}
                                    {selectedBonuses.includes('top_sigma') && <th className="p-4 text-right text-pink-400">Top Sigma</th>}
                                    <th className="p-4 text-right text-white">Total</th>
                                    <th className="p-4 text-center">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                {simulationResults.map(row => (
                                    <tr key={row.id} className={`border-b border-gray-800 hover:bg-gray-800/50 transition-colors ${selectedRows.includes(row.id) ? 'bg-brand-gold/5' : ''}`}>
                                        <td className="p-4 text-center">
                                            <input 
                                                type="checkbox" 
                                                checked={selectedRows.includes(row.id)} 
                                                onChange={() => toggleRowSelection(row.id)}
                                                className="accent-brand-gold cursor-pointer w-4 h-4" 
                                            />
                                        </td>
                                        <td className="p-4 font-bold text-white">{row.consultantName}</td>
                                        <td className="p-4 text-sm text-gray-400">{row.consultantPin}</td>
                                        {selectedBonuses.includes('matrix_sigma') && <td className="p-4 text-right font-mono text-gray-300">{formatCurrency(row.bonuses.matrix_sigma || 0)}</td>}
                                        {selectedBonuses.includes('depth') && <td className="p-4 text-right font-mono text-gray-300">{formatCurrency(row.bonuses.depth || 0)}</td>}
                                        {selectedBonuses.includes('fidelity') && <td className="p-4 text-right font-mono text-gray-300">{formatCurrency(row.bonuses.fidelity || 0)}</td>}
                                        {selectedBonuses.includes('career') && <td className="p-4 text-right font-mono text-gray-300">{formatCurrency(row.bonuses.career || 0)}</td>}
                                        {selectedBonuses.includes('top_sigma') && <td className="p-4 text-right font-mono text-gray-300">{formatCurrency(row.bonuses.top_sigma || 0)}</td>}
                                        <td className="p-4 text-right font-bold text-brand-gold text-lg">{formatCurrency(row.total)}</td>
                                        <td className="p-4 text-center">
                                            {row.status === 'ready' ? (
                                                <span className="bg-green-500/20 text-green-400 px-2 py-1 rounded text-xs font-bold uppercase">Pronto</span>
                                            ) : (
                                                <span className="bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded text-xs font-bold uppercase" title={row.details}>Pendente</span>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </Card>
            )}

            {/* Histórico */}
            <Card>
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold text-white">Histórico de Fechamentos</h3>
                    <button className="text-sm text-brand-gold hover:text-white flex items-center gap-2">
                        <IconDownload size={16} /> Exportar Tudo
                    </button>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="border-b border-brand-gray text-xs font-bold text-gray-500 uppercase">
                            <tr>
                                <th className="p-3">Data Process.</th>
                                <th className="p-3">Período Ref.</th>
                                <th className="p-3">Alvo</th>
                                <th className="p-3 text-right">Total Distribuído</th>
                                <th className="p-3 text-center">Status</th>
                                <th className="p-3 text-center">Recibo</th>
                            </tr>
                        </thead>
                        <tbody>
                            {mockHistory.map(log => (
                                <tr key={log.id} className="border-b border-brand-gray-light hover:bg-brand-gray-light/50">
                                    <td className="p-3 font-mono text-white">{log.date}</td>
                                    <td className="p-3 text-gray-300">{log.period}</td>
                                    <td className="p-3 text-sm text-gray-400 font-bold">{log.target}</td>
                                    <td className="p-3 text-right font-bold text-white">{formatCurrency(log.totalDistributed)}</td>
                                    <td className="p-3 text-center">
                                        <span className="bg-green-500/20 text-green-400 px-2 py-1 rounded text-xs font-bold uppercase">
                                            Concluído
                                        </span>
                                    </td>
                                    <td className="p-3 text-center">
                                        <button className="text-gray-500 hover:text-brand-gold transition-colors">
                                            <IconFileClock size={18} />
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </Card>

            {/* Modal de Confirmação */}
            <Modal isOpen={confirmModalOpen} onClose={() => setConfirmModalOpen(false)} title="Confirmação de Pagamento">
                <div className="space-y-6 text-center">
                    <div className="mx-auto w-16 h-16 bg-yellow-500/20 rounded-full flex items-center justify-center text-yellow-500 mb-4">
                        <IconAlertTriangle size={32} />
                    </div>
                    
                    <div>
                        <h3 className="text-2xl font-bold text-white">Você está prestes a processar {selectedRows.length} pagamentos.</h3>
                        <p className="text-gray-400 mt-2">
                            Valor total da operação: <span className="text-brand-gold font-bold text-xl">{formatCurrency(totalSelectedValue)}</span>
                        </p>
                    </div>
                    
                    <div className="bg-brand-gray-dark p-4 rounded-lg text-left text-sm text-gray-300 space-y-2 border border-gray-700">
                        <p><strong>Atenção:</strong></p>
                        <ul className="list-disc list-inside space-y-1 text-gray-400">
                            <li>Os valores serão creditados imediatamente nas Wallets dos consultores.</li>
                            <li>O saldo do sistema será deduzido.</li>
                            <li>Esta ação é irreversível e gerará recibos individuais.</li>
                        </ul>
                    </div>

                    <div className="flex gap-4 mt-6">
                        <button 
                            onClick={() => setConfirmModalOpen(false)}
                            className="flex-1 bg-brand-gray text-white font-semibold py-3 rounded-lg hover:bg-brand-gray-light transition-colors"
                        >
                            Cancelar
                        </button>
                        <button 
                            onClick={handleExecutePayment}
                            disabled={isProcessing}
                            className="flex-1 bg-brand-gold text-brand-dark font-bold py-3 rounded-lg hover:bg-yellow-400 transition-colors shadow-lg"
                        >
                            {isProcessing ? 'Processando...' : 'Confirmar e Pagar'}
                        </button>
                    </div>
                </div>
            </Modal>
        </div>
    );
};

export default FinancialClosing;
