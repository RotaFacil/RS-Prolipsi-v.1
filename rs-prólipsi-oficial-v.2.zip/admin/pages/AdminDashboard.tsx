
import React from 'react';
import Card from '../../components/Card';
import { IconUsers, IconWallet, IconGitFork, IconShop } from '../../components/icons';

const StatCard: React.FC<{ title: string; value: string; subtext: string; icon: React.ElementType }> = ({ title, value, subtext, icon: Icon }) => (
    <Card className="flex items-center space-x-4">
        <div className="p-3 bg-brand-gray-light rounded-full">
            <Icon size={24} className="text-brand-gold" />
        </div>
        <div>
            <h4 className="text-sm text-brand-text-dim">{title}</h4>
            <p className="text-2xl font-bold text-white">{value}</p>
            <p className="text-xs text-gray-500">{subtext}</p>
        </div>
    </Card>
);

const AdminDashboard: React.FC = () => {
    return (
        <div className="space-y-8">
            <div>
                <h1 className="text-3xl font-bold text-brand-gold">Painel Administrativo</h1>
                <p className="text-gray-400 mt-1">Visão geral do sistema RS Prólipsi.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard title="Consultores Ativos" value="0" subtext="Nenhum dado" icon={IconUsers} />
                <StatCard title="Saldo Wallet (Total)" value="R$ 0,00" subtext="Nenhum dado" icon={IconWallet} />
                <StatCard title="Ciclos do Mês" value="0" subtext="Nenhum período" icon={IconGitFork} />
                <StatCard title="Vendas Shop" value="R$ 0,00" subtext="Nenhum dado" icon={IconShop} />
            </div>

            <Card>
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-bold text-white">Acesso Rápido: Consultores</h2>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="border-b border-brand-gray text-xs font-bold text-gray-500 uppercase tracking-wider">
                            <tr>
                                <th className="p-3">Nome</th>
                                <th className="p-3">PIN</th>
                                <th className="p-3">Rede</th>
                                <th className="p-3 text-right">Saldo (R$)</th>
                                <th className="p-3 text-center">Ativo Sigma</th>
                                <th className="p-3 text-center">Ciclos (Mês)</th>
                                <th className="p-3 text-center">Pontos Carreira</th>
                                <th className="p-3 text-center">Top Sigma</th>
                                <th className="p-3">Status</th>
                                <th className="p-3 text-center">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colSpan={10} className="text-center py-8 text-gray-500">
                                    Nenhum consultor encontrado.
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default AdminDashboard;
