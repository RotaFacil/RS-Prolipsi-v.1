
import React, { useState } from 'react';
import { NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useUser } from '../consultant/ConsultantLayout';
import { 
    IconSettings, IconUsers, IconLogOut, IconShield, IconChart, IconMenu, 
    IconDashboard, IconGitFork, IconStar, IconAward, IconWallet, IconMessage,
    IconStore, IconUserCog, IconChevronDown, IconEdit, IconFileClock
} from '../components/icons';

const adminGroups = [
    {
        title: 'Gestão',
        items: [
            { name: 'Painel', path: '/global-admin/dashboard', icon: IconDashboard },
            { name: 'Fechamento Financeiro', path: '/global-admin/financial-closing', icon: IconFileClock }, // Novo item
            { name: 'Consultores', path: '/global-admin/consultants', icon: IconUsers },
            { name: 'Admin Consultor', path: '/consultant/dashboard', icon: IconUserCog, external: true },
        ]
    },
    {
        title: 'Configurações SIGMA',
        items: [
            { name: 'Matriz SIGMA', path: '/global-admin/sigma/matrix', icon: IconGitFork },
            { name: 'Bônus Profundidade', path: '/global-admin/sigma/depth', icon: IconUsers },
            { name: 'Top SIGMA', path: '/global-admin/sigma/top', icon: IconStar },
            { name: 'Bônus Fidelidade', path: '/global-admin/sigma/fidelity', icon: IconRepeat },
            { name: 'Plano de Carreira', path: '/global-admin/sigma/career', icon: IconAward },
        ]
    },
    {
        title: 'Ferramentas',
        items: [
            { name: 'Editor de Dashboard', path: '/global-admin/tools/dashboard-editor', icon: IconEdit },
            { name: 'Marketplace', path: '/global-admin/tools/marketplace', icon: IconStore },
            { name: 'WalletPay', path: '/global-admin/tools/wallet', icon: IconWallet },
            { name: 'Comunicação', path: '/global-admin/tools/comms', icon: IconMessage },
            { name: 'Configurações Gerais', path: '/global-admin/settings', icon: IconSettings },
        ]
    }
];

import { IconRepeat } from '../components/icons';

const GlobalAdminLayout: React.FC = () => {
    const { logout, user } = useUser();
    const navigate = useNavigate();
    const location = useLocation();
    const [isSidebarOpen, setSidebarOpen] = useState(true);

    const handleLogout = async () => {
        await logout();
        navigate('/admin-login');
    };

    return (
        <div className="flex h-screen bg-brand-dark font-sans text-brand-text-light overflow-hidden">
            {/* Sidebar */}
            <aside className={`bg-brand-gray border-r border-brand-gray-light flex-shrink-0 flex flex-col transition-all duration-300 ${isSidebarOpen ? 'w-64' : 'w-20'}`}>
                <div className="h-20 flex items-center justify-center border-b border-brand-gray-light">
                    {isSidebarOpen ? (
                        <div className="flex items-center gap-2 text-brand-gold">
                            <span className="font-extrabold text-xl tracking-wider">RS Prólipsi</span>
                        </div>
                    ) : (
                        <span className="font-extrabold text-brand-gold">RS</span>
                    )}
                </div>

                <nav className="flex-1 p-4 space-y-6 overflow-y-auto">
                    {adminGroups.map((group, idx) => (
                        <div key={idx}>
                            {isSidebarOpen && <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 px-3">{group.title}</h3>}
                            <div className="space-y-1">
                                {group.items.map(item => (
                                    <NavLink 
                                        key={item.name} 
                                        to={item.path}
                                        target={item.external ? "_blank" : undefined}
                                        className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 ${isActive && !item.external ? 'bg-brand-gold text-brand-dark font-bold' : 'text-gray-400 hover:bg-brand-gray-light hover:text-white'} ${!isSidebarOpen ? 'justify-center' : ''}`}
                                        title={!isSidebarOpen ? item.name : ''}
                                    >
                                        <item.icon size={20} className="flex-shrink-0" />
                                        {isSidebarOpen && <span>{item.name}</span>}
                                        {item.external && isSidebarOpen && <span className="ml-auto text-xs opacity-50">↗</span>}
                                    </NavLink>
                                ))}
                            </div>
                        </div>
                    ))}
                </nav>

                <div className="p-4 border-t border-brand-gray-light">
                    <button onClick={handleLogout} className={`flex items-center gap-3 w-full px-3 py-2 text-red-400 hover:bg-red-900/20 rounded-lg transition-colors ${!isSidebarOpen ? 'justify-center' : ''}`}>
                        <IconLogOut size={20} className="flex-shrink-0" />
                        {isSidebarOpen && <span className="font-semibold">Sair</span>}
                    </button>
                </div>
            </aside>

            {/* Main Content */}
            <div className="flex-1 flex flex-col overflow-hidden relative">
                {/* Header */}
                <header className="h-16 bg-brand-gray border-b border-brand-gray-light flex items-center justify-between px-6 shadow-md z-10">
                    <div className="flex items-center gap-4">
                        <button onClick={() => setSidebarOpen(!isSidebarOpen)} className="text-gray-400 hover:text-white">
                            <IconMenu size={24} />
                        </button>
                        <h2 className="text-lg font-bold text-white">Painel Administrativo</h2>
                    </div>
                    
                    <div className="flex items-center gap-4 bg-brand-gray-light py-1.5 px-3 rounded-full border border-brand-gray-light">
                        <div className="text-right hidden sm:block">
                            <p className="text-xs font-bold text-white">Admin</p>
                            <p className="text-[10px] text-brand-gold uppercase tracking-wider">Administrador</p>
                        </div>
                        <div className="h-8 w-8 rounded-full bg-brand-gold/20 flex items-center justify-center text-brand-gold border border-brand-gold">
                            <IconShield size={16} />
                        </div>
                    </div>
                </header>

                <main className="flex-1 overflow-y-auto p-6 bg-brand-dark">
                    <div className="max-w-7xl mx-auto">
                        <Outlet />
                    </div>
                </main>
                
                <footer className="py-2 px-6 text-center text-xs text-gray-600 border-t border-brand-gray-light bg-brand-dark">
                    &copy; 2025 RS Prólipsi. Todos os direitos reservados.
                </footer>
            </div>
        </div>
    );
};

export default GlobalAdminLayout;
