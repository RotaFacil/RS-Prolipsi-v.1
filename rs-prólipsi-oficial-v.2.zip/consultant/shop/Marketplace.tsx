
import React from 'react';
import { 
    IconStore, IconChart, IconExternalLink, IconSettings, 
    IconBox, IconTruck, IconUsers, IconWallet, IconBell, IconPlus
} from '../../components/icons';
import Card from '../../components/Card';
import { mockUser, mockShopProducts } from '../data';

const StatCard: React.FC<{ title: string; value: string; icon: React.ElementType; color: string; subtext?: string }> = ({ title, value, icon: Icon, color, subtext }) => (
    <Card className="flex items-center space-x-4 border-l-4" style={{ borderColor: color }}>
        <div className={`p-3 rounded-full bg-opacity-20`} style={{ backgroundColor: color + '33' }}>
            <Icon size={24} style={{ color: color }} />
        </div>
        <div>
            <p className="text-gray-400 text-xs uppercase font-bold">{title}</p>
            <p className="text-2xl font-bold text-white">{value}</p>
            {subtext && <p className="text-xs text-gray-500 mt-1">{subtext}</p>}
        </div>
    </Card>
);

const Marketplace: React.FC = () => {
    // Link para a loja externa (simulado)
    const storeLink = `/#/store/loja-oficial`;

    return (
        <div className="space-y-8 animate-fade-in">
            {/* Header do Painel */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-brand-gray p-6 rounded-xl border border-brand-gray-light shadow-lg">
                <div className="flex items-center gap-4">
                    <div className="bg-brand-gold p-3 rounded-lg text-brand-dark">
                        <IconStore size={32} />
                    </div>
                    <div>
                        <h1 className="text-2xl font-bold text-white">Central do Vendedor</h1>
                        <p className="text-gray-400 text-sm">Gerencie seu inventário, pedidos e desempenho na RS Market.</p>
                    </div>
                </div>
                <div className="flex gap-3">
                    <button className="flex items-center gap-2 bg-brand-gray-light text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors border border-gray-600">
                        <IconSettings size={18} /> Configurações
                    </button>
                    <a 
                        href={storeLink} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 bg-brand-gold text-brand-dark px-6 py-2 rounded-lg font-bold hover:bg-yellow-400 transition-all shadow-lg shadow-brand-gold/20"
                    >
                        <IconExternalLink size={18} /> Visualizar Loja
                    </a>
                </div>
            </div>

            {/* Métricas Principais */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard 
                    title="Vendas (30 dias)" 
                    value="R$ 12.450,00" 
                    icon={IconChart} 
                    color="#10B981" 
                    subtext="+15% vs mês anterior"
                />
                <StatCard 
                    title="Pedidos Pendentes" 
                    value="8" 
                    icon={IconTruck} 
                    color="#F59E0B" 
                    subtext="3 envios atrasados"
                />
                <StatCard 
                    title="Avaliação da Loja" 
                    value="4.8/5" 
                    icon={IconUsers} 
                    color="#3B82F6" 
                    subtext="Baseado em 142 reviews"
                />
                <StatCard 
                    title="Saldo Disponível" 
                    value="R$ 4.850,00" 
                    icon={IconWallet} 
                    color="#FFD700" 
                    subtext="Próximo repasse: 15/02"
                />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Coluna Principal: Inventário */}
                <div className="lg:col-span-2 space-y-6">
                    <Card>
                        <div className="flex justify-between items-center mb-6">
                            <h2 className="text-xl font-bold text-white flex items-center gap-2"><IconBox/> Inventário Ativo</h2>
                            <button className="text-sm bg-brand-gold text-brand-dark px-3 py-1 rounded font-bold hover:bg-white flex items-center gap-1">
                                <IconPlus size={14}/> Adicionar Produto
                            </button>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full text-left">
                                <thead className="bg-brand-gray-light text-xs font-bold text-gray-400 uppercase">
                                    <tr>
                                        <th className="p-3 rounded-l-lg">Produto</th>
                                        <th className="p-3 text-right">Preço</th>
                                        <th className="p-3 text-center">Estoque</th>
                                        <th className="p-3 text-center">Status</th>
                                        <th className="p-3 rounded-r-lg text-right">Ação</th>
                                    </tr>
                                </thead>
                                <tbody className="text-sm">
                                    {mockShopProducts.slice(0, 5).map(product => (
                                        <tr key={product.id} className="border-b border-brand-gray-light hover:bg-brand-gray-light/30">
                                            <td className="p-3">
                                                <div className="flex items-center gap-3">
                                                    <img src={product.imageUrl} alt="" className="w-10 h-10 object-cover rounded bg-white" />
                                                    <span className="font-semibold text-white line-clamp-1">{product.name}</span>
                                                </div>
                                            </td>
                                            <td className="p-3 text-right text-gray-300">R$ {product.price.toFixed(2)}</td>
                                            <td className="p-3 text-center text-white">45</td>
                                            <td className="p-3 text-center"><span className="bg-green-500/20 text-green-400 px-2 py-1 rounded text-xs font-bold">ATIVO</span></td>
                                            <td className="p-3 text-right"><button className="text-brand-gold hover:text-white">Editar</button></td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </Card>
                </div>

                {/* Coluna Lateral: Atalhos e Avisos */}
                <div className="space-y-6">
                    <Card className="bg-gradient-to-br from-brand-gray to-brand-gray-dark border border-brand-gold/30">
                        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                            <IconBell className="text-brand-gold"/> Saúde da Conta
                        </h3>
                        <div className="space-y-3">
                            <div className="bg-brand-gray-light p-3 rounded-lg border-l-4 border-green-500">
                                <p className="text-xs text-gray-400 mb-1">Índice de Pedidos Perfeitos</p>
                                <p className="text-sm text-white font-bold">98.5% (Excelente)</p>
                            </div>
                            <div className="bg-brand-gray-light p-3 rounded-lg border-l-4 border-yellow-500">
                                <p className="text-xs text-gray-400 mb-1">Envios Atrasados</p>
                                <p className="text-sm text-white font-bold">2.1% (Atenção)</p>
                            </div>
                        </div>
                    </Card>

                    <Card>
                        <h3 className="text-lg font-bold text-white mb-4">Ferramentas de Venda</h3>
                        <div className="grid grid-cols-1 gap-3">
                            <button className="flex items-center gap-3 p-3 bg-brand-gray-light rounded-lg hover:bg-brand-gray border border-gray-700 hover:border-brand-gold transition-all text-left group">
                                <div className="bg-blue-500/20 p-2 rounded text-blue-400"><IconChart size={20}/></div>
                                <div>
                                    <span className="block text-white font-bold text-sm">Campanhas de Ads</span>
                                    <span className="text-xs text-gray-500">Impulsione seus produtos</span>
                                </div>
                            </button>
                            <button className="flex items-center gap-3 p-3 bg-brand-gray-light rounded-lg hover:bg-brand-gray border border-gray-700 hover:border-brand-gold transition-all text-left group">
                                <div className="bg-purple-500/20 p-2 rounded text-purple-400"><IconBox size={20}/></div>
                                <div>
                                    <span className="block text-white font-bold text-sm">Logística RS Prime</span>
                                    <span className="text-xs text-gray-500">Gerenciar envios FBA</span>
                                </div>
                            </button>
                        </div>
                    </Card>
                </div>
            </div>
        </div>
    );
};

export default Marketplace;
