
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../../components/Card';
import { 
    IconStore, IconChevronLeft, IconChevronRight, IconCheckCircle, 
    IconSparkles, IconLayout, IconPalette, IconBox, IconGlobe,
    IconShoppingCart
} from '../../components/icons';
import { useUser } from '../ConsultantLayout';
import { GoogleGenAI } from "@google/genai";
import { mockStoreConfig, mockShopProducts } from '../data';

const StoreSetupWizard: React.FC = () => {
    const { user } = useUser();
    const navigate = useNavigate();
    const [step, setStep] = useState(1);
    const [isGenerating, setIsGenerating] = useState(false);
    
    const [config, setConfig] = useState({
        ...mockStoreConfig,
        storeName: `${user.name} Store`,
        slug: user.name.toLowerCase().replace(/\s+/g, '-'),
        products: mockShopProducts.slice(0, 4).map(p => p.id) // Pré-seleciona alguns
    });

    const nextStep = () => setStep(prev => Math.min(prev + 1, 5));
    const prevStep = () => setStep(prev => Math.max(prev - 1, 1));

    const handleFinish = () => {
        localStorage.setItem('userStoreConfig', JSON.stringify({ ...config, isActive: true }));
        navigate('/consultant/shop/vitrine');
    };

    const generateWithIA = async () => {
        setIsGenerating(true);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const prompt = `Como um Designer de Elite, sugira:
            1. Um nome de loja luxuoso para o consultor "${user.name}".
            2. Um título (headline) magnético para o topo do site.
            3. Um subtítulo persuasivo focado em resultados.
            Retorne APENAS um JSON: {"storeName": "...", "heroHeadline": "...", "heroSubheadline": "..."}`;
            
            const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: prompt,
                config: { responseMimeType: "application/json" }
            });

            const result = JSON.parse(response.text);
            setConfig(prev => ({ ...prev, ...result }));
            nextStep();
        } catch (e) {
            console.error(e);
            nextStep(); // Prossegue mesmo com erro para não travar o usuário
        } finally {
            setIsGenerating(false);
        }
    };

    return (
        <div className="max-w-4xl mx-auto py-10 animate-fade-in">
            {/* Stepper */}
            <div className="mb-12">
                <div className="flex justify-between mb-4">
                    {[1, 2, 3, 4, 5].map(s => (
                        <div 
                            key={s} 
                            className={`h-1.5 flex-1 mx-1 rounded-full transition-all duration-700 ${s <= step ? 'bg-[#39FF14] shadow-[0_0_10px_rgba(57,255,20,0.5)]' : 'bg-brand-gray-light'}`}
                        />
                    ))}
                </div>
                <p className="text-center text-[10px] font-black uppercase tracking-[0.2em] text-gray-500">
                    ETAPA {step} DE 5 • {
                        step === 1 ? 'INTELIGÊNCIA CRIATIVA' :
                        step === 2 ? 'IDENTIDADE ÚNICA' :
                        step === 3 ? 'ESTILO VISUAL' :
                        step === 4 ? 'CATÁLOGO INICIAL' : 'PRONTO PARA O SUCESSO'
                    }
                </p>
            </div>

            <Card className="p-8 md:p-12 min-h-[550px] flex flex-col relative overflow-hidden bg-brand-gray border-white/5">
                {/* Background Decor */}
                <div className="absolute -top-24 -right-24 w-64 h-64 bg-[#39FF14]/5 rounded-full blur-3xl"></div>

                {/* PASSO 1: IA STARTER */}
                {step === 1 && (
                    <div className="flex-1 flex flex-col items-center justify-center text-center space-y-8 animate-fade-in">
                        <div className="bg-[#39FF14]/10 p-6 rounded-3xl text-[#39FF14] animate-pulse">
                            <IconSparkles size={64} />
                        </div>
                        <div className="space-y-3">
                            <h2 className="text-3xl font-black text-white italic uppercase tracking-tighter">Quer uma ajudinha da RSIA?</h2>
                            <p className="text-gray-400 max-w-md">
                                Nossa Inteligência Artificial pode analisar seu perfil e sugerir os nomes e textos mais lucrativos para sua nova vitrine.
                            </p>
                        </div>
                        <div className="w-full max-w-sm space-y-3">
                            <button 
                                onClick={generateWithIA}
                                disabled={isGenerating}
                                className="w-full bg-[#39FF14] text-black font-black py-5 rounded-2xl flex items-center justify-center gap-3 hover:scale-105 transition-all shadow-xl"
                            >
                                {isGenerating ? 'PROCESSANDO...' : <><IconSparkles /> CONFIGURAR COM IA</>}
                            </button>
                            <button onClick={nextStep} className="w-full text-gray-500 text-xs font-black uppercase tracking-widest hover:text-white transition-colors">
                                QUERO CONFIGURAR MANUALMENTE
                            </button>
                        </div>
                    </div>
                )}

                {/* PASSO 2: IDENTIDADE */}
                {step === 2 && (
                    <div className="flex-1 space-y-8 animate-fade-in">
                        <div className="space-y-2">
                            <h2 className="text-3xl font-black text-white italic uppercase tracking-tighter">Sua Marca Online</h2>
                            <p className="text-gray-400">Como os clientes vão conhecer sua loja?</p>
                        </div>
                        <div className="space-y-6">
                            <div className="group">
                                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest block mb-2 group-focus-within:text-[#39FF14] transition-colors">Nome da Vitrine</label>
                                <input 
                                    type="text" 
                                    autoFocus
                                    value={config.storeName}
                                    onChange={e => setConfig({ ...config, storeName: e.target.value })}
                                    className="w-full bg-black/40 border border-white/10 p-5 rounded-2xl text-white focus:border-[#39FF14] outline-none text-xl font-bold transition-all"
                                />
                            </div>
                            <div>
                                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest block mb-2">Seu Endereço de Venda</label>
                                <div className="flex items-center bg-black/40 border border-white/10 rounded-2xl overflow-hidden focus-within:border-[#39FF14] transition-all">
                                    <span className="px-5 text-gray-500 text-sm font-mono border-r border-white/5">rsprolipsi.com/</span>
                                    <input 
                                        type="text" 
                                        value={config.slug}
                                        onChange={e => setConfig({ ...config, slug: e.target.value.toLowerCase().replace(/\s+/g, '-') })}
                                        className="flex-1 bg-transparent p-5 text-white outline-none font-bold font-mono"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* PASSO 3: DESIGN */}
                {step === 3 && (
                    <div className="flex-1 space-y-8 animate-fade-in">
                        <div className="space-y-2">
                            <h2 className="text-3xl font-black text-white italic uppercase tracking-tighter">Identidade Visual</h2>
                            <p className="text-gray-400">Escolha o template que melhor combina com seu público.</p>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            {['amazon-pro', 'minimalist', 'boutique'].map(t => (
                                <button 
                                    key={t} 
                                    onClick={() => setConfig({ ...config, template: t as any })}
                                    className={`p-4 rounded-2xl border-2 transition-all text-left relative overflow-hidden ${config.template === t ? 'border-[#39FF14] bg-[#39FF14]/5' : 'border-white/5 bg-black/20 hover:border-white/20'}`}
                                >
                                    <div className="aspect-video bg-white/5 rounded-lg mb-4 flex items-center justify-center">
                                        <IconLayout className={config.template === t ? 'text-[#39FF14]' : 'text-gray-700'} />
                                    </div>
                                    <h3 className="font-bold text-white uppercase text-xs tracking-widest">{t.replace('-', ' ')}</h3>
                                    {config.template === t && <IconCheckCircle className="absolute top-4 right-4 text-[#39FF14]" size={16} />}
                                </button>
                            ))}
                        </div>
                        <div className="flex items-center gap-6 p-4 bg-black/20 rounded-2xl border border-white/5">
                            <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Sua Cor Principal:</label>
                            <div className="flex items-center gap-3">
                                <input type="color" value={config.primaryColor} onChange={e => setConfig({ ...config, primaryColor: e.target.value })} className="h-10 w-10 border-none bg-transparent cursor-pointer rounded-full" />
                                <span className="font-mono text-sm text-gray-400">{config.primaryColor}</span>
                            </div>
                        </div>
                    </div>
                )}

                {/* PASSO 4: PRODUTOS */}
                {step === 4 && (
                    <div className="flex-1 space-y-6 animate-fade-in">
                        <div className="space-y-2">
                            <h2 className="text-3xl font-black text-white italic uppercase tracking-tighter">Abastecer Vitrine</h2>
                            <p className="text-gray-400">Selecione os produtos que quer exibir inicialmente.</p>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-h-[350px] overflow-y-auto pr-2 custom-scrollbar">
                            {mockShopProducts.map(p => {
                                const isSelected = config.products.includes(p.id);
                                return (
                                    <div 
                                        key={p.id} 
                                        onClick={() => {
                                            const newProds = isSelected ? config.products.filter(id => id !== p.id) : [...config.products, p.id];
                                            setConfig({...config, products: newProds});
                                        }}
                                        className={`relative p-2 rounded-2xl border-2 transition-all cursor-pointer ${isSelected ? 'border-[#39FF14] bg-[#39FF14]/5' : 'border-white/5 bg-black/20'}`}
                                    >
                                        <img src={p.imageUrl} className="w-full aspect-square object-cover rounded-xl mb-2 grayscale-[0.5] group-hover:grayscale-0" />
                                        <p className="text-[10px] font-bold text-white line-clamp-1 text-center">{p.name}</p>
                                        {isSelected && (
                                            <div className="absolute top-2 right-2 bg-[#39FF14] rounded-full p-1 shadow-lg">
                                                <IconCheckCircle size={12} className="text-black" />
                                            </div>
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )}

                {/* PASSO 5: SUCESSO */}
                {step === 5 && (
                    <div className="flex-1 flex flex-col items-center justify-center text-center space-y-8 animate-fade-in">
                        <div className="text-[#39FF14] bg-[#39FF14]/10 p-8 rounded-full border border-[#39FF14]/20 animate-bounce">
                            <IconCheckCircle size={80} />
                        </div>
                        <div className="space-y-2">
                            <h2 className="text-4xl font-black text-white italic uppercase tracking-tighter">Vitrine Sincronizada!</h2>
                            <p className="text-gray-400">Seu e-commerce está no ar e pronto para receber pedidos.</p>
                        </div>
                        <div className="bg-black/40 p-6 rounded-3xl border border-white/10 w-full max-w-sm text-left space-y-3">
                            <p className="text-[10px] font-black uppercase text-gray-600 tracking-widest">Resumo da Configuração</p>
                            <div className="space-y-1 text-sm font-bold">
                                <p className="text-white flex justify-between"><span>Nome:</span> <span className="text-[#39FF14]">{config.storeName}</span></p>
                                <p className="text-white flex justify-between"><span>Endereço:</span> <span className="text-brand-gold">{config.slug}</span></p>
                                <p className="text-white flex justify-between"><span>Catálogo:</span> <span>{config.products.length} produtos</span></p>
                            </div>
                        </div>
                    </div>
                )}

                {/* Footer do Wizard */}
                <div className="mt-auto pt-8 flex justify-between items-center border-t border-white/5">
                    {step > 1 && step < 5 ? (
                        <button onClick={prevStep} className="flex items-center gap-2 text-gray-500 font-black uppercase text-[10px] tracking-widest hover:text-white transition-colors">
                            <IconChevronLeft size={16}/> Voltar
                        </button>
                    ) : <div />}

                    {step === 5 ? (
                        <button onClick={handleFinish} className="bg-[#39FF14] text-black font-black px-12 py-5 rounded-2xl text-xl uppercase tracking-tighter hover:scale-105 transition-all shadow-[0_0_30px_rgba(57,255,20,0.3)]">
                            LANÇAR MINHA VITRINE
                        </button>
                    ) : (
                        <button 
                            onClick={nextStep} 
                            disabled={step === 4 && config.products.length === 0}
                            className="bg-brand-gold text-brand-dark font-black px-8 py-3 rounded-xl flex items-center gap-2 hover:bg-white transition-all disabled:opacity-30"
                        >
                            PRÓXIMO PASSO <IconChevronRight size={20}/>
                        </button>
                    )}
                </div>
            </Card>

            <style>{`
                .custom-scrollbar::-webkit-scrollbar { width: 4px; }
                .custom-scrollbar::-webkit-scrollbar-thumb { background: #333; border-radius: 10px; }
                @keyframes fade-in { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
                .animate-fade-in { animation: fade-in 0.5s ease-out forwards; }
            `}</style>
        </div>
    );
};

export default StoreSetupWizard;
