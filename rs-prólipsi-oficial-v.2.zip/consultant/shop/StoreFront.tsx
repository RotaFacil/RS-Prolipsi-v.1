
import React, { useMemo, useState } from "react";
import { 
  IconShoppingCart, IconSearch, IconCreditCard, IconBox, 
  IconCheckCircle, IconUser, IconHeart, IconChevronLeft, 
  IconChevronRight, IconTrash, IconPlus, IconMinus,
  IconFacebook, IconYoutube, IconInstagram, IconTruck, IconShield,
  IconRepeat
} from "../../components/icons";
import Modal from "../../components/Modal";

// Tipos alinhados ao seu prompt MVP
interface Product {
  id: string;
  slug: string;
  title: string;
  description: string;
  priceCents: number;
  image: string;
  category: string;
  stock: number;
  featured?: boolean;
  onSale?: boolean;
  bestSeller?: boolean;
}

interface CartItem { product: Product; qty: number }

// Mock – utilizando os dados exatos que você enviou
const MOCK_PRODUCTS: Product[] = [
  {
    id: "p1",
    slug: "relogio-classico",
    title: "Relógio de Pulso Clássico de Couro",
    description: "Design atemporal com funcionalidade moderna.",
    priceCents: 125000,
    image: "https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=800&q=80",
    category: "Acessórios",
    stock: 24,
    featured: true,
    onSale: true,
    bestSeller: true,
  },
  {
    id: "p2",
    slug: "bolsa-design",
    title: "Bolsa de Ombro de Design",
    description: "Acabamento premium, ideal para o dia a dia.",
    priceCents: 210000,
    image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&q=80",
    category: "Moda",
    stock: 18,
    featured: true,
    bestSeller: true,
  },
  {
    id: "p3",
    slug: "caneta-executiva",
    title: "Caneta-tinteiro Executiva",
    description: "Escrita suave e construção em metal.",
    priceCents: 85000,
    image: "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?w=800&q=80",
    category: "Escritório",
    stock: 70,
    onSale: true,
  },
  {
    id: "p4",
    slug: "quadro-minimalista",
    title: "Quadro Decorativo Minimalista",
    description: "Tinta sobre tela, 60x80cm.",
    priceCents: 159000,
    image: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=800&q=80",
    category: "Casa & Decoração",
    stock: 32,
    featured: true,
  },
];

const fmtBRL = (c: number) => new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(c / 100);

export default function StoreFront() {
  const [query, setQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [items, setItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState<'shipping' | 'payment' | 'success' | null>(null);

  const categories = useMemo(() => Array.from(new Set(MOCK_PRODUCTS.map(p => p.category))), []);

  const filtered = useMemo(() =>
    MOCK_PRODUCTS.filter(p =>
      (selectedCategory ? p.category === selectedCategory : true) &&
      (query ? (p.title + p.description).toLowerCase().includes(query.toLowerCase()) : true)
    ), [query, selectedCategory]
  );

  const featured = MOCK_PRODUCTS.filter(p => p.featured);
  const onSale = MOCK_PRODUCTS.filter(p => p.onSale);
  const bestSellers = MOCK_PRODUCTS.filter(p => p.bestSeller);

  function addToCart(product: Product) {
    setItems((prev) => {
      const idx = prev.findIndex(i => i.product.id === product.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = { ...next[idx], qty: next[idx].qty + 1 };
        return next;
      }
      return [...prev, { product, qty: 1 }];
    });
    setIsCartOpen(true);
  }

  const subtotal = items.reduce((acc, it) => acc + it.product.priceCents * it.qty, 0);
  const total = subtotal + (items.length ? 1990 : 0);

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 font-sans selection:bg-yellow-400 selection:text-black">
      {/* Navbar - Visual de Luxo */}
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-neutral-900/80 border-b border-neutral-800">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-8">
            <span 
              className="text-yellow-400 font-black text-2xl tracking-tighter italic uppercase cursor-pointer" 
              onClick={() => { setSelectedCategory(null); setQuery(""); }}
            >
              RS Prólipsi
            </span>
            <nav className="hidden lg:flex items-center gap-6 text-[10px] font-black uppercase tracking-widest text-neutral-400">
              <button onClick={() => setSelectedCategory(null)} className="hover:text-white transition-colors">Início</button>
              <div className="relative group">
                <button className="hover:text-white transition-colors flex items-center gap-1">Categorias</button>
                <div className="absolute top-full left-0 mt-2 w-48 bg-neutral-900 border border-neutral-800 rounded-xl shadow-2xl py-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                  {categories.map(c => (
                    <button key={c} onClick={() => setSelectedCategory(c)} className="w-full text-left px-4 py-2 hover:bg-neutral-800 hover:text-yellow-400 transition-colors">
                      {c}
                    </button>
                  ))}
                </div>
              </div>
              <button className="hover:text-white transition-colors">Ofertas</button>
            </nav>
          </div>

          <div className="flex-1 max-w-md relative hidden md:block">
            <IconSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
            <input
              type="text"
              placeholder="O que você está buscando hoje?"
              value={query}
              onChange={e => setQuery(e.target.value)}
              className="w-full bg-neutral-800 border border-neutral-700 rounded-full py-2.5 pl-10 pr-4 text-sm focus:border-yellow-400 outline-none transition-all"
            />
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 text-neutral-400 hover:text-white transition-colors"><IconUser size={22}/></button>
            <button 
                onClick={() => setIsCartOpen(true)} 
                className="relative p-2 bg-neutral-800 rounded-full border border-neutral-700 hover:bg-neutral-700 transition-all group"
            >
              <IconShoppingCart size={22} className="group-hover:scale-110 transition-transform" />
              {items.length > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-lime-400 text-black text-[10px] font-black rounded-full flex items-center justify-center animate-bounce">
                  {items.reduce((a, b) => a + b.qty, 0)}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section - Elegância Redefinida */}
      {!selectedCategory && !query && (
        <section className="relative h-[65vh] flex items-center bg-neutral-900 border-b border-neutral-800 overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-2 items-center gap-12 relative z-10">
            <div className="space-y-6 animate-fade-in-up">
              <span className="bg-lime-400 text-black font-black uppercase tracking-widest px-3 py-1 text-[10px] rounded-full shadow-lg shadow-lime-400/20">Marketplace de Elite</span>
              <h1 className="text-5xl md:text-8xl font-black tracking-tight uppercase italic leading-[0.85]">
                Elegância, <br/> <span className="text-yellow-400">Redefinida.</span>
              </h1>
              <p className="text-lg text-neutral-400 max-w-lg leading-relaxed">
                Descubra um mercado selecionado de produtos premium de vendedores confiáveis. Sua jornada para o luxo começa agora.
              </p>
              <div className="flex flex-wrap gap-4 pt-4">
                <button className="bg-lime-400 text-black font-black px-10 py-5 rounded-2xl uppercase tracking-tighter hover:scale-105 transition-all shadow-xl shadow-lime-400/30">
                  Explorar Catálogo
                </button>
                <button className="bg-neutral-800 text-white font-bold px-10 py-5 rounded-2xl border border-neutral-700 hover:bg-neutral-700 transition-all">
                  Ver Ofertas
                </button>
              </div>
            </div>
            <div className="hidden md:block relative group animate-fade-in">
              <div className="aspect-[4/3] rounded-[3rem] bg-gradient-to-br from-neutral-800 to-neutral-950 border border-neutral-700 overflow-hidden shadow-2xl relative">
                <img src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?q=80&w=2070" className="w-full h-full object-cover opacity-50 group-hover:scale-110 transition-transform duration-[2000ms]" alt="Visual Luxo" />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent"></div>
              </div>
              {/* Floating Badge */}
              <div className="absolute -bottom-6 -left-6 bg-brand-gray border border-neutral-700 p-6 rounded-[2rem] shadow-2xl animate-bounce">
                <IconShield size={32} className="text-yellow-400"/>
              </div>
            </div>
          </div>
          {/* Background Gradient */}
          <div className="absolute top-0 right-0 w-1/2 h-full bg-yellow-400/5 blur-[150px] -mr-40 rounded-full"></div>
        </section>
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-20 space-y-32">
        
        {selectedCategory || query ? (
            <section className="animate-fade-in">
                <h2 className="text-4xl font-black uppercase italic tracking-tighter mb-12 flex items-center gap-4">
                    Resultados para: <span className="text-yellow-400 px-4 py-2 bg-yellow-400/10 rounded-xl border border-yellow-400/20">{selectedCategory || query}</span>
                </h2>
                <ProductGrid products={filtered} onAdd={addToCart} />
            </section>
        ) : (
            <>
                {/* Destaques */}
                <section>
                    <div className="mb-12 flex justify-between items-end">
                        <div>
                            <h2 className="text-4xl font-black uppercase italic tracking-tighter">Produtos em Destaque</h2>
                            <p className="text-neutral-400 mt-2 text-lg">A mais alta qualidade, selecionada por especialistas.</p>
                        </div>
                        <button className="text-yellow-400 font-black uppercase tracking-widest text-[10px] hover:underline">Ver tudo</button>
                    </div>
                    <ProductGrid products={featured} onAdd={addToCart} />
                </section>

                {/* Ofertas - Layout Diferenciado */}
                <section className="bg-neutral-900/50 -mx-4 px-4 py-24 rounded-[4rem] border border-neutral-800 shadow-inner relative overflow-hidden">
                    <div className="max-w-7xl mx-auto relative z-10">
                        <div className="mb-12">
                            <h2 className="text-4xl font-black uppercase italic tracking-tighter text-yellow-400">Ofertas de Temporada</h2>
                            <p className="text-neutral-400 mt-2 text-lg">Aproveite descontos exclusivos por tempo limitado.</p>
                        </div>
                        <ProductGrid products={onSale} onAdd={addToCart} />
                    </div>
                    {/* Background Decor */}
                    <div className="absolute bottom-0 left-0 w-64 h-64 bg-lime-400/5 blur-[100px] rounded-full"></div>
                </section>

                {/* Mais Vendidos */}
                <section>
                    <div className="mb-12">
                        <h2 className="text-4xl font-black uppercase italic tracking-tighter">Mais Vendidos</h2>
                        <p className="text-neutral-400 mt-2 text-lg">Os favoritos da nossa comunidade global.</p>
                    </div>
                    <ProductGrid products={bestSellers} onAdd={addToCart} />
                </section>
            </>
        )}

        {/* Call to Action: Seja um Lojista */}
        <section className="rounded-[4rem] overflow-hidden border border-yellow-500/20 bg-neutral-900 group relative">
          <div className="grid md:grid-cols-2 items-center">
            <div className="p-16 space-y-8 relative z-10">
              <h2 className="text-5xl font-black uppercase italic tracking-tighter leading-[0.9]">
                Seja um <br/> <span className="text-yellow-400">Lojista Parceiro</span>
              </h2>
              <p className="text-neutral-300 text-lg leading-relaxed">
                Transforme sua visão em lucro. Junte-se ao nosso marketplace, alcance milhões e escale seu negócio com tecnologia RS Prólipsi de ponta.
              </p>
              <button className="bg-lime-400 text-black font-black px-12 py-5 rounded-2xl uppercase tracking-tighter shadow-xl hover:scale-105 transition-all">
                Começar a Vender
              </button>
            </div>
            <div className="h-full min-h-[450px] relative overflow-hidden">
                <img 
                    src="https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?q=80&w=2070" 
                    className="absolute inset-0 w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-1000"
                    alt="Lojista"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-neutral-900 via-neutral-900/20 to-transparent"></div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer Profissional */}
      <footer className="border-t border-neutral-800 py-24 bg-neutral-900/30">
        <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-4 gap-16">
          <div className="space-y-6">
            <span className="text-yellow-400 font-black text-3xl tracking-tighter italic uppercase">RS Prólipsi</span>
            <p className="text-sm text-neutral-500 leading-relaxed font-medium">O futuro do e-commerce premium. Combinamos curadoria artística com logística de escala global.</p>
            <div className="flex gap-6 text-neutral-500">
              <IconFacebook size={24} className="hover:text-white cursor-pointer transition-colors" />
              <IconInstagram size={24} className="hover:text-white cursor-pointer transition-colors" />
              <IconYoutube size={24} className="hover:text-white cursor-pointer transition-colors" />
            </div>
          </div>
          <div>
            <h4 className="font-black uppercase tracking-[0.2em] text-[11px] text-neutral-500 mb-8">Compradores</h4>
            <ul className="space-y-4 text-sm text-neutral-400">
              <li className="hover:text-yellow-400 cursor-pointer transition-colors">Produtos Físicos</li>
              <li className="hover:text-yellow-400 cursor-pointer transition-colors">Minha Conta</li>
              <li className="hover:text-yellow-400 cursor-pointer transition-colors">Rastrear Pedido</li>
              <li className="hover:text-yellow-400 cursor-pointer transition-colors">Política de Devolução</li>
            </ul>
          </div>
          <div>
            <h4 className="font-black uppercase tracking-[0.2em] text-[11px] text-neutral-500 mb-8">Ecossistema</h4>
            <ul className="space-y-4 text-sm text-neutral-400">
              <li className="hover:text-yellow-400 cursor-pointer transition-colors">Painel do Consultor</li>
              <li className="hover:text-yellow-400 cursor-pointer transition-colors">Dropshipping RS</li>
              <li className="hover:text-yellow-400 cursor-pointer transition-colors">Seja um Afiliado</li>
              <li className="hover:text-yellow-400 cursor-pointer transition-colors">Suporte 24/7</li>
            </ul>
          </div>
          <div>
            <h4 className="font-black uppercase tracking-[0.2em] text-[11px] text-neutral-500 mb-8">Informações</h4>
            <address className="not-italic space-y-4 text-sm text-neutral-500">
              <p>Rua Exemplo, 1000 - SP/Brasil</p>
              <p className="text-white font-bold">contato@rsprolipsi.com.br</p>
              <p>CNPJ: 00.000.000/0001-00</p>
            </address>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 mt-20 pt-8 border-t border-neutral-800 text-center text-xs text-neutral-600 font-bold uppercase tracking-[0.1em]">
            © {new Date().getFullYear()} RS Prólipsi Oficial. Todos os Direitos Reservados.
        </div>
      </footer>

      {/* Modais de Checkout e Carrinho */}
      <Modal isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} title="Sua Sacola" className="max-w-md h-full fixed right-0 top-0 m-0 rounded-none border-l border-neutral-800 bg-neutral-900">
        <div className="flex flex-col h-full">
          <div className="flex-1 overflow-y-auto custom-scroll pr-2">
            {items.length === 0 ? (
                <div className="text-center py-24 opacity-10">
                    <IconShoppingCart size={120} className="mx-auto" />
                    <p className="font-black uppercase text-xs mt-6 tracking-widest">Sua sacola está vazia</p>
                </div>
            ) : items.map((it) => (
              <div key={it.product.id} className="flex gap-4 py-6 border-b border-neutral-800 group animate-fade-in">
                <div className="w-24 h-24 bg-white rounded-2xl overflow-hidden p-2 flex-shrink-0">
                    <img src={it.product.image} className="w-full h-full object-contain" alt="" />
                </div>
                <div className="flex-1 space-y-2">
                  <div className="flex justify-between items-start">
                    <h4 className="font-bold text-sm leading-tight text-white uppercase italic tracking-tighter">{it.product.title}</h4>
                    <button className="text-neutral-600 hover:text-red-500 transition-colors" onClick={() => setItems(c => c.filter(x => x.product.id !== it.product.id))}>
                      <IconTrash size={16}/>
                    </button>
                  </div>
                  <p className="text-yellow-400 font-black text-lg">{fmtBRL(it.product.priceCents)}</p>
                  <div className="flex items-center gap-4 pt-2">
                    <div className="flex items-center bg-neutral-800 rounded-lg p-1 border border-neutral-700">
                        <button onClick={() => {}} className="p-1 text-neutral-400 hover:text-white"><IconMinus size={14}/></button>
                        <span className="text-xs font-black w-8 text-center">{it.qty}</span>
                        <button onClick={() => {}} className="p-1 text-neutral-400 hover:text-white"><IconPlus size={14}/></button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {items.length > 0 && (
            <div className="pt-8 border-t border-neutral-800 space-y-6">
              <div className="space-y-2 text-sm text-neutral-500 font-bold uppercase tracking-widest">
                  <div className="flex justify-between"><span>Subtotal</span><span className="text-white">{fmtBRL(subtotal)}</span></div>
                  <div className="flex justify-between"><span>Frete Prime</span><span className="text-lime-400">R$ 19,90</span></div>
              </div>
              <div className="flex justify-between text-3xl font-black italic tracking-tighter pt-2 border-t border-neutral-800/50">
                <span>TOTAL</span>
                <span className="text-yellow-400">{fmtBRL(total)}</span>
              </div>
              <button onClick={() => setCheckoutStep('shipping')} className="w-full bg-lime-400 text-black font-black py-6 rounded-[2rem] uppercase tracking-tighter hover:bg-white hover:scale-[1.02] active:scale-95 transition-all shadow-2xl shadow-lime-400/20">
                Finalizar Pedido
              </button>
            </div>
          )}
        </div>
      </Modal>

      <Modal isOpen={!!checkoutStep} onClose={() => setCheckoutStep(null)} title="Finalizar Compra" className="max-w-xl bg-neutral-900 border-neutral-800">
           {checkoutStep === 'shipping' && (
                <div className="space-y-8 animate-fade-in-up">
                    <div className="grid gap-6">
                        <div><label className="text-[10px] font-black text-neutral-500 uppercase tracking-widest mb-2 block">Nome Completo</label><input type="text" className="w-full bg-neutral-800 border border-neutral-700 p-4 rounded-2xl outline-none focus:border-yellow-400 transition-all" placeholder="Como no documento..." /></div>
                        <div className="grid grid-cols-2 gap-4">
                            <div><label className="text-[10px] font-black text-neutral-500 uppercase tracking-widest mb-2 block">E-mail</label><input type="email" className="w-full bg-neutral-800 border border-neutral-700 p-4 rounded-2xl outline-none focus:border-yellow-400 transition-all" /></div>
                            <div><label className="text-[10px] font-black text-neutral-500 uppercase tracking-widest mb-2 block">WhatsApp</label><input type="tel" className="w-full bg-neutral-800 border border-neutral-700 p-4 rounded-2xl outline-none focus:border-yellow-400 transition-all" /></div>
                        </div>
                    </div>
                    <div className="p-6 bg-brand-gold/5 rounded-3xl border border-brand-gold/20 flex items-center gap-4">
                        <IconTruck className="text-brand-gold" size={32}/>
                        <div>
                            <p className="font-black text-white text-sm uppercase italic tracking-tighter">RS Express selecionado</p>
                            <p className="text-neutral-500 text-xs font-medium">Entrega prioritária para o seu endereço.</p>
                        </div>
                    </div>
                    <button onClick={() => setCheckoutStep('payment')} className="w-full bg-yellow-400 text-black font-black py-5 rounded-[2rem] uppercase tracking-tighter hover:bg-white transition-all shadow-xl shadow-yellow-400/10">Continuar para Pagamento</button>
                </div>
           )}

           {checkoutStep === 'payment' && (
                <div className="space-y-8 animate-fade-in-up">
                    <div className="grid grid-cols-2 gap-4">
                        <button className="p-8 rounded-[2rem] border-2 border-yellow-400 bg-yellow-400/5 flex flex-col items-center gap-4 transition-all">
                            <IconCreditCard size={32} className="text-yellow-400"/>
                            <span className="font-black uppercase tracking-widest text-[10px]">Cartão</span>
                        </button>
                        <button className="p-8 rounded-[2rem] border-2 border-neutral-800 bg-neutral-800/50 flex flex-col items-center gap-4 text-neutral-500 hover:border-yellow-400/50 hover:text-yellow-400 transition-all">
                            <IconRepeat size={32}/>
                            <span className="font-black uppercase tracking-widest text-[10px]">PIX Instantâneo</span>
                        </button>
                    </div>
                    <button onClick={() => setCheckoutStep('success')} className="w-full bg-lime-400 text-black font-black py-6 rounded-[2rem] uppercase tracking-tighter shadow-2xl">Confirmar e Pagar {fmtBRL(total)}</button>
                </div>
           )}

           {checkoutStep === 'success' && (
                <div className="text-center py-16 space-y-8 animate-fade-in-up">
                    <div className="w-24 h-24 bg-lime-400/20 text-lime-400 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                        <IconCheckCircle size={56} />
                    </div>
                    <div>
                        <h2 className="text-4xl font-black uppercase italic tracking-tighter leading-none">Pedido <br/> Confirmado!</h2>
                        <p className="text-neutral-500 mt-4 text-sm font-medium">Preparamos tudo com exclusividade. Você receberá o código de rastreio em breve no seu e-mail.</p>
                    </div>
                    <button onClick={() => { setCheckoutStep(null); setItems([]); setIsCartOpen(false); }} className="w-full bg-neutral-800 text-white font-black py-5 rounded-[2rem] uppercase tracking-widest text-xs hover:bg-neutral-700 transition-all">Voltar ao Catálogo</button>
                </div>
           )}
      </Modal>

      <style>{`
        .custom-scroll::-webkit-scrollbar { width: 4px; }
        .custom-scroll::-webkit-scrollbar-track { background: transparent; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #333; border-radius: 10px; }
        .animate-fade-in-up { animation: fade-in-up 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        @keyframes fade-in-up { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </div>
  );
}

function ProductGrid({ products, onAdd }: { products: Product[], onAdd: (p: Product) => void }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
      {products.map(p => (
        <div key={p.id} className="group relative flex flex-col animate-fade-in">
          {/* Card Image */}
          <div className="aspect-[4/5] bg-white rounded-[2.5rem] overflow-hidden relative shadow-2xl transition-all duration-700 group-hover:-translate-y-2 group-hover:shadow-yellow-400/5">
            <img src={p.image} className="w-full h-full object-contain p-8 group-hover:scale-110 transition-transform duration-1000" alt={p.title} />
            {p.onSale && (
                <div className="absolute top-6 left-6 bg-red-600 text-white text-[9px] font-black uppercase px-3 py-1 rounded-full shadow-lg">Oferta Limitada</div>
            )}
            <button className="absolute top-6 right-6 p-3 bg-neutral-900/5 text-neutral-400 hover:text-red-500 hover:bg-white transition-all rounded-full shadow-lg opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0">
              <IconHeart size={20} />
            </button>
            <div className="absolute bottom-6 left-6 right-6 translate-y-20 group-hover:translate-y-0 transition-transform duration-500 no-print">
                <button 
                    onClick={() => onAdd(p)}
                    className="w-full bg-neutral-900 text-white font-black py-4 rounded-2xl uppercase tracking-tighter hover:bg-yellow-400 hover:text-black transition-all shadow-2xl"
                >
                    Adicionar à Sacola
                </button>
            </div>
          </div>
          
          {/* Info */}
          <div className="mt-8 space-y-3 px-2">
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-neutral-500">{p.category}</p>
            <h3 className="text-xl font-black uppercase italic tracking-tighter leading-none group-hover:text-yellow-400 transition-colors">{p.title}</h3>
            <div className="flex items-center justify-between gap-4">
                <div className="flex flex-col">
                    <span className="text-[10px] text-neutral-600 line-through font-bold">De {fmtBRL(p.priceCents * 1.2)}</span>
                    <span className="text-2xl font-black text-white italic tracking-tighter">{fmtBRL(p.priceCents)}</span>
                </div>
                <div className="p-3 bg-neutral-900 rounded-2xl border border-neutral-800 text-lime-400 animate-pulse">
                    <IconCheckCircle size={18}/>
                </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
