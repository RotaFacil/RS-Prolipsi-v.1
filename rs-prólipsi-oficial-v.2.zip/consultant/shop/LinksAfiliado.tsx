
import React, { useState } from 'react';
import Card from '../../components/Card';
import { mockAffiliateSellers, mockShopSettings } from '../data';
import { IconSearch, IconLink, IconCopy, IconExternalLink, IconStore } from '../../components/icons';
import { useUser } from '../ConsultantLayout';

const LinksAfiliado: React.FC = () => {
    const { user } = useUser();
    const [searchTerm, setSearchTerm] = useState('');

    const copyLink = (sellerId: string) => {
        const link = `https://rsprolipsi.com/loja/${sellerId}?ref=${user.id}`;
        navigator.clipboard.writeText(link);
        alert('Link de afiliado copiado!');
    };

    const filteredSellers = mockAffiliateSellers.filter(s => 
        s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        s.category.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="space-y-8">
            <Card>
                <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
                    <div>
                        <h2 className="text-xl font-bold text-white">Programa de Afiliados</h2>
                        <p className="text-sm text-gray-400">Divulgue lojas parceiras e ganhe comissão sobre as vendas.</p>
                    </div>
                    <div className="relative w-full md:w-64">
                        <IconSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                        <input 
                            type="text" 
                            placeholder="Buscar parceiro..." 
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className="w-full bg-brand-gray-light border border-brand-gray rounded-lg py-2 pl-10 pr-4 text-white focus:border-brand-gold focus:outline-none"
                        />
                    </div>
                </div>

                <div className="space-y-4">
                    {filteredSellers.map(seller => (
                        <div key={seller.id} className="bg-brand-gray-light p-4 rounded-lg flex flex-col md:flex-row items-center gap-4 border border-transparent hover:border-brand-gray transition-colors">
                            <img src={seller.logoUrl} alt={seller.name} className="w-12 h-12 rounded-full bg-white object-contain p-1" />
                            <div className="flex-1 text-center md:text-left">
                                <h3 className="font-bold text-white">{seller.name}</h3>
                                <p className="text-xs text-gray-400">{seller.category}</p>
                            </div>
                            <div className="text-center px-4">
                                <p className="text-xs text-gray-500 uppercase font-bold">Comissão</p>
                                <p className="text-lg font-bold text-green-400">{seller.commissionRate}%</p>
                            </div>
                            <div className="flex gap-2 w-full md:w-auto">
                                <button 
                                    onClick={() => copyLink(seller.id)}
                                    className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-brand-gold text-brand-dark font-bold py-2 px-4 rounded-lg hover:bg-yellow-400 transition-colors text-sm"
                                >
                                    <IconCopy size={16}/> Copiar Link
                                </button>
                                <a 
                                    href={`#`} 
                                    className="flex items-center justify-center p-2 bg-brand-gray text-gray-300 hover:text-white rounded-lg transition-colors"
                                    title="Visitar Loja"
                                >
                                    <IconExternalLink size={20}/>
                                </a>
                            </div>
                        </div>
                    ))}
                </div>
            </Card>

            <Card className="bg-gradient-to-r from-blue-900 to-brand-gray border border-blue-700/30">
                <div className="flex items-start gap-4">
                    <div className="p-3 bg-blue-500/20 rounded-full text-blue-400 hidden sm:block">
                        <IconStore size={32}/>
                    </div>
                    <div>
                        <h3 className="text-lg font-bold text-white mb-2">Link da Sua Loja Própria</h3>
                        <p className="text-sm text-blue-200 mb-4">Use este link para divulgar sua vitrine completa, incluindo produtos de dropshipping selecionados por você.</p>
                        <div className="flex gap-2">
                            <input 
                                type="text" 
                                readOnly 
                                value={`https://rsprolipsi.com/store/${mockShopSettings.storeSlug}`} 
                                className="flex-1 bg-black/30 border border-blue-500/30 rounded px-3 text-sm text-white"
                            />
                            <button 
                                onClick={() => { navigator.clipboard.writeText(`https://rsprolipsi.com/store/${mockShopSettings.storeSlug}`); alert('Link copiado!'); }}
                                className="bg-blue-600 hover:bg-blue-500 text-white font-bold py-2 px-4 rounded text-sm transition-colors"
                            >
                                Copiar
                            </button>
                        </div>
                    </div>
                </div>
            </Card>
        </div>
    );
};

export default LinksAfiliado;
