
import React, { useState, FormEvent, FC } from 'react';
import Card from '../../components/Card';
import Modal from '../../components/Modal';
import { mockPixels } from '../data';
import { 
    IconFacebook, IconGoogle, IconPinterest, IconPlus, IconTrash, 
    IconEdit, IconHelpCircle, IconTikTok, IconTaboola, IconSnapchat,
    IconTwitter, IconLinkedin
} from '../../components/icons';
import type { Pixel } from '../../types';

// Configuração visual e de campos para cada plataforma
const platformConfig = {
    facebook: { 
        name: 'Facebook / Meta', 
        icon: IconFacebook, 
        color: 'text-blue-500',
        fields: [
            { id: 'pixelId', label: 'ID do Pixel', tooltip: 'O identificador numérico do seu pixel.' },
            { id: 'accessToken', label: 'Token de API (Opcional)', tooltip: 'Para API de Conversões (CAPI).' }
        ]
    },
    google: { 
        name: 'Google Ads', 
        icon: IconGoogle, 
        color: 'text-red-500',
        fields: [
            { id: 'pixelId', label: 'Google Tag ID (AW-)', tooltip: 'Ex: AW-123456789' },
            { id: 'conversionLabel', label: 'Rótulo de Conversão', tooltip: 'O código alfanumérico da conversão.' }
        ]
    },
    tiktok: {
        name: 'TikTok Ads',
        icon: IconTikTok,
        color: 'text-white',
        fields: [ { id: 'pixelId', label: 'Pixel ID', tooltip: 'ID do pixel do TikTok.' } ]
    },
    pinterest: { 
        name: 'Pinterest', 
        icon: IconPinterest, 
        color: 'text-red-700',
        fields: [ { id: 'pixelId', label: 'Tag ID', tooltip: 'ID da tag do Pinterest.' } ]
    },
    taboola: { name: 'Taboola', icon: IconTaboola, color: 'text-blue-400', fields: [{ id: 'pixelId', label: 'Pixel ID', tooltip: '' }] },
    snapchat: { name: 'Snapchat', icon: IconSnapchat, color: 'text-yellow-400', fields: [{ id: 'pixelId', label: 'Pixel ID', tooltip: '' }] },
    twitter: { name: 'X / Twitter', icon: IconTwitter, color: 'text-gray-300', fields: [{ id: 'pixelId', label: 'Pixel ID', tooltip: '' }] },
    linkedin: { name: 'LinkedIn', icon: IconLinkedin, color: 'text-blue-600', fields: [{ id: 'pixelId', label: 'Insight Tag ID', tooltip: '' }] },
};

const statusMap = {
  active: { label: 'Ativo', color: 'bg-green-500/20 text-green-400' },
  inactive: { label: 'Inativo', color: 'bg-red-500/20 text-red-400' },
};

const Tooltip: FC<{text: string; children: React.ReactNode}> = ({ text, children }) => (
    <div className="relative flex items-center group ml-2">
        {children}
        <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 w-48 p-2 bg-black text-white text-xs rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10 text-center">
            {text}
        </div>
    </div>
);

const PixelsMarketing: React.FC = () => {
    const [pixels, setPixels] = useState<Pixel[]>(mockPixels);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingPixel, setEditingPixel] = useState<Pixel | null>(null);
    const [formData, setFormData] = useState<Partial<Pixel>>({ platform: 'facebook', status: 'active' });

    const handleOpenModal = (pixel?: Pixel) => {
        if (pixel) {
            setEditingPixel(pixel);
            setFormData(pixel);
        } else {
            setEditingPixel(null);
            setFormData({ platform: 'facebook', status: 'active', name: '', pixelId: '' });
        }
        setIsModalOpen(true);
    };

    const handleSave = (e: FormEvent) => {
        e.preventDefault();
        if (editingPixel) {
            setPixels(prev => prev.map(p => p.id === editingPixel.id ? { ...p, ...formData } as Pixel : p));
        } else {
            const newPixel = { ...formData, id: `px-${Date.now()}` } as Pixel;
            setPixels(prev => [...prev, newPixel]);
        }
        setIsModalOpen(false);
    };

    const handleDelete = (id: string) => {
        if (confirm('Tem certeza que deseja remover este pixel?')) {
            setPixels(prev => prev.filter(p => p.id !== id));
        }
    };

    const PlatformIcon = ({ platform }: { platform: string }) => {
        // @ts-ignore
        const config = platformConfig[platform];
        if (!config) return null;
        const Icon = config.icon;
        return <Icon className={`h-6 w-6 ${config.color}`} />;
    };

    return (
        <div className="space-y-6">
            <Card>
                <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
                    <div>
                        <h2 className="text-xl font-bold text-white">Pixels de Rastreamento</h2>
                        <p className="text-gray-400 text-sm">Configure seus pixels para rastrear visitas, checkouts e compras na sua loja.</p>
                    </div>
                    <button onClick={() => handleOpenModal()} className="flex items-center gap-2 bg-brand-gold text-brand-dark font-bold py-2 px-4 rounded-lg hover:bg-yellow-400 transition-colors">
                        <IconPlus size={18} /> Adicionar Pixel
                    </button>
                </div>

                <div className="space-y-3">
                    {pixels.map(pixel => (
                        <div key={pixel.id} className="flex flex-col md:flex-row items-center justify-between p-4 bg-brand-gray-light rounded-lg border border-transparent hover:border-brand-gray transition-colors">
                            <div className="flex items-center gap-4 w-full md:w-auto mb-3 md:mb-0">
                                <div className="p-3 bg-brand-gray rounded-lg">
                                    <PlatformIcon platform={pixel.platform} />
                                </div>
                                <div>
                                    <h4 className="font-bold text-white">{pixel.name}</h4>
                                    <p className="text-xs text-gray-400 font-mono">{pixel.pixelId}</p>
                                </div>
                            </div>
                            
                            <div className="flex items-center gap-4 w-full md:w-auto justify-between md:justify-end">
                                <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${statusMap[pixel.status].color}`}>
                                    {statusMap[pixel.status].label}
                                </span>
                                <div className="flex gap-2">
                                    <button onClick={() => handleOpenModal(pixel)} className="p-2 text-gray-400 hover:text-white hover:bg-brand-gray rounded transition-colors"><IconEdit size={18}/></button>
                                    <button onClick={() => handleDelete(pixel.id)} className="p-2 text-gray-400 hover:text-red-400 hover:bg-brand-gray rounded transition-colors"><IconTrash size={18}/></button>
                                </div>
                            </div>
                        </div>
                    ))}
                    {pixels.length === 0 && <p className="text-center text-gray-500 py-8">Nenhum pixel configurado.</p>}
                </div>
            </Card>

            <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={editingPixel ? "Editar Pixel" : "Novo Pixel"}>
                <form onSubmit={handleSave} className="space-y-4">
                    <div>
                        <label className="text-sm text-gray-400 block mb-1">Plataforma</label>
                        <select 
                            value={formData.platform} 
                            onChange={e => setFormData({ ...formData, platform: e.target.value as any })}
                            className="w-full bg-brand-gray p-2 rounded border border-gray-600 text-white focus:border-brand-gold focus:outline-none"
                        >
                            {Object.entries(platformConfig).map(([key, config]) => (
                                <option key={key} value={key}>{config.name}</option>
                            ))}
                        </select>
                    </div>
                    
                    <div>
                        <label className="text-sm text-gray-400 block mb-1">Nome de Identificação</label>
                        <input 
                            type="text" 
                            value={formData.name || ''} 
                            onChange={e => setFormData({ ...formData, name: e.target.value })}
                            placeholder="Ex: Facebook Ads Principal"
                            className="w-full bg-brand-gray p-2 rounded border border-gray-600 text-white focus:border-brand-gold focus:outline-none"
                            required
                        />
                    </div>

                    {/* Dynamic Fields based on Platform */}
                    {/* @ts-ignore */}
                    {platformConfig[formData.platform || 'facebook'].fields.map((field: any) => (
                        <div key={field.id}>
                            <label className="text-sm text-gray-400 block mb-1 flex items-center">
                                {field.label}
                                {field.tooltip && <Tooltip text={field.tooltip}><IconHelpCircle size={14} className="text-gray-500"/></Tooltip>}
                            </label>
                            <input 
                                type="text"
                                // @ts-ignore
                                value={formData[field.id] || ''}
                                // @ts-ignore
                                onChange={e => setFormData({ ...formData, [field.id]: e.target.value })}
                                className="w-full bg-brand-gray p-2 rounded border border-gray-600 text-white focus:border-brand-gold focus:outline-none font-mono"
                            />
                        </div>
                    ))}

                    <div>
                        <label className="text-sm text-gray-400 block mb-1">Status</label>
                        <select 
                            value={formData.status} 
                            onChange={e => setFormData({ ...formData, status: e.target.value as any })}
                            className="w-full bg-brand-gray p-2 rounded border border-gray-600 text-white focus:border-brand-gold focus:outline-none"
                        >
                            <option value="active">Ativo (Instalado)</option>
                            <option value="inactive">Inativo</option>
                        </select>
                    </div>

                    <button type="submit" className="w-full bg-brand-gold text-brand-dark font-bold py-3 rounded-lg hover:bg-yellow-400 mt-4">
                        Salvar Configuração
                    </button>
                </form>
            </Modal>
        </div>
    );
};

export default PixelsMarketing;
