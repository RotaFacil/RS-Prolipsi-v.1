
import React, { useState } from 'react';
import Card from '../../components/Card';
import { mockShortenedLinks } from '../data';
import { IconLink, IconActive, IconTrendingUp, IconCopy, IconTrash, IconExternalLink } from '../../components/icons';
import type { ShortenedLink } from '../../types';

const EncurtadorLink: React.FC = () => {
    const [links, setLinks] = useState<ShortenedLink[]>(mockShortenedLinks);
    const [longUrl, setLongUrl] = useState('');
    const [customAlias, setCustomAlias] = useState('');
    const [isCreating, setIsCreating] = useState(false);

    const handleShorten = (e: React.FormEvent) => {
        e.preventDefault();
        setIsCreating(true);
        
        // Simulação de API
        setTimeout(() => {
            const alias = customAlias || Math.random().toString(36).substring(2, 7);
            const newLink: ShortenedLink = {
                id: Date.now().toString(),
                short: `https://robot.rs/${alias}`,
                original: longUrl,
                clicks: 0
            };
            setLinks([newLink, ...links]);
            setLongUrl('');
            setCustomAlias('');
            setIsCreating(false);
        }, 800);
    };

    const copyToClipboard = (text: string) => {
        navigator.clipboard.writeText(text);
        alert('Link copiado!');
    };

    const handleDelete = (id: string) => {
        setLinks(prev => prev.filter(l => l.id !== id));
    };

    return (
        <div className="space-y-8">
            <Card className="border-l-4 border-brand-gold">
                <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2"><IconLink className="text-brand-gold"/> Novo Link Curto</h2>
                <form onSubmit={handleShorten} className="space-y-4">
                    <div className="flex flex-col md:flex-row gap-4">
                        <div className="flex-grow">
                            <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">URL Original (Destino)</label>
                            <input 
                                type="url" 
                                required 
                                value={longUrl}
                                onChange={e => setLongUrl(e.target.value)}
                                placeholder="https://..."
                                className="w-full bg-brand-gray-light p-3 rounded-lg border border-gray-600 focus:border-brand-gold focus:outline-none text-white"
                            />
                        </div>
                        <div className="md:w-1/3">
                            <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Apelido (Opcional)</label>
                            <div className="flex items-center">
                                <span className="bg-brand-gray border border-r-0 border-gray-600 p-3 rounded-l-lg text-gray-400 text-sm">robot.rs/</span>
                                <input 
                                    type="text" 
                                    value={customAlias}
                                    onChange={e => setCustomAlias(e.target.value)}
                                    placeholder="ex: promo-natal"
                                    className="w-full bg-brand-gray-light p-3 rounded-r-lg border border-gray-600 focus:border-brand-gold focus:outline-none text-white"
                                />
                            </div>
                        </div>
                    </div>
                    <div className="text-right">
                        <button type="submit" disabled={isCreating} className="bg-brand-gold text-brand-dark font-bold px-8 py-3 rounded-lg hover:bg-yellow-400 transition-all shadow-lg shadow-brand-gold/20 disabled:opacity-50">
                            {isCreating ? 'Encurtando...' : 'Encurtar Agora'}
                        </button>
                    </div>
                </form>
            </Card>

            <Card>
                <h2 className="text-xl font-bold text-white mb-6">Meus Links</h2>
                <div className="space-y-4">
                    {links.map(link => (
                        <div key={link.id} className="bg-brand-gray-light p-4 rounded-lg border border-transparent hover:border-brand-gray transition-colors flex flex-col md:flex-row justify-between items-center gap-4">
                            <div className="flex-grow min-w-0">
                                <div className="flex items-center gap-3 mb-1">
                                    <span className="font-bold text-brand-gold text-lg">{link.short}</span>
                                    <button onClick={() => copyToClipboard(link.short)} className="text-gray-400 hover:text-white" title="Copiar"><IconCopy size={16}/></button>
                                    <a href={link.short} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white" title="Abrir"><IconExternalLink size={16}/></a>
                                </div>
                                <p className="text-xs text-gray-400 truncate max-w-md">{link.original}</p>
                            </div>
                            
                            <div className="flex items-center gap-6">
                                <div className="flex flex-col items-center">
                                    <span className="text-xs text-gray-500 font-bold uppercase">Cliques</span>
                                    <div className="flex items-center gap-1 text-white font-bold">
                                        <IconTrendingUp size={16} className="text-green-400"/> {link.clicks}
                                    </div>
                                </div>
                                <div className="h-8 w-px bg-gray-600 mx-2 hidden md:block"></div>
                                <button onClick={() => handleDelete(link.id)} className="p-2 text-gray-500 hover:text-red-400 transition-colors">
                                    <IconTrash size={18}/>
                                </button>
                            </div>
                        </div>
                    ))}
                    {links.length === 0 && <p className="text-center text-gray-500 py-4">Nenhum link criado ainda.</p>}
                </div>
            </Card>
        </div>
    );
};

export default EncurtadorLink;
