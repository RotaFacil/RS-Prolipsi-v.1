
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../../components/Card';
import { 
    IconEye, IconLayout, IconCopy, IconCheckCircle, IconExternalLink, 
    IconSparkles, IconBox, IconChart, IconShield, IconStore,
    IconShoppingCart, IconTrendingUp, IconAward, IconChevronRight
} from '../../components/icons';
import { mockStoreConfig } from '../data';
import { useUser } from '../ConsultantLayout';

const VitrineHome: React.FC = () => {
    const { user } = useUser();
    const navigate = useNavigate();
    const [config, setConfig] = useState(mockStoreConfig);
    const [copied, setCopied] = useState(false);
    const [hasConfigured, setHasConfigured] = useState(false);

    useEffect(() => {
        const saved = localStorage.getItem('userStoreConfig');
        if (saved) {
            setConfig(JSON.parse(saved));
            setHasConfigured(true);
        }
    }, []);

    // FUNÇÃO PADRONIZADA PARA GERAR LINK REAL DA LOJA
    const getStoreUrl = () => {
        const origin = window.location.origin;
        const path = window.location.pathname;
        return `${origin}${path}#/store/${config.slug}`;
    };

    const handleCopy = () => {
        const fullUrl = getStoreUrl();
        navigator.clipboard.writeText(fullUrl);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    const handleOpenStore = () => {
        window.open(getStoreUrl(), '_blank');
    };

    if (!hasConfigured) {
        return (
            <div className="max-w-6xl mx-auto space-y-16 animate-fade-in py-10">
                <div className="text-center space-y-6">
                    <div className="inline-flex p-3 bg-[#39FF14]/10 rounded-2xl text-[#39FF14] mb-4">
                        <IconStore size={40} />
                    </div>
                    <h1 className="text-4xl md:text-6xl font-black text-white italic uppercase tracking-tighter leading-none">
                        Sua Loja Profissional <br/> <span className="text-[#39FF14]">Pronta em Segundos</span>
                    </h1>
                    <p className="text-xl text-gray-400 max-w-2xl mx-auto">
                        Não seja apenas um consultor, seja dono do seu próprio e-commerce de luxo com estoque global e logística integrada.
                    </p>
                    <div className="pt-6">
                        <button 
                            onClick={() => navigate('/consultant/shop/setup')}
                            className="bg-[#39FF14] text-black font-black px-10 py-5 rounded-2xl text-xl uppercase tracking-tighter hover:scale-105 transition-all shadow-[0_0_30px_rgba(57,255,20,0.3)] flex items-center gap-3 mx-auto"
                        >
                            Criar Minha Loja Agora <IconChevronRight size={24}/>
                        </button>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <Card className="bg-brand-gray-light/30 border-white/5 p-8 text-center space-y-4">
                        <div className="w-12 h-12 bg-blue-500/20 text-blue-400 rounded-full flex items-center justify-center mx-auto"><IconBox/></div>
                        <h3 className="text-xl font-bold text-white uppercase italic">Dropshipping Nativo</h3>
                        <p className="text-gray-500 text-sm">Venda sem estoque. A RS Prólipsi cuida da separação e envio direto.</p>
                    </Card>
                    <Card className="bg-brand-gray-light/30 border-white/5 p-8 text-center space-y-4">
                        <div className="w-12 h-12 bg-purple-500/20 text-purple-400 rounded-full flex items-center justify-center mx-auto"><IconSparkles/></div>
                        <h3 className="text-xl font-bold text-white uppercase italic">Design de Luxo</h3>
                        <p className="text-gray-500 text-sm">Sua loja com visual "High-End". Templates otimizados para converter.</p>
                    </Card>
                    <Card className="bg-brand-gray-light/30 border-white/5 p-8 text-center space-y-4">
                        <div className="w-12 h-12 bg-green-500/20 text-green-400 rounded-full flex items-center justify-center mx-auto"><IconTrendingUp/></div>
                        <h3 className="text-xl font-bold text-white uppercase italic">Comissão Direta</h3>
                        <p className="text-gray-500 text-sm">Vendeu, ganhou. Suas comissões caem direto na sua RS Wallet.</p>
                    </Card>
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-8 animate-fade-in">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2 border-l-4 border-[#39FF14] bg-brand-gray shadow-xl">
                    <div className="flex flex-col md:flex-row justify-between gap-6">
                        <div className="space-y-2">
                            <div className="flex items-center gap-2">
                                <span className="h-2 w-2 bg-[#39FF14] rounded-full animate-pulse"></span>
                                <span className="text-[10px] font-black uppercase text-[#39FF14] tracking-widest">Vitrine Standalone Online</span>
                            </div>
                            <h2 className="text-3xl font-black text-white italic uppercase tracking-tighter">
                                {config.storeName}
                            </h2>
                            <p className="text-gray-400 text-sm">Sua vitrine profissional está ativa e pronta para vender.</p>
                        </div>
                        <button 
                            onClick={handleOpenStore}
                            className="bg-[#39FF14] text-black font-black px-6 py-3 rounded-xl flex items-center justify-center gap-2 hover:brightness-110 transition-all shadow-lg self-start"
                        >
                            <IconEye size={20}/> Abrir Loja
                        </button>
                    </div>

                    <div className="mt-8 pt-6 border-t border-white/5 space-y-3">
                        <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Link de Divulgação</label>
                        <div className="flex items-center gap-2">
                            <input 
                                type="text" 
                                readOnly 
                                value={getStoreUrl()} 
                                className="flex-1 bg-black/40 border border-white/10 p-3 rounded-lg text-sm text-brand-gold font-mono focus:outline-none"
                            />
                            <button 
                                onClick={handleCopy}
                                className={`p-3 rounded-lg border transition-all ${copied ? 'bg-green-500 border-green-500 text-white' : 'bg-brand-gray-light border-white/10 text-gray-400 hover:text-white'}`}
                            >
                                {copied ? <IconCheckCircle size={20}/> : <IconCopy size={20}/>}
                            </button>
                        </div>
                    </div>
                </Card>

                <Card className="flex flex-col justify-center items-center text-center p-8 bg-[#39FF14]/5 border-[#39FF14]/20 border-dashed border-2">
                    <IconSparkles size={48} className="text-[#39FF14] mb-4" />
                    <h3 className="text-white font-bold text-lg mb-2">Editor Visual</h3>
                    <p className="text-gray-400 text-xs mb-6">Mude o estilo e as cores da sua vitrine.</p>
                    <button 
                        onClick={() => navigate('/consultant/shop/store-builder')}
                        className="w-full py-3 rounded-xl bg-white/5 border border-[#39FF14]/30 text-white font-bold text-sm hover:bg-[#39FF14]/10 transition-all"
                    >
                        Customizar Layout
                    </button>
                </Card>
            </div>
        </div>
    );
};

export default VitrineHome;
