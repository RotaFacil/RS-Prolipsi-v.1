
import React, { useState } from 'react';
import Card from '../../components/Card';
import Modal from '../../components/Modal';
import { mockUserOrders } from '../data';
import type { UserOrder } from '../../types';
import { IconCheckCircle, IconTruck, IconFileClock } from '../../components/icons';

const formatCurrency = (value: number) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const statusMap: Record<UserOrder['status'], { label: string; icon: React.ElementType; color: string }> = {
    pending_payment: { label: 'Aguardando Pagamento', icon: IconFileClock, color: 'text-yellow-400' },
    paid: { label: 'Pago', icon: IconCheckCircle, color: 'text-blue-400' },
    shipped: { label: 'Enviado', icon: IconTruck, color: 'text-indigo-400' },
    completed: { label: 'Entregue', icon: IconCheckCircle, color: 'text-green-400' },
};

const MeusPedidos: React.FC = () => {
    const [selectedOrder, setSelectedOrder] = useState<UserOrder | null>(null);

    return (
        <>
            <Card>
                <h2 className="text-xl font-bold text-white mb-6">Histórico de Pedidos</h2>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="border-b border-brand-gray text-sm text-gray-400">
                            <tr>
                                <th className="p-3">Pedido</th>
                                <th className="p-3">Data</th>
                                <th className="p-3">Status</th>
                                <th className="p-3 text-right">Total</th>
                                <th className="p-3"></th>
                            </tr>
                        </thead>
                        <tbody>
                            {mockUserOrders.map(order => {
                                const statusInfo = statusMap[order.status] || statusMap.pending_payment;
                                const StatusIcon = statusInfo.icon;
                                return (
                                    <tr key={order.id} className="border-b border-brand-gray-light last:border-b-0 hover:bg-brand-gray-light/50">
                                        <td className="p-3 font-semibold text-white font-mono">{order.id}</td>
                                        <td className="p-3 text-sm text-gray-300">{new Date(order.date).toLocaleDateString('pt-BR')}</td>
                                        <td className="p-3">
                                            <span className={`flex items-center gap-2 text-sm font-semibold ${statusInfo.color}`}>
                                                <StatusIcon size={16} />
                                                {statusInfo.label}
                                            </span>
                                        </td>
                                        <td className="p-3 text-right font-semibold text-white">{formatCurrency(order.total)}</td>
                                        <td className="p-3 text-right">
                                            <button 
                                                onClick={() => setSelectedOrder(order)}
                                                className="text-sm bg-brand-gray px-4 py-1.5 rounded-md hover:bg-brand-dark text-brand-gold font-semibold transition-colors"
                                            >
                                                Ver Detalhes
                                            </button>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </Card>

            <Modal isOpen={!!selectedOrder} onClose={() => setSelectedOrder(null)} title={`Detalhes do Pedido: ${selectedOrder?.id}`}>
                {selectedOrder && (
                    <div className="space-y-6">
                        <div>
                            <h3 className="font-bold text-brand-gold mb-2">Itens do Pedido</h3>
                            <div className="space-y-3">
                                {selectedOrder.items.map(item => (
                                    <div key={item.productId} className="flex items-center justify-between p-3 bg-brand-gray-light rounded-lg">
                                        <div className="flex items-center gap-4">
                                            <img src={item.imageUrl} alt={item.name} className="h-12 w-12 rounded-md object-cover" />
                                            <div>
                                                <p className="font-semibold text-white text-sm">{item.name}</p>
                                                <p className="text-xs text-gray-400">{item.quantity} x {formatCurrency(item.unitPrice)}</p>
                                            </div>
                                        </div>
                                        <p className="font-semibold text-white text-sm">{formatCurrency(item.quantity * item.unitPrice)}</p>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div>
                             <h3 className="font-bold text-brand-gold mb-2">Informações de Entrega</h3>
                             <div className="p-3 bg-brand-gray-light rounded-lg text-sm space-y-2">
                                <p><strong className="text-gray-400">Método:</strong> {selectedOrder.shipping.type === 'delivery' ? 'Entrega' : 'Retirada'}</p>
                                <p><strong className="text-gray-400">Endereço:</strong> {selectedOrder.shipping.address}</p>
                                {selectedOrder.shipping.trackingCode && (
                                     <p><strong className="text-gray-400">Rastreio:</strong> <span className="font-mono text-brand-gold">{selectedOrder.shipping.trackingCode}</span></p>
                                )}
                             </div>
                        </div>
                        
                        <div>
                            <h3 className="font-bold text-brand-gold mb-2">Resumo Financeiro</h3>
                            <div className="p-3 bg-brand-gray-light rounded-lg text-sm space-y-1">
                                <div className="flex justify-between"><span className="text-gray-400">Subtotal:</span> <span>{formatCurrency(selectedOrder.items.reduce((acc, i) => acc + (i.unitPrice * i.quantity), 0))}</span></div>
                                <div className="flex justify-between"><span className="text-gray-400">Frete:</span> <span>{formatCurrency(selectedOrder.shipping.cost)}</span></div>
                                <div className="flex justify-between font-bold text-lg pt-2 border-t border-brand-gray"><span className="text-white">Total:</span> <span className="text-brand-gold">{formatCurrency(selectedOrder.total)}</span></div>
                            </div>
                        </div>
                    </div>
                )}
            </Modal>
        </>
    );
};

export default MeusPedidos;
