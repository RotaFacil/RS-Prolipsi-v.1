
import React, { useState } from 'react';
import Card from '../../components/Card';
import { 
    IconStore, IconSettings, IconPalette, IconImage, IconLayout, 
    IconSave, IconEye, IconCheckCircle, IconPlus, IconTrash, IconStar,
    IconExternalLink, IconSparkles, IconChart, IconShield, IconRepeat, IconType
} from '../../components/icons';
import { mockStoreConfig, mockShopProducts } from '../data';
import type { StoreConfig } from '../../types';

// Helper de formatação de preço
const formatPrice = (p: number | undefined) => (p || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const StoreBuilder: React.FC = () => {
    const [config, setConfig] = useState<StoreConfig>(() => {
        const saved = localStorage.getItem('userStoreConfig');
        return saved ? JSON.parse(saved) : mockStoreConfig;
    });
    const [activeTab, setActiveTab] = useState<'hub' | 'config' | 'design' | 'catalog'>('hub');
    const [isSaving, setIsSaving] = useState(false);

    const handleSave = () => {
        setIsSaving(true);
        setTimeout(() => {
            setIsSaving(false);
            localStorage.setItem('userStoreConfig', JSON.stringify(config));
            alert("Alterações publicadas! Atualize a aba da loja para ver.");
        }, 1200);
    };

    const handleChange = (field: keyof StoreConfig, value: any) => {
        setConfig(prev => ({ ...prev, [field]: value }));
    };

    const toggleProduct = (productId: string) => {
        setConfig(prev => {
            const exists = prev.products.includes(productId);
            if (exists) return { ...prev, products: prev.products.filter(id => id !== productId) };
            return { ...prev, products: [...prev.products, productId] };
        });
    };

    const openPreview = () => {
        // Salva antes de abrir para o preview estar atualizado
        localStorage.setItem('userStoreConfig', JSON.stringify(config));
        
        // CONSTRUÇÃO DE URL COMPATÍVEL COM SANDBOX E HASHROUTER
        const baseUrl = window.location.href.split('#')[0];
        const storeUrl = `${baseUrl}#/store/${config.slug}`;
        window.open(storeUrl, '_blank');
    };

    return (
        <div className="space-y-8 animate-fade-in pb-24">
            {/* Header de Gestão Pro */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="flex items-center gap-4">
                    <div className="bg-[#39FF14] p-4 rounded-[1.5rem] text-black shadow-[0_0_30px_rgba(57,255,20,0.3)]">
                        <IconStore size={32} />
                    </div>
                    <div>
                        <h1 className="text-3xl font-black text-white italic uppercase tracking-tighter">CMS • Minha Vitrine</h1>
                        <div className="flex items-center gap-2 mt-1">
                            <span className="h-2 w-2 bg-[#39FF14] rounded-full animate-pulse"></span>
                            <span className="text-[10px] text-gray-500 font-black uppercase tracking-[0.2em]">Sincronizado com a Rede RS</span>
                        </div>
                    </div>
                </div>
                <div className="flex gap-3">
                    <button onClick={openPreview} className="bg-brand-gray text-white font-bold px-6 py-3 rounded-xl border border-gray-600 flex items-center gap-2 hover:bg-gray-700 transition-all">
                        <IconEye size={20} /> Preview
                    </button>
                    <button onClick={handleSave} disabled={isSaving} className="bg-[#39FF14] text-black font-black px-8 py-3 rounded-xl uppercase tracking-tighter shadow-lg hover:scale-105 transition-all disabled:opacity-50">
                        {isSaving ? 'Publicando...' : <><IconSave size={20} /> Publicar</>}
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                {/* Sidebar do CMS */}
                <div className="lg:col-span-1 space-y-4">
                    <Card className="p-2 border-white/5 bg-brand-gray-light/30">
                        <nav className="flex flex-col gap-1">
                            {[
                                { id: 'hub', label: 'Dashboard', icon: IconChart },
                                { id: 'config', label: 'Site & SEO', icon: IconSettings },
                                { id: 'design', label: 'Visual & Temas', icon: IconPalette },
                                { id: 'catalog', label: 'Meus Produtos', icon: IconLayout },
                            ].map(item => (
                                <button 
                                    key={item.id}
                                    onClick={() => setActiveTab(item.id as any)} 
                                    className={`flex items-center gap-3 px-4 py-4 rounded-xl font-black uppercase tracking-widest text-[10px] transition-all ${activeTab === item.id ? 'bg-[#39FF14] text-black' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
                                >
                                    <item.icon size={20} /> {item.label}
                                </button>
                            ))}
                        </nav>
                    </Card>

                    <Card className="bg-gradient-to-br from-purple-900/40 to-black border-purple-500/30 p-8 text-center">
                        <IconSparkles size={40} className="text-purple-400 mb-4 mx-auto animate-pulse" />
                        <h4 className="text-white font-black uppercase italic tracking-tighter text-lg">RSIA AI Designer</h4>
                        <p className="text-[10px] text-purple-200/60 leading-relaxed mt-4 font-bold uppercase tracking-widest">Deixe a IA escrever suas copies e escolher sua paleta de cores.</p>
                        <button className="w-full mt-6 py-3 bg-purple-600 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] text-white hover:bg-purple-500 transition-colors shadow-lg">Otimizar com IA</button>
                    </Card>
                </div>

                {/* Área de Edição */}
                <div className="lg:col-span-3">
                    {activeTab === 'hub' && (
                        <div className="space-y-6 animate-fade-in">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <Card className="p-8 border-t-4 border-blue-500 bg-brand-gray-light/50">
                                    <p className="text-[10px] font-black uppercase text-gray-500 tracking-[0.3em]">Visitantes</p>
                                    <p className="text-5xl font-black text-white mt-4 italic tracking-tighter">1,482</p>
                                </Card>
                                <Card className="p-8 border-t-4 border-[#39FF14] bg-brand-gray-light/50">
                                    <p className="text-[10px] font-black uppercase text-gray-500 tracking-[0.3em]">Conversões</p>
                                    <p className="text-5xl font-black text-white mt-4 italic tracking-tighter">42</p>
                                </Card>
                                <Card className="p-8 border-t-4 border-purple-500 bg-brand-gray-light/50">
                                    <p className="text-[10px] font-black uppercase text-gray-500 tracking-[0.3em]">Ticket Médio</p>
                                    <p className="text-5xl font-black text-white mt-4 italic tracking-tighter">R$ 185</p>
                                </Card>
                            </div>
                            <Card className="p-10 border-white/5">
                                <div className="flex items-center justify-between mb-8">
                                    <h3 className="text-xl font-black text-white italic uppercase tracking-tighter">Status de Publicação</h3>
                                    <div className="flex items-center gap-2 text-[#39FF14]">
                                        <IconCheckCircle size={16} />
                                        <span className="text-[10px] font-black uppercase tracking-widest">Loja Ativa</span>
                                    </div>
                                </div>
                                <div className="p-6 bg-black/40 rounded-[1.5rem] border border-white/5 space-y-4">
                                    <p className="text-sm text-gray-400 font-medium">Sua loja está online no endereço:</p>
                                    <div className="flex items-center gap-2">
                                        <input 
                                            readOnly 
                                            value={`rsprolipsi.com/store/${config.slug}`} 
                                            className="flex-1 bg-white/5 p-4 rounded-xl text-brand-gold font-mono text-sm border border-white/5"
                                        />
                                        <button onClick={openPreview} className="p-4 bg-brand-gray-light rounded-xl hover:text-brand-gold"><IconExternalLink/></button>
                                    </div>
                                </div>
                            </Card>
                        </div>
                    )}

                    {activeTab === 'config' && (
                        <Card className="space-y-8 animate-fade-in p-10 bg-brand-gray-light/20">
                            <h2 className="text-2xl font-black text-white italic uppercase tracking-tighter border-b border-white/5 pb-6">Configurações Gerais & SEO</h2>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                                <div className="space-y-6">
                                    <div>
                                        <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] mb-3 block">Nome da Sua Vitrine</label>
                                        <input type="text" value={config.storeName} onChange={e => handleChange('storeName', e.target.value)} className="w-full bg-black/40 border border-white/10 p-5 rounded-2xl text-white font-bold focus:border-[#39FF14] outline-none transition-all text-lg"/>
                                    </div>
                                    <div>
                                        <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] mb-3 block">URL Personalizada (Slug)</label>
                                        <div className="flex items-center bg-black/40 border border-white/10 rounded-2xl overflow-hidden focus-within:border-[#39FF14] transition-all">
                                            <span className="px-5 text-gray-600 text-xs font-mono">/store/</span>
                                            <input type="text" value={config.slug} onChange={e => handleChange('slug', e.target.value.toLowerCase().replace(/\s+/g, '-'))} className="flex-1 bg-transparent p-5 text-white font-mono outline-none"/>
                                        </div>
                                    </div>
                                </div>
                                <div className="space-y-6">
                                    <div>
                                        <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] mb-3 block">Headline do Banner (Título Principal)</label>
                                        <input type="text" value={config.heroHeadline} onChange={e => handleChange('heroHeadline', e.target.value)} className="w-full bg-black/40 border border-white/10 p-5 rounded-2xl text-white font-bold focus:border-[#39FF14] outline-none transition-all"/>
                                    </div>
                                    <div>
                                        <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] mb-3 block">Subtítulo Persuasivo</label>
                                        <textarea value={config.heroSubheadline} onChange={e => handleChange('heroSubheadline', e.target.value)} rows={3} className="w-full bg-black/40 border border-white/10 p-5 rounded-2xl text-white focus:border-[#39FF14] outline-none resize-none transition-all text-sm"/>
                                    </div>
                                </div>
                            </div>
                        </Card>
                    )}

                    {activeTab === 'design' && (
                        <Card className="space-y-8 animate-fade-in p-10">
                            <h2 className="text-2xl font-black text-white italic uppercase tracking-tighter border-b border-white/5 pb-6">Identidade Visual & Experiência</h2>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                                <div className="space-y-6">
                                    <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-4">Estrutura de Layout</h4>
                                    <div className="grid grid-cols-1 gap-4">
                                        {[
                                            { id: 'amazon-pro', label: 'E-commerce Clássico', desc: 'Foco em grade e categorias' },
                                            { id: 'boutique', label: 'Boutique de Luxo', desc: 'Imagens grandes e minimalismo' },
                                            { id: 'minimalist', label: 'Direct Sales', desc: 'Foco total em conversão rápida' },
                                        ].map(t => (
                                            <button 
                                                key={t.id} 
                                                onClick={() => handleChange('template', t.id)} 
                                                className={`p-6 rounded-[1.5rem] border-2 text-left flex items-center justify-between group transition-all ${config.template === t.id ? 'border-[#39FF14] bg-[#39FF14]/5' : 'border-white/5 bg-black/20 hover:border-white/20'}`}
                                            >
                                                <div>
                                                    <p className="font-bold text-white text-sm uppercase italic tracking-tighter">{t.label}</p>
                                                    <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mt-1">{t.desc}</p>
                                                </div>
                                                {config.template === t.id && <IconCheckCircle className="text-[#39FF14]" />}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                                <div className="space-y-8">
                                    <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-4">Cores da Marca</h4>
                                    <div className="space-y-6">
                                        <div className="flex items-center justify-between p-6 bg-black/40 rounded-2xl border border-white/5">
                                            <div>
                                                <span className="text-xs font-black text-white uppercase tracking-widest">Cor de Destaque</span>
                                                <p className="text-[10px] text-gray-500 uppercase font-bold mt-1">Botões e links</p>
                                            </div>
                                            <div className="flex items-center gap-4">
                                                <input type="color" value={config.primaryColor} onChange={e => handleChange('primaryColor', e.target.value)} className="h-12 w-12 border-0 bg-transparent cursor-pointer rounded-full overflow-hidden" />
                                                <span className="font-mono text-sm text-gray-400">{config.primaryColor}</span>
                                            </div>
                                        </div>
                                        <div className="flex items-center justify-between p-6 bg-black/40 rounded-2xl border border-white/5">
                                            <div>
                                                <span className="text-xs font-black text-white uppercase tracking-widest">Fundo da Loja</span>
                                                <p className="text-[10px] text-gray-500 uppercase font-bold mt-1">Dark ou Light mode</p>
                                            </div>
                                            <div className="flex items-center gap-4">
                                                <input type="color" value={config.secondaryColor} onChange={e => handleChange('secondaryColor', e.target.value)} className="h-12 w-12 border-0 bg-transparent cursor-pointer rounded-full overflow-hidden" />
                                                <span className="font-mono text-sm text-gray-400">{config.secondaryColor}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="p-6 bg-brand-gold/5 rounded-2xl border border-brand-gold/20 flex items-center gap-4">
                                        <IconShield size={24} className="text-brand-gold" />
                                        <p className="text-[10px] text-gray-400 font-bold uppercase leading-relaxed">
                                            Cores neon ou tons dourados são recomendados para manter a identidade visual RS Prólipsi de alta conversão.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </Card>
                    )}

                    {activeTab === 'catalog' && (
                        <Card className="space-y-8 animate-fade-in p-10">
                            <div className="flex justify-between items-center border-b border-white/5 pb-6">
                                <div>
                                    <h2 className="text-2xl font-black text-white italic uppercase tracking-tighter">Inventário Selecionado</h2>
                                    <p className="text-xs text-gray-500 font-bold uppercase mt-1">Escolha o que será exibido na sua vitrine</p>
                                </div>
                                <span className="bg-[#39FF14] text-black px-4 py-2 rounded-full font-black uppercase text-[10px] tracking-widest">{config.products.length} Itens Ativos</span>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[600px] overflow-y-auto pr-4 custom-scrollbar">
                                {mockShopProducts.map(p => {
                                    const isSelected = config.products.includes(p.id);
                                    return (
                                        <div key={p.id} onClick={() => toggleProduct(p.id)} className={`p-4 rounded-2xl border-2 cursor-pointer flex items-center gap-6 transition-all group ${isSelected ? 'border-[#39FF14] bg-[#39FF14]/5' : 'border-white/5 bg-black/20 hover:border-white/10'}`}>
                                            <div className="w-20 h-20 bg-white rounded-xl overflow-hidden p-2 flex-shrink-0">
                                                <img src={p.imageUrl} className="w-full h-full object-contain" alt={p.name} />
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <p className="text-[10px] text-[#39FF14] font-black uppercase tracking-[0.2em]">{p.category}</p>
                                                <h4 className="font-bold text-white text-sm truncate uppercase italic tracking-tighter">{p.name}</h4>
                                                <p className="text-sm font-black text-gray-400 mt-1">{formatPrice(p.price)}</p>
                                            </div>
                                            <div className={`w-10 h-10 rounded-full border-2 flex items-center justify-center transition-all ${isSelected ? 'bg-[#39FF14] border-[#39FF14] text-black' : 'border-gray-700 text-gray-700 group-hover:border-gray-500'}`}>
                                                {isSelected ? <IconCheckCircle size={20}/> : <IconPlus size={20}/>}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </Card>
                    )}
                </div>
            </div>

            <style>{`
                .custom-scrollbar::-webkit-scrollbar { width: 6px; }
                .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
                .custom-scrollbar::-webkit-scrollbar-thumb { background: #333; border-radius: 10px; }
                .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #39FF14; }
                @keyframes fade-in { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
                .animate-fade-in { animation: fade-in 0.5s ease-out forwards; }
            `}</style>
        </div>
    );
};

export default StoreBuilder;
