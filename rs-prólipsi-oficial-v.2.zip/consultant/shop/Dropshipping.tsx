
import React, { useState, useMemo } from 'react';
import Card from '../../components/Card';
import Modal from '../../components/Modal';
import { IconTruck, IconSearch, IconFilter, IconPlus, IconCheckCircle, IconEye } from '../../components/icons';
import { mockShopProducts, mockStoreConfig } from '../data';
import type { CDProduct } from '../../types';

const formatCurrency = (value: number) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const Dropshipping: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [categoryFilter, setCategoryFilter] = useState('Todos');
    const [myStoreProducts, setMyStoreProducts] = useState<string[]>(mockStoreConfig.products);
    const [selectedProduct, setSelectedProduct] = useState<CDProduct | null>(null);

    const filteredProducts = useMemo(() => {
        return mockShopProducts.filter(p => {
            const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
            const matchesCategory = categoryFilter === 'Todos' || p.category === categoryFilter;
            return matchesSearch && matchesCategory;
        });
    }, [searchTerm, categoryFilter]);

    const handleToggleStore = (productId: string) => {
        setMyStoreProducts(prev => {
            const exists = prev.includes(productId);
            const newProducts = exists ? prev.filter(id => id !== productId) : [...prev, productId];
            // In a real app, verify this updates the store config
            return newProducts;
        });
    };

    return (
        <div className="space-y-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div>
                    <h1 className="text-2xl font-bold text-brand-gold flex items-center gap-2"><IconTruck/> Catálogo Dropshipping</h1>
                    <p className="text-gray-400 text-sm mt-1">Selecione produtos para revender na sua loja sem precisar de estoque.</p>
                </div>
                <div className="flex gap-2">
                    <div className="relative">
                        <IconSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                        <input 
                            type="text" 
                            placeholder="Buscar produtos..." 
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className="bg-brand-gray-light border border-brand-gray rounded-lg py-2 pl-10 pr-4 text-white focus:border-brand-gold focus:outline-none"
                        />
                    </div>
                    <select 
                        value={categoryFilter}
                        onChange={e => setCategoryFilter(e.target.value)}
                        className="bg-brand-gray-light border border-brand-gray rounded-lg py-2 px-4 text-white focus:border-brand-gold focus:outline-none"
                    >
                        <option>Todos</option>
                        <option>Relógios</option>
                        <option>Eletrônicos</option>
                        <option>Moda</option>
                        <option>Beleza</option>
                    </select>
                </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredProducts.map(product => {
                    const isInStore = myStoreProducts.includes(product.id);
                    return (
                        <Card key={product.id} className="p-0 flex flex-col group hover:border-brand-gold/50 transition-colors">
                            <div className="relative h-48 overflow-hidden bg-white">
                                <img src={product.imageUrl} alt={product.name} className="w-full h-full object-contain p-4 group-hover:scale-105 transition-transform duration-300" />
                                <div className="absolute top-2 right-2 bg-brand-gold text-brand-dark text-xs font-bold px-2 py-1 rounded shadow">
                                    {product.commission ? `${product.commission}% Comiss.` : 'Dropship'}
                                </div>
                            </div>
                            <div className="p-4 flex-1 flex flex-col">
                                <p className="text-xs text-gray-500 mb-1">{product.category}</p>
                                <h3 className="font-bold text-white text-sm line-clamp-2 mb-2 flex-grow" title={product.name}>{product.name}</h3>
                                
                                <div className="flex justify-between items-end border-t border-brand-gray-light pt-3 mt-auto">
                                    <div>
                                        <p className="text-xs text-gray-400">Preço Sugerido</p>
                                        <p className="text-lg font-bold text-brand-gold">{formatCurrency(product.price || 0)}</p>
                                    </div>
                                    <button 
                                        onClick={() => handleToggleStore(product.id)}
                                        className={`p-2 rounded-lg transition-colors ${isInStore ? 'bg-green-500/20 text-green-400' : 'bg-brand-gray-light text-gray-300 hover:bg-brand-gold hover:text-brand-dark'}`}
                                        title={isInStore ? "Remover da Loja" : "Adicionar à Loja"}
                                    >
                                        {isInStore ? <IconCheckCircle size={20}/> : <IconPlus size={20}/>}
                                    </button>
                                </div>
                                <button onClick={() => setSelectedProduct(product)} className="w-full mt-3 text-xs text-center text-gray-500 hover:text-white flex items-center justify-center gap-1">
                                    <IconEye size={12}/> Ver Detalhes
                                </button>
                            </div>
                        </Card>
                    );
                })}
            </div>

            <Modal isOpen={!!selectedProduct} onClose={() => setSelectedProduct(null)} title="Detalhes do Produto">
                {selectedProduct && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-white rounded-lg p-4 flex items-center justify-center">
                            <img src={selectedProduct.imageUrl} alt={selectedProduct.name} className="max-w-full max-h-64 object-contain" />
                        </div>
                        <div className="space-y-4">
                            <h3 className="text-xl font-bold text-white">{selectedProduct.name}</h3>
                            <div className="flex gap-4">
                                <div className="bg-brand-gray-light p-3 rounded text-center flex-1">
                                    <p className="text-xs text-gray-400">Preço Custo</p>
                                    <p className="font-bold text-white">R$ {(selectedProduct.fullPrice * 0.6).toFixed(2)}</p>
                                </div>
                                <div className="bg-brand-gray-light p-3 rounded text-center flex-1">
                                    <p className="text-xs text-gray-400">Preço Venda</p>
                                    <p className="font-bold text-brand-gold">{formatCurrency(selectedProduct.price || 0)}</p>
                                </div>
                                <div className="bg-green-500/10 p-3 rounded text-center flex-1 border border-green-500/30">
                                    <p className="text-xs text-green-400">Lucro Est.</p>
                                    <p className="font-bold text-green-400">R$ {((selectedProduct.price || 0) - (selectedProduct.fullPrice * 0.6)).toFixed(2)}</p>
                                </div>
                            </div>
                            <p className="text-gray-300 text-sm leading-relaxed">{selectedProduct.details?.description || "Produto de alta qualidade para revenda."}</p>
                            <button 
                                onClick={() => { handleToggleStore(selectedProduct.id); setSelectedProduct(null); }}
                                className={`w-full py-3 rounded-lg font-bold transition-colors ${myStoreProducts.includes(selectedProduct.id) ? 'bg-red-500/20 text-red-400 hover:bg-red-500/40' : 'bg-brand-gold text-brand-dark hover:bg-yellow-400'}`}
                            >
                                {myStoreProducts.includes(selectedProduct.id) ? 'Remover da Minha Loja' : 'Adicionar à Minha Loja'}
                            </button>
                        </div>
                    </div>
                )}
            </Modal>
        </div>
    );
};

export default Dropshipping;
