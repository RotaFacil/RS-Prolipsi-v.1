
import React, { useState } from 'react';
import Card from '../components/Card';
import { useUser } from './ConsultantLayout';
import type { User, NetworkNode } from '../types';
import { mockDeepNetwork } from './data';
import { IconBell, IconMessage, IconUser } from '../components/icons';

import Treinamentos from './comunicacao/Treinamentos';
import Catalogo from './comunicacao/Catalogo';
import Downloads from './comunicacao/Downloads';

type Tab = 'comunicados' | 'agenda' | 'treinamentos' | 'catalogo' | 'central-de-midia';

interface TabButtonProps {
    label: string;
    active: boolean;
    onClick: () => void;
}

const TabButton: React.FC<TabButtonProps> = ({ label, active, onClick }) => (
  <button
    onClick={onClick}
    className={`px-4 py-2 text-sm font-semibold rounded-t-lg border-b-2 transition-colors whitespace-nowrap ${active ? 'border-brand-gold text-brand-gold' : 'border-transparent text-gray-400 hover:text-white'}`}
  >
    {label}
  </button>
);

const getNetworkDownline = (node: NetworkNode, maxLevel: number): User[] => {
    const downline: User[] = [];
    const queue: NetworkNode[] = [...node.children];

    while (queue.length > 0) {
        const currentNode = queue.shift();
        if (currentNode && !currentNode.isEmpty && currentNode.level <= maxLevel) {
            downline.push(currentNode);
            if (currentNode.children) {
                queue.push(...currentNode.children);
            }
        }
    }
    return downline;
};

const BirthdayCard: React.FC<{ member: User }> = ({ member }) => {
    const [, month, day] = member.birthDate.split('-');

    const handleSendWhatsApp = () => {
        const message = `Olá, ${member.name}! 🎉 Muitas felicidades, saúde e sucesso neste seu dia especial. Que seja um novo ciclo de grandes realizações! Um grande abraço da equipe RS Prólipsi.`;
        const phoneNumber = member.whatsapp.replace(/\D/g, ''); // Remove non-numeric chars
        const url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
        window.open(url, '_blank');
    };

    return (
        <div className="flex items-center justify-between p-4 bg-brand-gray-light rounded-lg">
            <div className="flex items-center space-x-4">
                <img src={member.avatarUrl} alt={member.name} className="h-12 w-12 rounded-full" />
                <div>
                    <p className="font-bold text-white">{member.name}</p>
                    <p className="text-sm text-gray-400">PIN: {member.pin}</p>
                </div>
            </div>
            <div className="text-right">
                <p className="text-lg font-bold text-brand-gold">{day}/{month}</p>
                <button 
                    onClick={handleSendWhatsApp}
                    className="text-xs mt-1 bg-brand-gray px-3 py-1.5 rounded-md hover:bg-brand-dark transition-colors font-semibold"
                >
                    Enviar Parabéns
                </button>
            </div>
        </div>
    );
};


const AgendaComemorativa: React.FC = () => {
    const currentMonth = new Date().getMonth() + 1;
    
    // Get downline up to 5th generation
    const downline = getNetworkDownline(mockDeepNetwork, 5);
    
    const birthdaysThisMonth = downline
        .filter(member => parseInt(member.birthDate.split('-')[1]) === currentMonth)
        .sort((a, b) => parseInt(a.birthDate.split('-')[2]) - parseInt(b.birthDate.split('-')[2]));

    return (
        <div className="animate-fade-in space-y-4">
            <h2 className="text-xl font-semibold text-white">Aniversariantes do Mês</h2>
            {birthdaysThisMonth.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {birthdaysThisMonth.map(member => <BirthdayCard key={member.id} member={member} />)}
                </div>
            ) : (
                <div className="text-center py-10 text-gray-500">
                    <IconUser size={40} className="mx-auto" />
                    <p className="mt-2">Nenhum aniversário este mês na sua rede (até 5ª geração).</p>
                </div>
            )}
        </div>
    );
}

const Comunicados: React.FC = () => {
    const { messages } = useUser();
    return (
        <div className="space-y-6 animate-fade-in max-h-[70vh] overflow-y-auto pr-2">
            {messages.map(msg => (
                <div key={msg.id} className="flex space-x-4 p-4 border-b border-brand-gray-light last:border-b-0">
                    <div className="flex-shrink-0">
                        <div className={`h-12 w-12 rounded-lg flex items-center justify-center
                            ${msg.type === 'announcement' ? 'bg-blue-500/20 text-blue-400' : ''}
                            ${msg.type === 'alert' ? 'bg-red-500/20 text-red-400' : ''}
                            ${msg.type === 'promotion' ? 'bg-green-500/20 text-green-400' : ''}
                        `}>
                           {msg.type === 'alert' ? <IconBell /> : <IconMessage />}
                        </div>
                    </div>
                    <div className="flex-1">
                        <div className="flex justify-between items-start">
                            <div>
                                <h2 className="text-lg font-bold text-white">{msg.title}</h2>
                                <p className="text-sm text-gray-300 mt-1">{msg.content}</p>
                            </div>
                            {!msg.read && <span className="text-xs bg-brand-gold text-brand-dark font-semibold px-2 py-1 rounded-full">Novo</span>}
                        </div>
                        <p className="text-xs text-gray-500 mt-2">{msg.date}</p>
                    </div>
                </div>
            ))}
        </div>
    );
};


const Comunicacao: React.FC = () => {
    const [activeTab, setActiveTab] = useState<Tab>('comunicados');

    const renderContent = () => {
        switch (activeTab) {
            case 'comunicados': return <Comunicados />;
            case 'agenda': return <AgendaComemorativa />;
            case 'treinamentos': return <Treinamentos />;
            case 'catalogo': return <Catalogo />;
            case 'central-de-midia': return <Downloads />;
            default: return null;
        }
    };

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-brand-gold">Central de Comunicação e Recursos</h1>
            <Card>
                <div className="border-b border-brand-gray-light mb-6">
                    <div className="flex items-center overflow-x-auto">
                        <TabButton label="Comunicados" active={activeTab === 'comunicados'} onClick={() => setActiveTab('comunicados')} />
                        <TabButton label="Agenda Comemorativa" active={activeTab === 'agenda'} onClick={() => setActiveTab('agenda')} />
                        <TabButton label="Treinamentos" active={activeTab === 'treinamentos'} onClick={() => setActiveTab('treinamentos')} />
                        <TabButton label="Catálogo" active={activeTab === 'catalogo'} onClick={() => setActiveTab('catalogo')} />
                        <TabButton label="Central de Mídia" active={activeTab === 'central-de-midia'} onClick={() => setActiveTab('central-de-midia')} />
                    </div>
                </div>
                
                {renderContent()}
            </Card>
            <style>{`
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in { animation: fade-in 0.3s ease-out forwards; }
            `}</style>
        </div>
    );
};

export default Comunicacao;
