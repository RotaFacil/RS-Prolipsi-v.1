// This component is intentionally left empty as part of a UI/UX overhaul.
// The previous implementation was considered subpar and has been removed.
// A new, more professional spreadsheet editor will be implemented in the future
// within the new "Suíte de Criação".
import React from 'react';

const SheetEditor: React.FC = () => {
  return null;
};

export default SheetEditor;
