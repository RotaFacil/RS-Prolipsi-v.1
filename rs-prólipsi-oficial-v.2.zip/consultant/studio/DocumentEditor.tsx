// This component is intentionally left empty as part of a UI/UX overhaul.
// The previous implementation was considered subpar and has been removed.
// A new, more professional document editor will be implemented in the future
// within the new "Suíte de Criação".
import React from 'react';

const DocumentEditor: React.FC = () => {
  return null;
};

export default DocumentEditor;
