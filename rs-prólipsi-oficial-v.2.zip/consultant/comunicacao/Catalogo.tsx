import React from 'react';
import { IconShop, IconExternalLink } from '../../components/icons';

const Catalogo: React.FC = () => {
  return (
    <div className="animate-fade-in text-center py-16 text-gray-500">
      <IconShop size={48} className="mx-auto text-brand-gold" />
      <h2 className="text-2xl font-bold text-white mt-4">Catálogo de Produtos</h2>
      <p className="mt-2 max-w-lg mx-auto">Em breve, você poderá visualizar todos os produtos da RS Prólipsi aqui. Por enquanto, acesse nossa loja externa para ver todas as novidades.</p>
      <a 
        href="#" // Em um cenário real, este seria o link para a loja
        target="_blank"
        rel="noopener noreferrer"
        className="mt-6 inline-flex items-center justify-center gap-2 bg-brand-gold text-brand-dark font-bold py-3 px-6 rounded-lg hover:bg-yellow-400 transition-colors shadow-lg shadow-brand-gold/20"
      >
        <IconExternalLink size={20} />
        <span>Visitar a RS Shop</span>
      </a>
    </div>
  );
};

export default Catalogo;
