
import { supabase } from '../../lib/supabase';
import type { NetworkNode, User } from '../../types';
import { mockAllConsultants } from '../data'; // Importa dados de teste como fallback

// Mapeamento de User do DB para NetworkNode
const mapUserToNode = (user: any, level: number): NetworkNode => ({
    id: user.id?.toString() || 'unknown',
    name: user.name || 'Usuário',
    username: user.username || `user${user.id}`,
    pin: user.pin || 'Iniciante',
    avatarUrl: user.avatar_url || user.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name || 'U')}&background=random`,
    status: user.status || 'active',
    email: user.email || '',
    whatsapp: user.whatsapp || '',
    address: { zipCode: '', street: '', number: '', neighborhood: '', city: '', state: '' },
    bankAccount: { bank: '', agency: '', accountNumber: '', accountType: 'checking', pixKey: '' },
    cpfCnpj: '',
    birthDate: '',
    registrationDate: user.created_at || new Date().toISOString(),
    hasPurchased: true,
    totalCycles: user.totalCycles || 0,
    personalVolume: user.personal_volume || 0,
    groupVolume: user.group_volume || 0,
    upline: {
        id: user.sponsor_id || '',
        username: '',
        name: '',
        avatarUrl: '',
        idConsultor: user.sponsor_id || '',
        whatsapp: ''
    },
    level: level,
    children: [],
    isEmpty: false
});

const createEmptyNode = (parentId: string, index: number, level: number): NetworkNode => ({
    id: `empty-${parentId}-${index}`,
    name: 'Disponível',
    username: '',
    pin: 'Vago',
    avatarUrl: '',
    status: 'inactive',
    email: '',
    whatsapp: '',
    address: { zipCode: '', street: '', number: '', neighborhood: '', city: '', state: '' },
    bankAccount: { bank: '', agency: '', accountNumber: '', accountType: 'checking', pixKey: '' },
    cpfCnpj: '',
    birthDate: '',
    registrationDate: '',
    hasPurchased: false,
    level: level,
    children: [],
    isEmpty: true
});

export const NetworkService = {
    /**
     * Busca todos os consultores. Se o DB estiver vazio ou der erro, retorna mocks para não quebrar a UI.
     */
    async fetchAllConsultants() {
        try {
            const { data, error } = await supabase
                .from('consultores')
                .select('*')
                .order('created_at', { ascending: true });

            if (error) {
                console.warn("Erro ao buscar consultores (usando fallback):", error.message);
                return mockAllConsultants;
            }

            // Se o banco estiver vazio ou com poucos dados, mistura com mocks para visualização (opcional, remova se quiser apenas dados reais)
            if (!data || data.length === 0) {
                console.log("Banco vazio. Usando dados de teste.");
                return mockAllConsultants;
            }

            return data;
        } catch (err) {
            console.error("Exceção ao buscar consultores:", err);
            return mockAllConsultants;
        }
    },

    /**
     * Constrói a Árvore Unilevel (Quem indicou quem - Padrão)
     */
    buildUnilevelTree(allUsers: any[], rootId: string): NetworkNode | null {
        // Normaliza IDs para string para garantir comparação correta
        const safeRootId = rootId.toString();
        const userMap = new Map<string, any>();
        allUsers.forEach(u => userMap.set(u.id.toString(), u));

        let rootUser = userMap.get(safeRootId);

        // FALLBACK: Se o usuário logado não estiver na lista (ex: acabou de criar conta e não salvou no DB, ou é mock),
        // cria um nó temporário para ele para não quebrar a tela.
        if (!rootUser) {
            console.warn(`Usuário raiz ${safeRootId} não encontrado na lista. Criando nó temporário.`);
            // Tenta achar nos mocks
            const mockUser = mockAllConsultants.find(u => u.id === safeRootId);
            if (mockUser) {
                rootUser = mockUser;
            } else {
                // Cria genérico
                rootUser = { 
                    id: safeRootId, 
                    name: 'Você (Novo)', 
                    pin: 'Iniciante', 
                    status: 'active', 
                    created_at: new Date().toISOString() 
                };
            }
        }

        const buildNode = (currentUser: any, currentLevel: number): NetworkNode => {
            const node = mapUserToNode(currentUser, currentLevel);
            
            const children = allUsers
                .filter(u => u.sponsor_id && u.sponsor_id.toString() === currentUser.id.toString())
                .map(child => buildNode(child, currentLevel + 1));
            
            node.children = children;
            return node;
        };

        return buildNode(rootUser, 0);
    },

    /**
     * Constrói a Matriz Forçada (Derramamento por Data)
     */
    buildForcedMatrixTree(allUsers: any[], rootId: string, width: number = 6, maxDepth: number = 6): NetworkNode | null {
        const safeRootId = rootId.toString();
        
        // 1. Encontrar o usuário raiz
        let rootUserRaw = allUsers.find(u => u.id.toString() === safeRootId);
        
        // Fallback se não encontrar
        if (!rootUserRaw) {
             const mockUser = mockAllConsultants.find(u => u.id === safeRootId);
             rootUserRaw = mockUser || { id: safeRootId, name: 'Você', pin: 'Iniciante', created_at: new Date().toISOString() };
        }

        // 2. Determinar quem faz parte da rede
        let teamMembers: any[] = [];
        const isCompany = safeRootId === '7838667' || rootUserRaw.username === 'admin' || rootUserRaw.name === 'RS Prólipsi';

        if (isCompany) {
             teamMembers = allUsers.filter(u => u.id.toString() !== safeRootId);
        } else {
            const getDescendants = (parentId: string): any[] => {
                const directs = allUsers.filter(u => u.sponsor_id && u.sponsor_id.toString() === parentId);
                let allDescendants = [...directs];
                directs.forEach(d => {
                    allDescendants = [...allDescendants, ...getDescendants(d.id.toString())];
                });
                return allDescendants;
            };
            teamMembers = getDescendants(safeRootId);
        }

        // 3. Ordenar por Data
        teamMembers.sort((a, b) => {
            const dateA = a.created_at || a.registrationDate || new Date().toISOString();
            const dateB = b.created_at || b.registrationDate || new Date().toISOString();
            return new Date(dateA).getTime() - new Date(dateB).getTime();
        });

        // 4. Montar Árvore
        const rootNode = mapUserToNode(rootUserRaw, 0);
        const parentQueue: NetworkNode[] = [rootNode];
        const usersToPlace = [...teamMembers];

        while (parentQueue.length > 0) {
            const currentParent = parentQueue.shift()!;

            if (currentParent.level >= maxDepth) continue;

            currentParent.children = [];

            for (let i = 0; i < width; i++) {
                if (usersToPlace.length > 0) {
                    const nextUser = usersToPlace.shift()!;
                    const newNode = mapUserToNode(nextUser, currentParent.level + 1);
                    currentParent.children.push(newNode);
                    parentQueue.push(newNode);
                } else {
                    if (currentParent.level < 2) { 
                        const emptyNode = createEmptyNode(currentParent.id, i, currentParent.level + 1);
                        currentParent.children.push(emptyNode);
                    }
                }
            }
        }

        return rootNode;
    }
};
