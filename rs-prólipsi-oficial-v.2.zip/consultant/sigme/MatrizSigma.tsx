
import React, { useState, useMemo, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useUser } from '../ConsultantLayout';
import { NetworkService } from '../services/NetworkService';
import NetworkTree from '../components/NetworkTree';
import Card from '../../components/Card';
import { IconUsers, IconChevronLeft, IconGitFork, IconShoppingCart, IconAward, IconRepeat } from '../../components/icons';
import type { NetworkNode } from '../../types';

interface NetworkReport {
  totalDirects: number;
  activeDirects: number;
  inactiveDirects: number;
  totalDownline: number;
  maxDepth: number;
  downlineWithPurchase: number;
  downlineWithoutPurchase: number;
  pinSummary: { [key: string]: number };
}

const analyzeNetwork = (rootNode: NetworkNode): NetworkReport => {
    const report: NetworkReport = {
        totalDirects: 0,
        activeDirects: 0,
        inactiveDirects: 0,
        totalDownline: 0,
        maxDepth: 0,
        downlineWithPurchase: 0,
        downlineWithoutPurchase: 0,
        pinSummary: {},
    };

    if (!rootNode || !rootNode.children) return report;

    // Directs na Unilevel são filhos diretos.
    const directs = rootNode.children.filter(c => !c.isEmpty);
    report.totalDirects = directs.length;
    
    // Varredura BFS
    const queue: NetworkNode[] = [...rootNode.children];
    const visited = new Set<string>();

    while (queue.length > 0) {
        const node = queue.shift();
        if (!node || node.isEmpty || visited.has(node.id)) continue;
        
        visited.add(node.id);
        report.totalDownline++;
        report.maxDepth = Math.max(report.maxDepth, node.level);

        if (node.status === 'active') report.activeDirects++; 

        if (node.pin && node.pin !== 'Vago' && node.pin !== 'Iniciante') {
            report.pinSummary[node.pin] = (report.pinSummary[node.pin] || 0) + 1;
        }
        
        if (node.children) {
            queue.push(...node.children);
        }
    }
    
    return report;
}

const StatCard: React.FC<{ icon: React.ElementType, title: string, value: string | number, subValue?: string, className?: string }> = ({ icon: Icon, title, value, subValue, className }) => (
    <Card className={`flex items-center space-x-4 ${className}`}>
        <div className="p-3 bg-brand-gray-light rounded-full">
            <Icon size={24} className="text-brand-gold" />
        </div>
        <div>
            <h4 className="text-sm text-brand-text-dim">{title}</h4>
            <p className="text-2xl font-bold text-white">{value}</p>
            {subValue && <p className="text-xs text-brand-text-dim">{subValue}</p>}
        </div>
    </Card>
);

const MatrizSigma: React.FC = () => {
  const { user } = useUser();
  const [report, setReport] = useState<NetworkReport | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
      const loadData = async () => {
          try {
              const allUsers = await NetworkService.fetchAllConsultants();
              // Gera árvore unilevel para estatísticas precisas
              const unilevelTree = NetworkService.buildUnilevelTree(allUsers, user.id);
              if (unilevelTree) {
                  const data = analyzeNetwork(unilevelTree);
                  setReport(data);
              }
          } catch (error) {
              console.error("Erro ao carregar dados da rede:", error);
          } finally {
              setLoading(false);
          }
      };
      if (user.id) {
        loadData();
      }
  }, [user.id]);

  if (loading) return <div className="text-center p-10 text-brand-gold">Carregando dados da rede...</div>;
  if (!report) return <div className="text-center p-10 text-gray-500">Não foi possível carregar os dados.</div>;

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold text-brand-gold">Central de Rede</h1>
      
      <Card>
        <div className="bg-brand-gray p-4 rounded-lg mb-6">
            <h3 className="text-2xl font-bold text-center text-brand-gold">Visão Geral da Equipe</h3>
        </div>
        
        <h2 className="text-xl font-bold text-white mb-4">Relatório da Rede (Unilevel)</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <StatCard icon={IconUsers} title="Total na Rede" value={report.totalDownline} subValue={`Até ${report.maxDepth} níveis de profundidade`} />
          <StatCard icon={IconGitFork} title="Diretos Cadastrados" value={report.totalDirects} subValue="Seus indicados pessoais" />
          <StatCard icon={IconAward} title="Graduados" value={Object.values(report.pinSummary).reduce((a: number, b: number) => a + b, 0)} subValue="Pessoas com PIN na rede" />
        </div>
        <div className="mt-6 pt-6 border-t border-brand-gray-light">
          <h3 className="text-lg font-bold text-white mb-3">Distribuição de PINs na Rede</h3>
          <div className="flex flex-wrap gap-4">
            {Object.entries(report.pinSummary).length > 0 ? Object.entries(report.pinSummary)
              .sort(([, a], [, b]) => Number(b) - Number(a))
              .map(([pin, count]) => (
                <div key={pin} className="flex items-center space-x-2 bg-brand-gray-light px-3 py-2 rounded-lg">
                  <IconAward size={20} className="text-brand-gold"/>
                  <span className="font-semibold text-white">{pin}:</span>
                  <span className="font-mono text-brand-text-light">{count}</span>
                </div>
            )) : <p className="text-brand-text-dim text-sm">Nenhum graduado encontrado.</p>}
          </div>
        </div>
      </Card>

       <Card>
        <div className="text-center p-6">
            <IconUsers size={40} className="mx-auto text-brand-gold mb-4" />
            <h2 className="text-xl font-bold text-white mb-2">Explore sua Rede Completa</h2>
            <p className="text-gray-400 mb-6 max-w-md mx-auto">Visualize a Matriz Forçada (Derramamento) ou sua rede Unilevel em tempo real.</p>
            <div className="flex flex-wrap justify-center gap-4">
                <Link 
                    to={`/consultant/sigme/arvore-interativa/ciclo-global`} 
                    className="inline-flex items-center justify-center gap-2 bg-brand-gold text-brand-dark font-bold py-3 px-6 rounded-lg hover:bg-yellow-400 transition-colors shadow-lg shadow-brand-gold/20"
                >
                    <IconGitFork /> Matriz Forçada (Derramamento)
                </Link>
                 <Link 
                    to={`/consultant/sigme/arvore-interativa/unilevel`} 
                    className="inline-flex items-center justify-center gap-2 bg-brand-gray text-white font-bold py-3 px-6 rounded-lg hover:bg-brand-gray-light transition-colors border border-brand-gray-light"
                >
                    <IconUsers /> Unilevel (Indicação)
                </Link>
            </div>
        </div>
      </Card>
    </div>
  );
};

export const ArvoreInterativaPage: React.FC = () => {
  const { user } = useUser();
  const { type } = useParams<{ type: string }>(); // 'ciclo-global', 'bonus-profundidade', 'bonus-fidelidade', 'unilevel'
  const navigate = useNavigate();
  const [rootNode, setRootNode] = useState<NetworkNode | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
      const buildTree = async () => {
          setLoading(true);
          try {
              const allUsers = await NetworkService.fetchAllConsultants();
              let tree: NetworkNode | null = null;

              // Identificar se o usuário atual é a "Empresa/Admin"
              // Se sim, usa o ID fixo da empresa como raiz. Se não, usa o ID do usuário logado.
              // Isso garante que se você logar como Admin, veja TUDO.
              const isCompanyUser = user.username === 'admin' || user.name === 'RS Prólipsi' || user.id === '7838667';
              const rootId = isCompanyUser ? '7838667' : user.id;

              if (type === 'unilevel' || type === 'plano-carreira' || type === 'top-sigme') {
                  // Unilevel: Respeita quem indicou quem (Sponsor ID)
                  tree = NetworkService.buildUnilevelTree(allUsers, rootId);
              } else {
                  // Matriz Forçada (Ciclo, Profundidade, Fidelidade)
                  // Regra: Derramamento por DATA DE CADASTRO na estrutura 6xN
                  const width = 6;
                  const depth = type === 'ciclo-global' ? 2 : 6; 
                  
                  // Esta função agora ordena por Data de Cadastro e preenche sequencialmente
                  tree = NetworkService.buildForcedMatrixTree(allUsers, rootId, width, depth);
              }

              setRootNode(tree);
          } catch (err: any) {
              console.error("Erro building tree:", err);
              setError("Erro ao carregar a estrutura da rede. Verifique sua conexão com o banco de dados.");
          } finally {
              setLoading(false);
          }
      };

      if (user.id) {
        buildTree();
      }
  }, [type, user.id, user.username, user.name]);

  let title = 'Árvore da Rede';
  if (type === 'ciclo-global') title = 'Matriz Forçada (Derramamento por Data)';
  if (type === 'bonus-profundidade') title = 'Matriz Profundidade (6x6)';
  if (type === 'bonus-fidelidade') title = 'Matriz Fidelidade';
  if (type === 'unilevel') title = 'Rede Unilevel (Patrocínio)';

  const handleBack = () => navigate(-1);

  if (loading) return <div className="min-h-screen flex items-center justify-center text-brand-gold bg-brand-dark"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-gold mr-4"></div> Carregando estrutura...</div>;
  if (error) return <div className="min-h-screen flex items-center justify-center text-red-500 bg-brand-dark p-4 text-center">{error}</div>;
  if (!rootNode) return <div className="min-h-screen flex items-center justify-center text-gray-500 bg-brand-dark">Nenhuma rede encontrada para este usuário.</div>;

  return (
    <div className="h-full flex flex-col">
        <div className="flex items-center mb-4 px-4 pt-4">
             <button onClick={handleBack} className="flex items-center text-brand-gold font-semibold p-2 rounded-lg hover:bg-brand-gray-light">
                <IconChevronLeft size={20} className="mr-1"/>
                Voltar
            </button>
        </div>
      <div className="flex-grow relative">
        <NetworkTree 
          title={title}
          rootNode={rootNode}
        />
      </div>
    </div>
  );
};

export default MatrizSigma;
