
import React, { useState, createContext, useContext, useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import ChatbotWidget from './components/ChatbotWidget';
import type { User, SystemMessage, Incentive, DashboardConfig } from '../types';
import { useLayout } from '../context/LayoutContext';
import { supabase } from '../lib/supabase';
import { mockUser } from './data';

// User Context
export interface UserContextType {
  user: User;
  updateUser: (newUserData: Partial<User>) => void;
  messages: SystemMessage[];
  markMessageAsRead: (messageId: string) => void;
  credits: number;
  setCredits: React.Dispatch<React.SetStateAction<number>>;
  isAuthenticated: boolean;
  login: (email: string, pass: string) => Promise<{ error: any }>;
  logout: () => Promise<void>;
  isLoading: boolean;
}

export const UserContext = createContext<UserContextType | null>(null);

export const useUser = () => {
    const context = useContext(UserContext);
    if (!context) {
        throw new Error('useUser must be used within a UserProvider');
    }
    return context;
};


// Dashboard Config Context
// NOTE: Types moved to ../types.ts to avoid circular dependencies and for better organization
export interface DashboardConfigContextType {
  config: DashboardConfig;
  setConfig: React.Dispatch<React.SetStateAction<DashboardConfig>>;
}

export const DashboardConfigContext = createContext<DashboardConfigContextType | null>(null);

export const useDashboardConfig = () => {
  const context = useContext(DashboardConfigContext);
  if (!context) {
    throw new Error('useDashboardConfig must be used within a DashboardConfigProvider');
  }
  return context;
}

const ConsultantLayout: React.FC = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, updateUser, messages, setCredits } = useUser();
  const { layoutMode } = useLayout();
  const isFocusMode = layoutMode === 'focus';

  // --- REAL DATA FETCHING ---
  useEffect(() => {
    if (!user || !user.id) return;

    const fetchRealData = async () => {
      try {
        // 1. Fetch Profile Data (Already handled in App.tsx but good to ensure fields)
        // ... handled in App.tsx handleUserSession

        // 2. Fetch Wallet Transactions to calculate Balance
        const { data: transactions, error: txError } = await supabase
          .from('wallet_transactions')
          .select('amount')
          .eq('user_id', user.id);

        if (!txError && transactions) {
          const totalBalance = transactions.reduce((acc, t) => acc + t.amount, 0);
          // Assuming user.credits stores the wallet balance or a separate credits system
          // For now, let's map balance to credits for the chatbot if needed, or just log it
          // updateUser({ totalEarnings: totalBalance }); // If you add this field to types
        }

        // 3. Fetch Messages (Updated to use 'notifications' table)
        const { data: msgs, error: msgError } = await supabase
          .from('notifications') 
          .select('*')
          .eq('user_id', user.id) 
          .order('created_at', { ascending: false });
        
        // Note: setMessages is not exposed directly from useUser in App.tsx implementation, 
        // ideally App.tsx should handle global data fetching or expose setMessages. 
        // For this refactor, we are limited to what ContextProviders exposes.
        // Assuming context provider handles initial load or we would need to lift setMessages state.

      } catch (error) {
        console.error("Error fetching real data in layout:", error);
      }
    };

    fetchRealData();
  }, [user.id]);

  return (
      <div className="flex h-screen bg-brand-dark font-sans overflow-hidden">
        <div className={`
            ${isFocusMode ? 'hidden' : 'hidden md:flex'} 
            md:flex-shrink-0 transition-all duration-300 
            ${isSidebarCollapsed ? 'w-20' : 'w-64'}
          `}>
            <Sidebar isCollapsed={isSidebarCollapsed} />
        </div>

        {!isFocusMode && (
            <>
                <div
                  className={`fixed inset-0 bg-black/60 z-30 md:hidden transition-opacity duration-300 ${isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
                  onClick={() => setIsMobileMenuOpen(false)}
                  aria-hidden="true"
                ></div>
                <div className={`fixed inset-y-0 left-0 w-64 z-40 transform transition-transform duration-300 ease-in-out md:hidden ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
                  <Sidebar isCollapsed={false} closeSidebar={() => setIsMobileMenuOpen(false)} />
                </div>
            </>
        )}


        <div className="flex-1 flex flex-col overflow-hidden">
          {!isFocusMode && (
              <Topbar 
                user={user} 
                onMenuClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
                isSidebarCollapsed={isSidebarCollapsed}
              />
          )}

          <main className={`flex-1 overflow-y-auto ${isFocusMode ? '' : 'p-4 sm:p-6 md:p-8'}`}>
            <div className={isFocusMode ? 'h-full' : 'max-w-7xl mx-auto'}>
              <Outlet />
            </div>
          </main>
        </div>
        
        {!isFocusMode && <ChatbotWidget />}
      </div>
  );
};

export default ConsultantLayout;
