
import React, { FC, useMemo, useState, useEffect } from 'react';
import Card from '../components/Card';
import { mockCareerPlan, mockPromoBanners } from './data';
import * as icons from '../components/icons';
import { useUser, useDashboardConfig } from './ConsultantLayout';
import { Link } from 'react-router-dom';
import type { NetworkNode } from '../types';

const { IconCopy, IconAward, IconGitFork, IconStar, IconHandCoins, IconChevronLeft, IconChevronRight, IconUsers, IconShop, IconSparkles, IconMessage, IconWallet, IconDashboard } = icons;

const formatCurrency = (value: number | string | null | undefined): string => {
    if (value == null || value === '') {
        return 'R$ 0,00';
    }
    const num = typeof value === 'string' ? parseFloat(value) : value;
    if (isNaN(num)) {
        return 'R$ 0,00';
    }
    return num.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
};

const InfoLine: FC<{ label: string; value: string; valueClassName?: string }> = ({ label, value, valueClassName = '' }) => (
    <div className="flex justify-between items-center text-sm">
        <span className="text-brand-text-dim">{label}:</span>
        <span className={`font-semibold text-brand-text-light text-right ${valueClassName}`}>{value}</span>
    </div>
);

const CopyableLink: FC<{ label: string; link: string; }> = ({ label, link }) => {
    const [copied, setCopied] = React.useState(false);
    const handleCopy = () => {
        if (!link) return;
        navigator.clipboard.writeText(link);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };
    return (
        <div>
            <label className="text-sm text-brand-text-dim mb-1 block">{label}</label>
            <div className="flex">
                <input type="text" readOnly value={link || 'Link não gerado'} className="w-full bg-brand-dark text-brand-text-dim text-sm p-2 rounded-l-md border border-brand-gray-light focus:outline-none" />
                <button onClick={handleCopy} className={`w-12 h-10 flex items-center justify-center rounded-r-md text-brand-dark transition-colors ${copied ? 'bg-green-500' : 'bg-brand-gold hover:bg-yellow-400'}`}>
                    <IconCopy size={18} />
                </button>
            </div>
        </div>
    );
};

const UserInfoCard: FC = () => {
    const { user } = useUser();
    const { config } = useDashboardConfig();

    const statusDisplayMap: Record<string, {value: string, className: string}> = {
        active: { value: 'Ativo', className: 'text-sky-400' },
        inactive: { value: 'Inativo', className: 'text-red-400' },
        pending: { value: 'Pendente', className: 'text-yellow-400' },
    };

    return (
    <Card>
        <div className="flex items-center space-x-4 mb-6">
            <img src={user.avatarUrl || 'https://via.placeholder.com/150'} alt={user.name} className="h-20 w-20 rounded-full border-4 border-brand-gray-light shadow-lg" />
            <div>
                <h3 className="text-lg font-bold text-brand-text-light">{user.name}</h3>
                <p className="text-sm text-brand-text-dim">ID: {user.idConsultor || '...'}</p>
            </div>
        </div>
        <div className="space-y-3">
            {config.userInfo.map(field => {
                const rawValue = user[field.source as keyof typeof user] as string;
                const display = statusDisplayMap[rawValue] || { value: rawValue || '-', className: 'text-brand-gold uppercase font-bold' };
                
                return (
                    <InfoLine 
                        key={field.id} 
                        label={field.label} 
                        value={display.value} 
                        valueClassName={display.className} 
                    />
                );
            })}
            
            <div className="!mt-6 pt-6 border-t border-brand-gray-light space-y-4">
                {config.links.map(link => (
                    <CopyableLink 
                        key={link.id}
                        label={link.label} 
                        link={user[link.source as keyof typeof user] as string} 
                    />
                ))}
            </div>
        </div>
    </Card>
)};

const StatCard: FC<{ title: string, value: string, icon: string }> = ({ title, value, icon }) => {
  const Icon = icons[icon as keyof typeof icons] || IconAward;
  return (
    <Card>
        <div className="flex items-center space-x-4">
            <div className="p-3 bg-brand-gold/20 rounded-full">
                <Icon size={24} className="text-brand-gold" />
            </div>
            <div>
                <h4 className="text-sm text-brand-text-dim uppercase">{title}</h4>
                <p className="text-2xl font-bold text-white" style={{ textShadow: '0 0 6px rgba(255, 255, 255, 0.3)' }}>{value}</p>
            </div>
        </div>
    </Card>
)};

const MatrixOverviewCard: FC = () => {
    const { user } = useUser();
    // Using mock plan for structure, but user data for values
    const currentCycles = user.totalCycles || 0;
    const { pinTable } = mockCareerPlan;

    // Safety check: ensure pinTable is valid
    if (!pinTable || pinTable.length === 0) return null;

    const nextPin = pinTable.find(p => p.cycles > currentCycles) || pinTable[pinTable.length - 1];

    return (
        <Card className="bg-gradient-to-br from-brand-gray to-brand-gray-dark border-2 border-brand-gold shadow-gold-glow">
            <h4 className="font-bold text-brand-text-light mb-4 flex items-center gap-2"><IconGitFork size={20} className="text-brand-gold"/> Visão Geral da Matriz SIGME</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="p-3 bg-brand-gray-light rounded-lg">
                    <p className="text-sm text-brand-text-dim">Ciclos Atuais</p>
                    <p className="text-2xl font-bold text-white">{currentCycles}</p>
                </div>
                <div className="p-3 bg-brand-gray-light rounded-lg">
                    <p className="text-sm text-brand-text-dim">Bônus Total SIGME</p>
                    <p className="text-2xl font-bold text-white">{formatCurrency((user.bonusCicloGlobal || 0) + (user.bonusTopSigme || 0) + (user.bonusPlanoCarreira || 0))}</p>
                </div>
                <div className="p-3 bg-brand-gray-light rounded-lg">
                    <p className="text-sm text-brand-text-dim">Próximo PIN</p>
                    <p className="text-2xl font-bold text-brand-gold">{nextPin?.pin || 'N/A'}</p>
                </div>
            </div>
        </Card>
    );
};

const PinProgressGauge: FC = () => {
    const { user } = useUser();
    const { config } = useDashboardConfig();
    const { pinTable } = mockCareerPlan;
    
    // Safety check: ensure pinTable is valid
    if (!pinTable || pinTable.length === 0) return null;

    const currentCycles = user.totalCycles || 0;

    let currentPinIndex = -1;
    for (let i = pinTable.length - 1; i >= 0; i--) {
        if (currentCycles >= pinTable[i].cycles) {
            currentPinIndex = i;
            break;
        }
    }
    const currentPin = currentPinIndex !== -1 ? pinTable[currentPinIndex] : { pin: 'Iniciante', cycles: 0, bonus: 0, iconColor: '#9ca3af' };
    const nextPin = currentPinIndex < pinTable.length - 1 ? pinTable[currentPinIndex + 1] : currentPin;
    
    const startCycles = currentPin.cycles;
    const endCycles = nextPin.cycles;
    const range = endCycles - startCycles;
    const progressInCycles = currentCycles - startCycles;

    const progress = range > 0 ? Math.min(100, (progressInCycles / range) * 100) : (currentCycles >= endCycles ? 100 : 0);

    const radius = 100;
    const trackStrokeWidth = 20;
    const progressStrokeWidth = 16;
    const circumference = Math.PI * radius;
    const offset = circumference - (circumference * progress / 100);

    const currentPinLogo = config.pinLogos[currentPin.pin];
    const nextPinLogo = config.pinLogos[nextPin.pin];
    
    const nextPinColor = nextPin.iconColor || '#0f52ba';

    return (
        <>
        <style>{`
            @keyframes pulse-glow {
                0%, 100% { filter: drop-shadow(0 0 6px ${nextPinColor}99); }
                50% { filter: drop-shadow(0 0 16px ${nextPinColor}); }
            }
            .animate-pulse-glow { animation: pulse-glow 2.5s ease-in-out infinite; }
        `}</style>
        <Card>
            <h4 className="font-bold text-brand-text-light mb-2 text-center">Seu Progresso de Carreira</h4>
            <div className="relative w-full" style={{ height: '240px' }}>
                <svg width="100%" height="100%" viewBox="0 0 240 155" className="absolute top-0 left-0 overflow-visible">
                    <defs>
                        <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" stopColor="#2dd4bf" />
                            <stop offset="100%" stopColor="#34d399" />
                        </linearGradient>
                    </defs>
                    <path
                        d="M 20 125 A 100 100 0 0 1 220 125"
                        stroke="#2A2A2A"
                        strokeWidth={trackStrokeWidth}
                        strokeLinecap="round"
                        fill="none"
                    />
                    <path
                        d="M 20 125 A 100 100 0 0 1 220 125"
                        stroke="url(#progressGradient)"
                        strokeWidth={progressStrokeWidth}
                        strokeLinecap="round"
                        fill="none"
                        strokeDasharray={circumference}
                        strokeDashoffset={offset}
                        className="animate-pulse-glow"
                        style={{ transition: 'stroke-dashoffset 0.8s ease-out' }}
                    />
                </svg>
                
                <div className="absolute inset-0 flex flex-col items-center justify-end pb-16">
                    <p className="text-sm text-gray-400 font-medium">{currentCycles} / {endCycles} Ciclos</p>
                    <p className="text-6xl font-extrabold text-white my-1">{Math.floor(progress)}%</p>
                    <p className="text-base text-gray-300">Completo</p>
                </div>

                <div className="absolute bottom-0 w-full flex justify-between items-baseline px-4">
                    <div className="flex flex-col items-center text-center w-24">
                        {currentPinLogo ? <img src={currentPinLogo} alt={currentPin.pin} className="h-12 w-12 object-contain mb-1" /> : <IconAward className="h-12 w-12 mb-1" style={{ color: currentPin.iconColor }} />}
                        <span className="font-bold mt-1 text-sm text-white">{currentPin.pin} Atual</span>
                    </div>
                    <div className="flex flex-col items-center text-center w-24">
                        {nextPinLogo ? <img src={nextPinLogo} alt={nextPin.pin} className="h-12 w-12 object-contain mb-1" /> : <IconAward className="h-12 w-12 mb-1" style={{ color: nextPin.iconColor }} />}
                        <span className="font-bold mt-1 text-sm text-white">{nextPin.pin} Próximo</span>
                    </div>
                </div>
            </div>
        </Card>
        </>
    );
};


const PromoBannerCarousel: FC = () => {
    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentIndex(prev => (prev + 1) % mockPromoBanners.length);
        }, 5000);
        return () => clearInterval(timer);
    }, []);

    const goToSlide = (index: number) => setCurrentIndex(index);

    return (
        <Card className="p-0 overflow-hidden relative aspect-[2/1] md:aspect-[3/1]">
            {mockPromoBanners.map((banner, index) => (
                <div key={banner.id} className={`absolute inset-0 transition-opacity duration-1000 ${index === currentIndex ? 'opacity-100' : 'opacity-0'}`}>
                    <img src={banner.imageUrl} alt={banner.title} className="w-full h-full object-cover"/>
                    <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-transparent p-6 flex flex-col justify-center">
                         <h4 className="text-sm font-bold text-brand-gold uppercase tracking-widest">{banner.preTitle}</h4>
                         <h3 className="text-2xl md:text-4xl font-extrabold text-white mt-1">{banner.title}</h3>
                         <button className="mt-4 bg-brand-gold text-brand-dark font-bold py-2 px-4 rounded-lg hover:bg-yellow-400 transition-colors self-start text-sm">
                             {banner.ctaText}
                         </button>
                    </div>
                </div>
            ))}
             <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                {mockPromoBanners.map((_, index) => (
                    <button key={index} onClick={() => goToSlide(index)} className={`h-2 w-2 rounded-full transition-all ${index === currentIndex ? 'w-4 bg-brand-gold' : 'bg-white/50'}`}></button>
                ))}
            </div>
        </Card>
    );
};

const EmbeddedMatrixView: FC = () => {
    // In a real scenario, we'd fetch the user's first level children here
    // For now, let's just show an empty state or a prompt to view the full tree
    return (
        <Card>
            <div className="flex justify-between items-center mb-4">
                <h4 className="font-bold text-brand-text-light flex items-center gap-2"><IconUsers size={20} className="text-brand-gold"/> Meus Indicados Diretos</h4>
                <Link to="/consultant/sigme/arvore-interativa/directs" className="text-sm text-brand-gold font-semibold">Ver Rede &rarr;</Link>
            </div>
            <div className="flex justify-center items-center py-8 text-brand-text-dim">
                <p>Acesse a árvore interativa para ver sua rede em tempo real.</p>
            </div>
        </Card>
    );
};

const ShortcutIconsCard: FC = () => {
    const shortcuts = [
        { label: 'Dashboard', icon: IconDashboard, path: '/consultant/dashboard' },
        { label: 'RS Shop', icon: IconShop, path: '/consultant/shop/marketplace' },
        { label: 'RS Studio', icon: IconSparkles, path: '/consultant/studio' },
        { label: 'Comunicação', icon: IconMessage, path: '/consultant/comunicacao' },
        { label: 'Wallet', icon: IconWallet, path: '/consultant/wallet' },
        { label: 'Matriz SIGME', icon: IconGitFork, path: '/consultant/sigme/ciclo-global' },
    ];

    return (
        <Card>
            <h4 className="font-bold text-brand-text-light mb-4">Acesso Rápido</h4>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-4 text-center">
                {shortcuts.map(shortcut => (
                    <Link to={shortcut.path} key={shortcut.label} title={shortcut.label} className="flex flex-col items-center gap-2 p-2 rounded-lg hover:bg-brand-gray-light transition-colors group">
                        <div className="p-3 bg-brand-gray-light rounded-full group-hover:bg-brand-gold transition-colors">
                            <shortcut.icon size={24} className="text-brand-gold group-hover:text-brand-dark transition-colors" />
                        </div>
                    </Link>
                ))}
            </div>
        </Card>
    );
};


const Dashboard: React.FC = () => {
  const { user } = useUser();
  const { config } = useDashboardConfig();

    const bonusSourceMap: Record<string, { title: string; icon: string }> = {
        bonusCicloGlobal: { title: 'Bônus Ciclo Global', icon: 'IconGitFork' },
        bonusTopSigme: { title: 'Bônus Matriz SIGME', icon: 'IconStar' },
        bonusPlanoCarreira: { title: 'Plano de Carreira', icon: 'IconAward' },
    };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column */}
        <div className="lg:col-span-4 space-y-6">
            <UserInfoCard />
             <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-1 gap-6">
                {config.bonusCards.map(card => {
                    const cardInfo = bonusSourceMap[card.source] || { title: 'Bônus', icon: 'IconAward' };
                    const value = user[card.source as keyof typeof user] as number || 0;
                    return (
                        <StatCard 
                            key={card.id}
                            title={cardInfo.title} 
                            value={formatCurrency(value)}
                            icon={cardInfo.icon} 
                        />
                    );
                })}
            </div>
            <ShortcutIconsCard />
        </div>

        {/* Right Column */}
        <div className="lg:col-span-8 space-y-6">
            <PromoBannerCarousel />
            <MatrixOverviewCard />
            <PinProgressGauge />
            <EmbeddedMatrixView />
        </div>
    </div>
  );
};

export default Dashboard;
