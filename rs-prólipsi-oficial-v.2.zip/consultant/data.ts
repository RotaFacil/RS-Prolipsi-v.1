
import { 
    User, SystemMessage, Incentive, DashboardConfig, CycleInfo, NetworkNode, 
    WalletTransaction, Invoice, Subscription, AnticipationRequest, 
    CDInfo, CDProduct, CDConsultantOrder, CDInventoryItem, 
    Course, UserOrder, StoreConfig, MarketplaceProduct, MarketplaceOrder, MarketplaceStats,
    Pixel, ShortenedLink, AffiliateSeller
} from '../types';

export const mockUser: User = {
    id: '9772169',
    name: 'Emanuel Claro',
    email: 'emanuel@example.com',
    avatarUrl: 'https://i.pravatar.cc/300?u=emanuel',
    whatsapp: '11999999999',
    status: 'active',
    role: 'user',
    pin: 'Diamante',
    cpfCnpj: '123.456.789-00',
    birthDate: '1990-01-01',
    registrationDate: '2023-01-15',
    hasPurchased: true,
    address: {
        zipCode: '01001-000',
        street: 'Av. Paulista',
        number: '1000',
        neighborhood: 'Bela Vista',
        city: 'São Paulo',
        state: 'SP'
    },
    bankAccount: {
        bank: 'Nubank',
        agency: '0001',
        accountNumber: '12345-6',
        accountType: 'checking',
        pixKey: 'emanuel@example.com'
    },
    idConsultor: 'ec9772',
    linkIndicacao: 'https://rsprolipsi.com/register/ec9772',
    linkAfiliado: 'https://rsprolipsi.com/store/loja-do-emanuel',
    personalVolume: 1250,
    groupVolume: 45000,
    totalVolume: 46250,
    bonusCicloGlobal: 1540.00,
    bonusTopSigme: 350.00,
    bonusPlanoCarreira: 2000.00,
    totalCycles: 78,
    upline: {
        id: '1001',
        username: 'lider1',
        name: 'Líder Supremo',
        avatarUrl: 'https://i.pravatar.cc/300?u=lider',
        idConsultor: 'ls1001',
        whatsapp: '11888888888'
    }
};

export const mockSystemMessages: SystemMessage[] = [
    { id: 'msg1', title: 'Bem-vindo ao novo painel!', content: 'Explore as novas funcionalidades da sua área de consultor.', date: 'Hoje', read: false, type: 'announcement' },
    { id: 'msg2', title: 'Pagamento Processado', content: 'Seu saque de R$ 500,00 foi processado com sucesso.', date: 'Ontem', read: true, type: 'alert' },
];

export const mockCareerPlan = {
    currentCycles: 78,
    pinTable: [
        { pin: 'Bronze', cycles: 5, minLines: 0, vmec: '—', bonus: 13.50, iconColor: '#cd7f32' },
        { pin: 'Prata', cycles: 15, minLines: 1, vmec: '100', bonus: 40.50, iconColor: '#c0c0c0' },
        { pin: 'Ouro', cycles: 70, minLines: 1, vmec: '100', bonus: 189.00, iconColor: '#ffd700' },
        { pin: 'Safira', cycles: 150, minLines: 2, vmec: '60/40', bonus: 405.00, iconColor: '#0f52ba' },
        { pin: 'Esmeralda', cycles: 300, minLines: 2, vmec: '60/40', bonus: 810.00, iconColor: '#50c878' },
        { pin: 'Diamante', cycles: 1500, minLines: 3, vmec: '50/30/20', bonus: 4050.00, iconColor: '#b9f2ff' },
    ]
};

export const mockPromoBanners = [
    { id: '1', preTitle: 'LANÇAMENTO', title: 'Kit Verão 2025', price: 299.90, imageUrl: 'https://images.unsplash.com/photo-1526947425960-945c6e72858f?w=800&q=80', ctaText: 'Comprar Agora' },
    { id: '2', preTitle: 'OFERTA', title: 'Relógios Premium', price: 499.90, imageUrl: 'https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=800&q=80', ctaText: 'Ver Detalhes' },
];

export const mockCycleSummary = [
    { level: '1', bonus: 450.00, completed: 3 },
    { level: '2', bonus: 120.00, completed: 1 },
    { level: '3', bonus: 0, completed: 0 },
];

export const mockCycleInfo: CycleInfo[] = [
    { level: 1, completed: false, participants: [mockUser], personalConsumption: 100, cycleTotal: 500, divisionBase: 100, amountReceived: 0 }
];

export const mockCDProducts: CDProduct[] = [
    { id: 'p1', name: 'Kit Ativação Mensal', fullPrice: 360.00, discount: 0, imageUrl: 'https://via.placeholder.com/150', category: 'Kits', commission: 0, details: { mainVideoId: '', description: '', keyMetrics: [], videoGallery: [] } },
    { id: 'p2', name: 'Perfume Essencial', fullPrice: 150.00, discount: 10, imageUrl: 'https://via.placeholder.com/150', category: 'Perfumaria', commission: 15, details: { mainVideoId: '', description: '', keyMetrics: [], videoGallery: [] } }
];

export const mockDistributionCenters: CDInfo[] = [
    { name: 'CD Matriz SP', email: 'cd.sp@rs.com', phone: '11999998888', address: { city: 'São Paulo', state: 'SP', street: 'Rua A', number: '1', zipCode: '00000-000', neighborhood: 'Centro' }, isFederalSede: true, payment: { pixKey: { type: 'cnpj', key: '00.000.000/0001-00' }, apiKeys: { mercadoPago: '', pagSeguro: '', cielo: '', getnet: '', stone: '', pagoFacil: '', redLink: '', emax: '' } }, shipping: { allowLocalPickup: true, apiKeys: { melhorEnvio: '', loggi: '', superFrete: '', correios: '', frenet: '' } } },
    { name: 'CD Rio de Janeiro', email: 'cd.rj@rs.com', phone: '21999997777', address: { city: 'Rio de Janeiro', state: 'RJ', street: 'Rua B', number: '2', zipCode: '20000-000', neighborhood: 'Centro' }, isFederalSede: false, payment: { pixKey: { type: 'email', key: 'cd.rj@rs.com' }, apiKeys: { mercadoPago: '', pagSeguro: '', cielo: '', getnet: '', stone: '', pagoFacil: '', redLink: '', emax: '' } }, shipping: { allowLocalPickup: true, apiKeys: { melhorEnvio: '', loggi: '', superFrete: '', correios: '', frenet: '' } } }
];

export const mockWalletTransactions: WalletTransaction[] = [
    { id: 't1', date: '2023-10-25', description: 'Bônus Ciclo 1', amount: 150.00, type: 'commission_cycle', status: 'completed' },
    { id: 't2', date: '2023-10-24', description: 'Saque', amount: -500.00, type: 'withdrawal', status: 'completed' },
    { id: 't3', date: '2023-10-22', description: 'Venda Loja', amount: 45.00, type: 'commission_shop', status: 'completed' }
];

export const mockFullNetwork: NetworkNode = {
    ...mockUser,
    level: 0,
    children: [
        { ...mockUser, id: 'child1', name: 'Filho 1', children: [], level: 1, isEmpty: false },
        { ...mockUser, id: 'child2', name: 'Filho 2', children: [], level: 1, isEmpty: false }
    ]
};

export const mockDeepNetwork = mockFullNetwork;

export const countNetworkNodes = (node: NetworkNode): number => {
    if (!node || node.isEmpty) return 0;
    let count = 1;
    if (node.children) {
        node.children.forEach(child => count += countNetworkNodes(child));
    }
    return count;
};

export const mockNetworkReport = [
    { id: '1', name: 'Ana Souza', pin: 'Prata', status: 'active', joinDate: '2023-02-10', personalVolume: 300, groupVolume: 1500, lastActivity: '2023-10-25', whatsapp: '11999991111', avatarUrl: 'https://i.pravatar.cc/150?u=ana', totalCycles: 12 },
    { id: '2', name: 'Carlos Lima', pin: 'Iniciante', status: 'inactive', joinDate: '2023-05-20', personalVolume: 0, groupVolume: 0, lastActivity: '2023-09-10', whatsapp: '11999992222', avatarUrl: 'https://i.pravatar.cc/150?u=carlos', totalCycles: 0 }
];

export const mockBonusDepthData = [
    { level: 1, bonusPerPerson: 1.72, peopleTarget: 6, cycles: [{ cycleNumber: 1, peopleCompleted: 6, status: 'completed' }] },
    { level: 2, bonusPerPerson: 1.96, peopleTarget: 36, cycles: [{ cycleNumber: 1, peopleCompleted: 12, status: 'in_progress' }] }
];

export const mockBonusFidelityData = [
    { level: 1, percent: 7, value: 0.315, bonusPerPerson: 0.315, peopleTarget: 6, cycles: [{ cycleNumber: 1, peopleCompleted: 6, status: 'completed' }] }
];

export const mockBonuses = [
    { id: 'b1', date: '2023-10-20', type: 'Unilevel', source: 'Ana Souza', status: 'pago', amount: 15.00 }
];

export const mockTopSigmeRanking = [
    { position: 1, name: 'Emanuel Claro', cycles: 78, earnings: 15000.00, avatarUrl: 'https://i.pravatar.cc/150?u=emanuel' },
    { position: 2, name: 'Maria Silva', cycles: 70, earnings: 12000.00, avatarUrl: 'https://i.pravatar.cc/150?u=maria' },
    { position: 3, name: 'João Santos', cycles: 65, earnings: 10000.00, avatarUrl: 'https://i.pravatar.cc/150?u=joao' }
];

export const mockTopSigmeMonthlySummary = {
    totalGlobalCycles: 1500,
    totalDistributed: 45000.00,
    closingDate: '31/10/2023'
};

export const mockTopSigmePersonalStats = {
    myCycles: 12,
    myPoints: 120,
    projectedBonus: 450.00
};

export const mockInvoices: Invoice[] = [
    { id: 'inv1', customerName: 'Cliente A', dueDate: '2023-11-05', amount: 150.00, status: 'pending' }
];

export const mockSubscriptions: Subscription[] = [
    { id: 'sub1', planName: 'Plano VIP', customerName: 'Cliente B', nextBillingDate: '2023-11-10', amount: 99.90, status: 'active' }
];

export const mockAnticipationRequests: AnticipationRequest[] = [
    { id: 'req1', requestDate: '2023-10-20', requestedAmount: 500.00, feeAmount: 25.00, netAmount: 475.00, status: 'approved' }
];

export const mockActivationHistory = [
    { month: 'Outubro/2023', status: 'Ativo', method: 'Saldo Wallet', value: 360.00 },
    { month: 'Setembro/2023', status: 'Ativo', method: 'PIX', value: 360.00 }
];

export const mockStoreConfig: StoreConfig = {
    storeName: 'Loja do Emanuel',
    slug: 'loja-do-emanuel',
    template: 'amazon-pro',
    primaryColor: '#FFD700',
    secondaryColor: '#121212',
    bannerUrl: 'https://via.placeholder.com/1200x400',
    logoUrl: 'https://via.placeholder.com/100',
    heroHeadline: 'Melhores Ofertas',
    heroSubheadline: 'Confira nossos produtos',
    products: ['p1', 'p2'],
    isActive: true
};

export const mockShopCareerPlan = {
    currentRevenue: 15000,
    quarterlyRevenue: 45000,
    monthlyGrowth: [
        { month: 'Ago', revenue: 12000 },
        { month: 'Set', revenue: 14000 },
        { month: 'Out', revenue: 15000 }
    ],
    pinTable: [
        { pin: 'Iniciante', revenue: 0, bonus: 0, iconColor: 'text-gray-500' },
        { pin: 'Bronze', revenue: 5000, bonus: 100, iconColor: 'text-orange-400' },
        { pin: 'Prata', revenue: 15000, bonus: 300, iconColor: 'text-gray-300' },
        { pin: 'Ouro', revenue: 50000, bonus: 1000, iconColor: 'text-yellow-400' }
    ]
};

export const mockCourses: Course[] = [
    { id: 'c1', title: 'Início Rápido', description: 'Como começar na RS Prólipsi', iconName: 'IconBookOpen', modules: [
        { id: 'm1', title: 'Módulo 1: Cadastro', lessons: [{ id: 'l1', title: 'Como cadastrar', videoId: 'abc', completed: true }] }
    ]}
];

export const mockCDInfo: CDInfo = mockDistributionCenters[0];

export const mockCDConsultantOrders: CDConsultantOrder[] = [
    { id: 'ord1', date: '2023-10-26', consultant: { name: 'Ana Souza', email: 'ana@teste.com', phone: '11999991111', avatarUrl: 'https://i.pravatar.cc/150?u=ana' }, items: [{ productId: 'p1', name: 'Kit Ativação', quantity: 1, unitPrice: 360 }], subtotal: 360, shipping: { type: 'pickup', cost: 0 }, total: 360, status: 'completed' }
];

export const mockCDInventory: CDInventoryItem[] = [
    { productId: 'p1', name: 'Kit Ativação Mensal', quantity: 50, unitCost: 200 }
];

export const mockAllConsultants: User[] = [
    mockUser,
    ...mockNetworkReport.map(r => ({
        ...mockUser, 
        id: r.id, 
        name: r.name, 
        pin: r.pin, 
        status: r.status as any,
        avatarUrl: r.avatarUrl,
        username: r.name.toLowerCase().replace(' ', '')
    }))
];

export const mockMarketplaceStats: MarketplaceStats = {
    salesMonth: 12450.00,
    pendingOrders: 8,
    activeProducts: 45,
    ticketAverage: 185.00,
    commissionGenerated: 1200.00,
    salesHistory: [
        { date: '01/10', value: 400 },
        { date: '05/10', value: 850 },
        { date: '10/10', value: 600 },
        { date: '15/10', value: 1200 },
        { date: '20/10', value: 900 },
        { date: '25/10', value: 1500 }
    ]
};

export const mockMarketplaceOrders: MarketplaceOrder[] = [
    { 
        id: 'ORD-001', 
        customer: 'Cliente Final 1', 
        date: '26/10/2023', 
        total: 1250.00, 
        status: 'approved', 
        itemsCount: 2, 
        paymentMethod: 'Credit Card',
        customerInfo: { cpf: '123.123.123-12', email: 'cliente1@email.com', phone: '11999990001' },
        shippingAddress: { street: 'Rua Cliente', number: '10', neighborhood: 'Bairro', city: 'Cidade', state: 'SP', zipCode: '00000-000' },
        items: [{ id: 'p3', name: 'Relógio Luxo', quantity: 1, price: 1250, image: 'https://via.placeholder.com/50' }]
    },
    { 
        id: 'ORD-002', 
        customer: 'Cliente Final 2', 
        date: '25/10/2023', 
        total: 349.00, 
        status: 'shipped', 
        itemsCount: 1, 
        paymentMethod: 'PIX',
        customerInfo: { cpf: '123.123.123-13', email: 'cliente2@email.com', phone: '11999990002' },
        shippingAddress: { street: 'Rua Cliente 2', number: '20', neighborhood: 'Bairro', city: 'Cidade', state: 'RJ', zipCode: '00000-000' },
        items: [{ id: 'p4', name: 'Fone Bluetooth', quantity: 1, price: 349, image: 'https://via.placeholder.com/50' }]
    }
];

export const mockMarketplaceProducts: MarketplaceProduct[] = [
    { id: 'mp1', title: 'Relógio Luxo', sku: 'WATCH-001', price: 1250.00, stock: 10, status: 'active', image: 'https://via.placeholder.com/150', category: 'Relógios', lastUpdated: '2023-10-20' },
    { id: 'mp2', title: 'Fone Bluetooth', sku: 'AUDIO-002', price: 349.00, stock: 50, status: 'active', image: 'https://via.placeholder.com/150', category: 'Eletrônicos', lastUpdated: '2023-10-22' }
];

export const mockUserOrders: UserOrder[] = [
    { id: 'MY-ORD-1', date: '2023-10-15', status: 'completed', total: 360.00, items: [{ productId: 'p1', name: 'Kit Ativação', imageUrl: 'https://via.placeholder.com/50', quantity: 1, unitPrice: 360 }], shipping: { type: 'pickup', cost: 0, address: 'CD Matriz' } }
];

// Ensure Shop Products are defined AFTER other products
export const mockShopProducts = [
    ...mockCDProducts,
    ...mockMarketplaceProducts.map(p => ({
        id: p.id,
        name: p.title,
        fullPrice: p.price * 1.2,
        discount: 20,
        imageUrl: p.image,
        category: p.category,
        price: p.price,
        commission: 10,
        details: { mainVideoId: '', description: '', keyMetrics: [], videoGallery: [] }
    }))
];

export const mockShopSettings = {
    storeSlug: 'loja-do-emanuel',
    payoutMethod: 'wallet'
};

export const mockAffiliateSellers: AffiliateSeller[] = [
    { id: 'seller-1', name: 'Tech Store Brasil', category: 'Eletrônicos', commissionRate: 15, logoUrl: 'https://via.placeholder.com/50' },
    { id: 'seller-2', name: 'Beleza Natural', category: 'Beleza', commissionRate: 20, logoUrl: 'https://via.placeholder.com/50' },
    { id: 'seller-3', name: 'Casa & Conforto', category: 'Casa', commissionRate: 10, logoUrl: 'https://via.placeholder.com/50' }
];

export const mockShortenedLinks: ShortenedLink[] = [
    { id: '1', short: 'https://robot.rs/abcde', original: 'https://longurl.com/product/123', clicks: 50 },
    { id: '2', short: 'https://robot.rs/promo', original: 'https://longurl.com/promo/summer', clicks: 120 }
];

export const mockPixels: Pixel[] = [
    { id: 'px-1', name: 'Face Ads Principal', platform: 'facebook', pixelId: '1234567890', status: 'active', accessToken: 'EAAB...' },
    { id: 'px-2', name: 'Google Ads Remarketing', platform: 'google', pixelId: 'AW-987654321', status: 'active', conversionLabel: 'AbCdEfG' }
];

export const mockDashboardConfig: DashboardConfig = {
    userInfo: [
        { id: 'f1', label: 'Graduação', source: 'pin' },
        { id: 'f2', label: 'Status', source: 'status' }
    ],
    links: [
        { id: 'l1', label: 'Link de Indicação', source: 'linkIndicacao' }
    ],
    promoBanners: mockPromoBanners,
    bonusCards: [
        { id: 'bc1', source: 'bonusCicloGlobal' },
        { id: 'bc2', source: 'bonusTopSigme' }
    ],
    progressBars: {
        'main': { id: 'main', title: 'Próximo PIN', startIcon: 'IconAward', endIcon: 'IconAward', calculationMode: 'auto', targetPin: null }
    },
    pinLogos: {
        'Bronze': 'https://via.placeholder.com/50/cd7f32/ffffff?text=B',
        'Prata': 'https://via.placeholder.com/50/c0c0c0/000000?text=P',
        'Ouro': 'https://via.placeholder.com/50/ffd700/000000?text=O',
        'Diamante': 'https://via.placeholder.com/50/b9f2ff/000000?text=D'
    },
    networkSummary: { source: 'top-sigme' },
    incentives: [
        { id: 'inc1', name: 'Cruzeiro 2025', progress: 65, target: 100 }
    ]
};
