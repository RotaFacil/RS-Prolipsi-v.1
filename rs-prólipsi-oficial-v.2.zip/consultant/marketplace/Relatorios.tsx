
import React from 'react';
import Card from '../../components/Card';
import { IconChart, IconTag, IconMapPin, IconUsers, IconActivity } from '../../components/icons';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const mockTrafficData = [
    { name: 'Seg', visitantes: 120, vendas: 5 },
    { name: 'Ter', visitantes: 150, vendas: 8 },
    { name: 'Qua', visitantes: 200, vendas: 12 },
    { name: 'Qui', visitantes: 180, vendas: 10 },
    { name: 'Sex', visitantes: 250, vendas: 18 },
    { name: 'Sáb', visitantes: 300, vendas: 25 },
    { name: 'Dom', visitantes: 280, vendas: 22 },
];

const mockSourceData = [
    { name: 'Orgânico', value: 45 },
    { name: 'Instagram', value: 30 },
    { name: 'Google Ads', value: 15 },
    { name: 'Email', value: 10 },
];

const MarketplaceRelatorios: React.FC = () => {
    return (
        <div className="space-y-6 animate-fade-in pb-20">
            <h1 className="text-2xl font-bold text-brand-gold flex items-center gap-2"><IconChart/> Relatórios de Desempenho</h1>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <Card className="h-full">
                        <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                            <IconActivity className="text-brand-gold"/> Tráfego vs Conversão (7 Dias)
                        </h3>
                        <div className="h-72 w-full">
                            <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={mockTrafficData}>
                                    <defs>
                                        <linearGradient id="colorVisits" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3}/>
                                            <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                                        </linearGradient>
                                        <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#10B981" stopOpacity={0.3}/>
                                            <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                                        </linearGradient>
                                    </defs>
                                    <XAxis dataKey="name" stroke="#6B7280" fontSize={12} />
                                    <YAxis yAxisId="left" stroke="#3B82F6" fontSize={12} />
                                    <YAxis yAxisId="right" orientation="right" stroke="#10B981" fontSize={12} />
                                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" vertical={false} />
                                    <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: 'none', borderRadius: '8px' }} />
                                    <Area yAxisId="left" type="monotone" dataKey="visitantes" stroke="#3B82F6" fillOpacity={1} fill="url(#colorVisits)" name="Visitantes" />
                                    <Area yAxisId="right" type="monotone" dataKey="vendas" stroke="#10B981" fillOpacity={1} fill="url(#colorSales)" name="Vendas" />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>
                    </Card>
                </div>

                <div className="space-y-6">
                    <Card>
                        <h3 className="text-lg font-bold text-white mb-4">Funil de Vendas</h3>
                        <div className="space-y-4">
                            <div>
                                <div className="flex justify-between text-xs text-gray-400 mb-1">
                                    <span>Visitantes</span> <span>1,480</span>
                                </div>
                                <div className="w-full bg-brand-gray-light h-2 rounded-full"><div className="bg-blue-500 h-2 rounded-full w-full"></div></div>
                            </div>
                            <div>
                                <div className="flex justify-between text-xs text-gray-400 mb-1">
                                    <span>Add ao Carrinho</span> <span>420 (28%)</span>
                                </div>
                                <div className="w-full bg-brand-gray-light h-2 rounded-full"><div className="bg-purple-500 h-2 rounded-full w-[28%]"></div></div>
                            </div>
                            <div>
                                <div className="flex justify-between text-xs text-gray-400 mb-1">
                                    <span>Checkout Iniciado</span> <span>180 (12%)</span>
                                </div>
                                <div className="w-full bg-brand-gray-light h-2 rounded-full"><div className="bg-yellow-500 h-2 rounded-full w-[12%]"></div></div>
                            </div>
                            <div>
                                <div className="flex justify-between text-xs text-gray-400 mb-1">
                                    <span>Compras</span> <span>100 (6.7%)</span>
                                </div>
                                <div className="w-full bg-brand-gray-light h-2 rounded-full"><div className="bg-green-500 h-2 rounded-full w-[6.7%]"></div></div>
                            </div>
                        </div>
                    </Card>

                    <Card>
                        <h3 className="text-lg font-bold text-white mb-4">Origem do Tráfego</h3>
                        <div className="space-y-3">
                            {mockSourceData.map(source => (
                                <div key={source.name} className="flex justify-between items-center">
                                    <span className="text-sm text-gray-300">{source.name}</span>
                                    <div className="flex items-center gap-2">
                                        <div className="w-24 bg-brand-gray-light h-1.5 rounded-full overflow-hidden">
                                            <div className="bg-brand-gold h-full rounded-full" style={{ width: `${source.value}%` }}></div>
                                        </div>
                                        <span className="text-xs text-white font-bold w-8 text-right">{source.value}%</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </Card>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                    <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2"><IconTag className="text-blue-400"/> Produtos Mais Vendidos</h3>
                    <div className="space-y-3">
                        <div className="flex justify-between items-center p-2 bg-brand-gray-light rounded hover:bg-brand-gray transition-colors">
                            <div className="flex items-center gap-3">
                                <div className="w-8 h-8 bg-gray-700 rounded flex items-center justify-center text-xs font-bold text-gray-400">1</div>
                                <span className="text-white text-sm">Smartwatch Pro</span>
                            </div>
                            <span className="text-brand-gold font-bold">142 un.</span>
                        </div>
                        <div className="flex justify-between items-center p-2 bg-brand-gray-light rounded hover:bg-brand-gray transition-colors">
                            <div className="flex items-center gap-3">
                                <div className="w-8 h-8 bg-gray-700 rounded flex items-center justify-center text-xs font-bold text-gray-400">2</div>
                                <span className="text-white text-sm">Fone Bluetooth</span>
                            </div>
                            <span className="text-brand-gold font-bold">98 un.</span>
                        </div>
                        <div className="flex justify-between items-center p-2 bg-brand-gray-light rounded hover:bg-brand-gray transition-colors">
                            <div className="flex items-center gap-3">
                                <div className="w-8 h-8 bg-gray-700 rounded flex items-center justify-center text-xs font-bold text-gray-400">3</div>
                                <span className="text-white text-sm">Kit Perfume</span>
                            </div>
                            <span className="text-brand-gold font-bold">75 un.</span>
                        </div>
                    </div>
                </Card>

                <Card>
                    <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2"><IconUsers className="text-purple-400"/> Top Afiliados</h3>
                    <div className="space-y-3">
                        <div className="flex justify-between items-center p-2 bg-brand-gray-light rounded">
                            <span className="text-white text-sm">Loja do João</span>
                            <span className="text-green-400 font-bold">R$ 4.500</span>
                        </div>
                        <div className="flex justify-between items-center p-2 bg-brand-gray-light rounded">
                            <span className="text-white text-sm">Maria Cosméticos</span>
                            <span className="text-green-400 font-bold">R$ 3.200</span>
                        </div>
                        <div className="flex justify-between items-center p-2 bg-brand-gray-light rounded">
                            <span className="text-white text-sm">Pedro Tech</span>
                            <span className="text-green-400 font-bold">R$ 2.100</span>
                        </div>
                    </div>
                </Card>
            </div>
        </div>
    );
};

export default MarketplaceRelatorios;
