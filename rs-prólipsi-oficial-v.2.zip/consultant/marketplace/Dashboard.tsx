
import React, { useState, useEffect } from 'react';
import { 
    IconStore, IconChart, IconExternalLink, IconSettings, 
    IconBox, IconTruck, IconUsers, IconWallet, IconBell, IconPlus
} from '../../components/icons';
import Card from '../../components/Card';
import { mockMarketplaceStats, mockMarketplaceOrders, mockStoreConfig } from '../data';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const StatCard: React.FC<{ title: string; value: string; icon: React.ElementType; color: string; subtext?: string }> = ({ title, value, icon: Icon, color, subtext }) => (
    <Card className="flex items-center space-x-4 border-l-4" style={{ borderColor: color }}>
        <div className={`p-3 rounded-full bg-opacity-20`} style={{ backgroundColor: color + '33' }}>
            <Icon size={24} style={{ color: color }} />
        </div>
        <div>
            <p className="text-gray-400 text-xs uppercase font-bold">{title}</p>
            <p className="text-2xl font-bold text-white">{value}</p>
            {subtext && <p className="text-xs text-gray-500 mt-1">{subtext}</p>}
        </div>
    </Card>
);

const MarketplaceDashboard: React.FC = () => {
    const [slug, setSlug] = useState(mockStoreConfig.slug);

    useEffect(() => {
        const saved = localStorage.getItem('userStoreConfig');
        if (saved) {
            const config = JSON.parse(saved);
            if (config.slug) setSlug(config.slug);
        }
    }, []);

    const handleOpenStore = () => {
        // Lógica robusta de URL absoluta
        const baseUrl = window.location.origin + window.location.pathname;
        const storeUrl = `${baseUrl}#/store/${slug}`;
        window.open(storeUrl, '_blank');
    };

    return (
        <div className="space-y-8 animate-fade-in">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-brand-gray p-6 rounded-xl border border-brand-gray-light shadow-lg">
                <div className="flex items-center gap-4">
                    <div className="bg-brand-gold p-3 rounded-lg text-brand-dark">
                        <IconStore size={32} />
                    </div>
                    <div>
                        <h1 className="text-2xl font-bold text-white">Central do Vendedor</h1>
                        <p className="text-gray-400 text-sm">Gerencie seu inventário e acompanhe sua performance.</p>
                    </div>
                </div>
                <div className="flex gap-3">
                    <button className="flex items-center gap-2 bg-brand-gray-light text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors border border-gray-600">
                        <IconSettings size={18} /> Configurações
                    </button>
                    <button 
                        onClick={handleOpenStore}
                        className="flex items-center gap-2 bg-brand-gold text-brand-dark font-bold py-2 px-6 rounded-lg hover:bg-yellow-400 transition-all shadow-lg shadow-brand-gold/20"
                    >
                        <IconExternalLink size={18} /> Visualizar Loja
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard 
                    title="Vendas (30 dias)" 
                    value={`R$ ${mockMarketplaceStats.salesMonth.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`} 
                    icon={IconChart} 
                    color="#10B981" 
                />
                <StatCard 
                    title="Pedidos Pendentes" 
                    value={mockMarketplaceStats.pendingOrders.toString()} 
                    icon={IconTruck} 
                    color="#F59E0B" 
                />
                <StatCard 
                    title="Produtos Ativos" 
                    value={mockMarketplaceStats.activeProducts.toString()} 
                    icon={IconBox} 
                    color="#3B82F6" 
                />
                <StatCard 
                    title="Ticket Médio" 
                    value={`R$ ${mockMarketplaceStats.ticketAverage.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`} 
                    icon={IconWallet} 
                    color="#FFD700" 
                />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
                    <Card>
                        <div className="flex justify-between items-center mb-6">
                            <h2 className="text-xl font-bold text-white flex items-center gap-2"><IconTruck/> Pedidos Recentes</h2>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full text-left">
                                <thead className="bg-brand-gray-light text-xs font-bold text-gray-400 uppercase">
                                    <tr>
                                        <th className="p-3">ID Pedido</th>
                                        <th className="p-3">Cliente</th>
                                        <th className="p-3 text-right">Total</th>
                                        <th className="p-3 text-center">Status</th>
                                    </tr>
                                </thead>
                                <tbody className="text-sm">
                                    {mockMarketplaceOrders.slice(0, 3).map(order => (
                                        <tr key={order.id} className="border-b border-brand-gray-light hover:bg-brand-gray-light/30">
                                            <td className="p-3 font-mono text-white">{order.id}</td>
                                            <td className="p-3 text-gray-300">{order.customer}</td>
                                            <td className="p-3 text-right text-brand-gold font-bold">R$ {order.total.toFixed(2)}</td>
                                            <td className="p-3 text-center">
                                                <span className="bg-green-500/20 text-green-400 px-2 py-1 rounded text-xs font-bold uppercase">{order.status}</span>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </Card>
                </div>
            </div>
        </div>
    );
};

export default MarketplaceDashboard;
