
import React, { useState, useEffect } from 'react';
import Card from '../../components/Card';
import { 
    IconPalette, IconLayout, IconImage, IconStar, IconCheckCircle, 
    IconLock, IconSave, IconEye, IconSparkles, IconEdit, IconTrash,
    IconExternalLink, IconLink, IconCopy
} from '../../components/icons';
import { mockStoreConfig } from '../data';
import type { StoreConfig } from '../../types';

const MarketplaceVisualLoja: React.FC = () => {
    const [config, setConfig] = useState<StoreConfig>(() => {
        const saved = localStorage.getItem('userStoreConfig');
        return saved ? JSON.parse(saved) : mockStoreConfig;
    });
    const [isSaving, setIsSaving] = useState(false);
    const [copied, setCopied] = useState(false);

    const handleSave = () => {
        setIsSaving(true);
        setTimeout(() => {
            setIsSaving(false);
            localStorage.setItem('userStoreConfig', JSON.stringify(config));
            alert("Estrutura da loja publicada com sucesso!");
        }, 1000);
    };

    const handleChange = (field: keyof StoreConfig, value: any) => {
        setConfig(prev => ({ ...prev, [field]: value }));
    };

    const handleOpenPreview = () => {
        localStorage.setItem('userStoreConfig', JSON.stringify(config));
        // CORREÇÃO DEFINITIVA: Usa o endereço completo antes do #
        const baseUrl = window.location.href.split('#')[0];
        const storeUrl = `${baseUrl}#/store/${config.slug}`;
        window.open(storeUrl, '_blank');
    };

    const copyStoreLink = () => {
        const baseUrl = window.location.href.split('#')[0];
        const fullLink = `${baseUrl}#/store/${config.slug}`;
        navigator.clipboard.writeText(fullLink);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="space-y-8 animate-fade-in pb-20">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                        <IconPalette className="text-brand-gold"/> Construtor de Vitrine React
                    </h1>
                    <p className="text-gray-400 text-sm">Monte sua loja profissional. Cada mudança aqui altera sua página de vendas real.</p>
                </div>
                <div className="flex gap-3">
                    <button onClick={handleOpenPreview} className="bg-brand-gray text-white px-4 py-2 rounded-lg font-bold border border-gray-600 flex items-center gap-2 hover:bg-gray-700 transition-colors">
                        <IconEye size={18}/> Visualizar Loja
                    </button>
                    <button onClick={handleSave} disabled={isSaving} className="bg-brand-gold text-brand-dark px-6 py-2 rounded-lg font-bold shadow-lg shadow-brand-gold/20 flex items-center gap-2 hover:bg-white transition-all">
                        {isSaving ? 'Publicando...' : <><IconSave size={18}/> Publicar Loja</>}
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Painel de Configuração */}
                <div className="lg:col-span-4 space-y-6">
                    <Card className="border-l-4 border-brand-gold bg-brand-gray-dark">
                        <h2 className="text-white font-bold mb-4 flex items-center gap-2">
                            <IconLink className="text-brand-gold" size={18}/> Endereço da sua Loja
                        </h2>
                        <div className="space-y-4">
                            <div>
                                <label className="text-[10px] font-bold text-gray-500 uppercase block mb-1">Slug de Acesso</label>
                                <div className="flex items-center bg-brand-dark border border-gray-700 rounded-lg overflow-hidden focus-within:border-brand-gold">
                                    <span className="bg-gray-800 px-3 py-2 text-xs text-gray-500">/store/</span>
                                    <input 
                                        type="text" 
                                        value={config.slug} 
                                        onChange={e => handleChange('slug', e.target.value.toLowerCase().replace(/\s+/g, '-'))}
                                        className="bg-transparent p-2 text-white text-sm outline-none flex-1 font-mono"
                                    />
                                </div>
                            </div>
                            <button onClick={copyStoreLink} className="w-full py-2 bg-brand-gray-light border border-gray-700 rounded-lg text-xs font-bold text-gray-300 flex items-center justify-center gap-2 hover:text-white transition-colors">
                                {copied ? "Copiado!" : "Copiar Link da Loja"}
                            </button>
                        </div>
                    </Card>

                    <Card>
                        <h2 className="text-lg font-bold text-white mb-6 border-b border-gray-700 pb-2">Identidade Visual</h2>
                        <div className="space-y-4">
                            <div>
                                <label className="text-xs font-bold text-gray-500 uppercase mb-2 block">Cor de Destaque (Neon/Gold)</label>
                                <div className="flex items-center gap-3">
                                    <input type="color" value={config.primaryColor} onChange={e => handleChange('primaryColor', e.target.value)} className="h-12 w-12 rounded cursor-pointer border-0 bg-transparent" />
                                    <input type="text" value={config.primaryColor} onChange={e => handleChange('primaryColor', e.target.value)} className="bg-brand-gray-light border border-gray-600 rounded-lg p-3 text-white flex-1 font-mono text-sm" />
                                </div>
                            </div>
                        </div>
                    </Card>

                    <Card>
                        <h2 className="text-lg font-bold text-white mb-6 border-b border-gray-700 pb-2">Conteúdo do Banner (Hero)</h2>
                        <div className="space-y-4">
                            <div>
                                <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Título de Impacto</label>
                                <input 
                                    type="text" 
                                    value={config.heroHeadline} 
                                    onChange={e => handleChange('heroHeadline', e.target.value)}
                                    className="w-full bg-brand-gray-light border border-gray-600 rounded-lg p-3 text-white focus:border-brand-gold outline-none"
                                />
                            </div>
                            <div>
                                <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Subtítulo</label>
                                <textarea 
                                    rows={3}
                                    value={config.heroSubheadline} 
                                    onChange={e => handleChange('heroSubheadline', e.target.value)}
                                    className="w-full bg-brand-gray-light border border-gray-600 rounded-lg p-3 text-white focus:border-brand-gold outline-none"
                                />
                            </div>
                        </div>
                    </Card>
                </div>

                {/* Visualização de Seções */}
                <div className="lg:col-span-8 space-y-6">
                    <Card>
                        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                            <IconLayout className="text-brand-gold"/> Organização da Vitrine
                        </h2>
                        
                        <div className="space-y-4">
                            {[
                                { id: 'hero', label: 'Cabeçalho de Boas-vindas (Hero)', status: 'Ativado' },
                                { id: 'featured', label: 'Grade: Produtos em Destaque', status: 'Ativado' },
                                { id: 'offers', label: 'Seção de Ofertas Relâmpago', status: 'Ativado' },
                                { id: 'footer', label: 'Rodapé Estruturado (Redes Sociais)', status: 'Ativado' },
                            ].map((section) => (
                                <div key={section.id} className="p-4 bg-brand-gray-light rounded-xl border border-gray-700 flex items-center justify-between group">
                                    <div className="flex items-center gap-4">
                                        <div className="p-2 bg-brand-dark rounded text-brand-gold"><IconEdit size={18}/></div>
                                        <div>
                                            <p className="text-white font-bold">{section.label}</p>
                                            <p className="text-[10px] text-gray-500 uppercase font-black tracking-widest">{section.status}</p>
                                        </div>
                                    </div>
                                    <label className="relative inline-flex items-center cursor-pointer ml-2">
                                        <input type="checkbox" className="sr-only peer" defaultChecked />
                                        <div className="w-11 h-6 bg-gray-600 peer-focus:ring-2 peer-focus:ring-brand-gold rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-gold"></div>
                                    </label>
                                </div>
                            ))}
                        </div>
                    </Card>

                    <Card className="bg-brand-gray border-dashed border-2 border-gray-700 flex flex-col items-center justify-center py-12 text-center">
                        <IconSparkles size={48} className="text-brand-gold/30 mb-4" />
                        <h3 className="text-white font-bold italic text-lg">Assistente RSIA para Design</h3>
                        <p className="text-gray-500 text-sm max-w-sm mt-2">Deseja que a Inteligência Artificial monte uma sugestão completa de cores e textos baseada no seu nicho?</p>
                        <button className="mt-6 bg-brand-gray-light hover:bg-brand-gray text-white border border-gray-600 px-8 py-2 rounded-full font-bold text-xs uppercase tracking-widest transition-all">
                            Gerar com IA
                        </button>
                    </Card>
                </div>
            </div>
        </div>
    );
};

export default MarketplaceVisualLoja;
