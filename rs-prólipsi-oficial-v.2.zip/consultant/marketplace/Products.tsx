
import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { MarketplaceProduct } from '../../types';
import { mockMarketplaceProducts } from '../data';
import { IconSearch, IconTrash, IconEdit, IconPlus } from '../../components/icons';

const MarketplaceProducts: React.FC = () => {
    const navigate = useNavigate();
    const [products, setProducts] = useState<MarketplaceProduct[]>(mockMarketplaceProducts);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
    
    const filteredProducts = useMemo(() => {
        return products.filter(p =>
            p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            (p.sku && p.sku.toLowerCase().includes(searchTerm.toLowerCase()))
        );
    }, [products, searchTerm]);

    const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.checked) {
            setSelectedProducts(filteredProducts.map(p => p.id));
        } else {
            setSelectedProducts([]);
        }
    };
    
    const handleSelectOne = (id: string) => {
        setSelectedProducts(prev => 
            prev.includes(id) ? prev.filter(pId => pId !== id) : [...prev, id]
        );
    };

    const handleDelete = (ids: string[]) => {
        if (confirm(`Deseja excluir ${ids.length} produto(s)?`)) {
            setProducts(prev => prev.filter(p => !ids.includes(p.id)));
            setSelectedProducts([]);
        }
    };

    const handleNavigate = (id?: string) => {
        if (id) navigate(`/marketplace/produtos/edit/${id}`);
        else navigate('/marketplace/produtos/new');
    };

    return (
        <div className="space-y-6 animate-fade-in">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-brand-gold">Gestão de Produtos</h1>
                    <p className="text-gray-400">Gerencie seu catálogo e visualize o estoque em tempo real.</p>
                </div>
            </div>

            <div className="bg-brand-gray border border-brand-gray-light rounded-lg overflow-hidden">
                <div className="p-4 border-b border-brand-gray-light flex flex-col md:flex-row justify-between gap-4">
                    <div className="relative flex-grow max-w-lg">
                        <input
                            type="text"
                            placeholder="Buscar produtos por nome ou SKU..."
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className="w-full bg-brand-dark border border-gray-700 rounded-md py-2.5 pl-10 pr-4 text-white focus:border-brand-gold focus:outline-none"
                        />
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <IconSearch className="h-5 w-5 text-gray-500" />
                        </div>
                    </div>
                    <button 
                        onClick={() => handleNavigate()} 
                        className="flex items-center justify-center gap-2 bg-brand-gold text-brand-dark font-bold py-2.5 px-6 rounded-md hover:bg-yellow-400 transition-colors whitespace-nowrap shadow-lg shadow-brand-gold/20"
                    >
                        <IconPlus size={18} /> Adicionar Produto
                    </button>
                </div>

                {selectedProducts.length > 0 && (
                    <div className="p-4 bg-red-500/10 border-b border-brand-gray-light flex justify-between items-center">
                        <span className="text-sm font-semibold text-red-400">{selectedProducts.length} selecionado(s)</span>
                        <button onClick={() => handleDelete(selectedProducts)} className="flex items-center gap-2 text-sm text-red-500 hover:text-red-400 font-bold bg-brand-dark px-3 py-1 rounded border border-red-500/30">
                            <IconTrash size={16}/> Excluir Seleção
                        </button>
                    </div>
                )}

                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="text-xs text-gray-400 uppercase bg-brand-dark border-b border-brand-gray-light">
                            <tr>
                                <th className="p-4 w-10">
                                    <input type="checkbox" onChange={handleSelectAll} checked={selectedProducts.length > 0 && selectedProducts.length === filteredProducts.length} className="accent-brand-gold" />
                                </th>
                                <th className="px-6 py-4">Produto</th>
                                <th className="px-6 py-4">Status</th>
                                <th className="px-6 py-4">Estoque</th>
                                <th className="px-6 py-4">Preço</th>
                                <th className="px-6 py-4 text-right">Ações</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-brand-gray-light">
                            {filteredProducts.map(product => (
                                <tr key={product.id} className="hover:bg-brand-gray-light/20 transition-colors">
                                    <td className="p-4">
                                        <input type="checkbox" checked={selectedProducts.includes(product.id)} onChange={() => handleSelectOne(product.id)} className="accent-brand-gold" />
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-3">
                                            <img src={product.image} alt="" className="w-10 h-10 object-cover rounded bg-white"/>
                                            <div>
                                                <button onClick={() => handleNavigate(product.id)} className="font-bold text-white hover:text-brand-gold transition-colors">{product.title}</button>
                                                <div className="text-[10px] text-gray-500 font-mono">{product.sku}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 text-[10px] font-bold rounded-full uppercase ${
                                            product.status === 'active' 
                                            ? 'bg-green-500/20 text-green-400' 
                                            : 'bg-gray-700 text-gray-400'
                                        }`}>
                                            {product.status === 'active' ? 'Ativo' : 'Rascunho'}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 font-mono text-gray-300">{product.stock}</td>
                                    <td className="px-6 py-4 font-bold text-white">R$ {(product.price || 0).toFixed(2)}</td>
                                    <td className="px-6 py-4 text-right">
                                        <div className="flex justify-end gap-2">
                                            <button onClick={() => handleNavigate(product.id)} className="p-2 text-gray-400 hover:text-brand-gold hover:bg-brand-gray-light rounded-full transition-all">
                                                <IconEdit size={18}/>
                                            </button>
                                            <button onClick={() => handleDelete([product.id])} className="p-2 text-gray-500 hover:text-red-500 hover:bg-brand-gray-light rounded-full transition-all">
                                                <IconTrash size={18}/>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default MarketplaceProducts;
