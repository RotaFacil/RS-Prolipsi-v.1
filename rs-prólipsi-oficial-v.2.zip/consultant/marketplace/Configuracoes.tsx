
import React, { useState } from 'react';
import Card from '../../components/Card';
import { IconStore, IconTruck, IconCreditCard, IconSave, IconShield } from '../../components/icons';

const MarketplaceConfiguracoes: React.FC = () => {
    const [storeName, setStoreName] = useState('Minha Loja Oficial');
    const [storeDescription, setStoreDescription] = useState('Os melhores produtos com a qualidade RS Prólipsi.');
    const [shippingMethod, setShippingMethod] = useState('correios');
    const [returnPolicy, setReturnPolicy] = useState('Aceitamos devoluções em até 7 dias após o recebimento.');

    return (
        <div className="space-y-8 animate-fade-in pb-20">
            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                <IconStore className="text-brand-gold"/> Configurações da Loja
            </h1>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Perfil da Loja */}
                <Card>
                    <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2"><IconStore/> Identidade Visual</h2>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-bold text-gray-400 mb-1">Nome da Loja</label>
                            <input 
                                type="text" 
                                value={storeName} 
                                onChange={e => setStoreName(e.target.value)}
                                className="w-full bg-brand-gray-light border border-gray-600 rounded-lg p-3 text-white focus:border-brand-gold focus:outline-none"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-gray-400 mb-1">Descrição (Sobre Nós)</label>
                            <textarea 
                                value={storeDescription}
                                onChange={e => setStoreDescription(e.target.value)}
                                rows={4}
                                className="w-full bg-brand-gray-light border border-gray-600 rounded-lg p-3 text-white focus:border-brand-gold focus:outline-none"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-gray-400 mb-1">Logo da Loja</label>
                            <div className="flex items-center gap-4">
                                <div className="h-20 w-20 bg-brand-gray-dark border-2 border-dashed border-gray-600 rounded-lg flex items-center justify-center text-gray-500">
                                    Logo
                                </div>
                                <button className="text-sm text-brand-gold font-bold hover:underline">Alterar Logo</button>
                            </div>
                        </div>
                    </div>
                </Card>

                {/* Frete e Logística */}
                <Card>
                    <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2"><IconTruck/> Frete e Envio</h2>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-bold text-gray-400 mb-2">Método de Cálculo Padrão</label>
                            <select 
                                value={shippingMethod}
                                onChange={e => setShippingMethod(e.target.value)}
                                className="w-full bg-brand-gray-light border border-gray-600 rounded-lg p-3 text-white focus:border-brand-gold focus:outline-none"
                            >
                                <option value="correios">Correios (Automático)</option>
                                <option value="fixed">Taxa Fixa</option>
                                <option value="free">Frete Grátis</option>
                            </select>
                        </div>
                        <div className="flex items-center gap-2 p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                            <IconShield className="text-blue-400" size={20}/>
                            <p className="text-xs text-blue-200">
                                Seus envios estão protegidos pelo programa <strong>RS Envios</strong>. As etiquetas são geradas automaticamente após a confirmação do pagamento.
                            </p>
                        </div>
                    </div>
                </Card>

                {/* Pagamento */}
                <Card>
                    <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2"><IconCreditCard/> Recebimento</h2>
                    <p className="text-sm text-gray-400 mb-4">
                        Os pagamentos são processados pela plataforma e creditados na sua <strong>RS Wallet</strong> automaticamente após o prazo de liberação.
                    </p>
                    <div className="p-4 bg-brand-gray-light rounded-lg border border-gray-600">
                        <div className="flex justify-between items-center mb-2">
                            <span className="text-white font-bold">Conta Padrão</span>
                            <span className="text-green-400 text-xs font-bold bg-green-500/20 px-2 py-1 rounded">ATIVO</span>
                        </div>
                        <p className="text-sm text-gray-300">Banco: Nubank</p>
                        <p className="text-sm text-gray-300">Ag: 0001 / CC: 12345-6</p>
                    </div>
                    <button className="mt-4 text-sm text-brand-gold font-bold hover:underline">Gerenciar Contas Bancárias</button>
                </Card>

                {/* Políticas */}
                <Card>
                    <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2"><IconShield/> Políticas da Loja</h2>
                    <div>
                        <label className="block text-sm font-bold text-gray-400 mb-1">Política de Devolução</label>
                        <textarea 
                            value={returnPolicy}
                            onChange={e => setReturnPolicy(e.target.value)}
                            rows={4}
                            className="w-full bg-brand-gray-light border border-gray-600 rounded-lg p-3 text-white focus:border-brand-gold focus:outline-none"
                        />
                    </div>
                </Card>
            </div>

            <div className="fixed bottom-8 right-8 z-40">
                <button className="flex items-center gap-2 bg-brand-gold text-brand-dark font-bold py-4 px-8 rounded-full shadow-2xl hover:bg-yellow-400 transition-transform transform hover:scale-105">
                    <IconSave size={20}/> Salvar Configurações
                </button>
            </div>
        </div>
    );
};

export default MarketplaceConfiguracoes;
