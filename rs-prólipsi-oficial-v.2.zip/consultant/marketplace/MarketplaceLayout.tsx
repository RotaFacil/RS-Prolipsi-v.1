
import React, { useState, useEffect } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import Topbar from '../components/Topbar';
import { useUser } from '../ConsultantLayout';
import { 
    IconDashboard, IconBox, IconTruck, IconSettings, IconStore, 
    IconChart, IconLogOut, IconChevronLeft, IconPalette, IconLink,
    IconWallet, IconFileText, IconExternalLink, IconEye
} from '../../components/icons';
import { mockStoreConfig } from '../data';

const marketplaceNavItems = [
  { name: 'Visão Geral', path: '/marketplace', icon: IconDashboard },
  { name: 'Meus Produtos', path: '/marketplace/produtos', icon: IconBox },
  { name: 'Pedidos de Venda', path: '/marketplace/pedidos', icon: IconTruck },
  { name: 'Financeiro', path: '/marketplace/financeiro', icon: IconWallet },
  { name: 'Relatórios', path: '/marketplace/relatorios', icon: IconChart },
  { name: 'Aparência da Loja', path: '/marketplace/loja-visual', icon: IconPalette },
  { name: 'Links de Divulgação', path: '/marketplace/marketing', icon: IconLink },
  { name: 'Configurações', path: '/marketplace/configuracoes', icon: IconSettings },
];

interface MarketplaceSidebarProps {
    isCollapsed: boolean;
    closeSidebar?: () => void;
}

const MarketplaceSidebar: React.FC<MarketplaceSidebarProps> = ({ isCollapsed, closeSidebar }) => {
    const navLinkClasses = (isActive: boolean) =>
        `flex items-center space-x-3 px-3 py-3 rounded-lg transition-all duration-200 ${isCollapsed ? 'justify-center' : ''} ${
        isActive
            ? 'bg-brand-gold text-brand-dark font-semibold shadow-lg shadow-brand-gold/20'
            : 'text-brand-text-dim hover:bg-brand-gray-light hover:text-white'
        }`;

    return (
        <aside className="w-full h-full bg-brand-gray border-r border-brand-gray-light flex-shrink-0 p-3 flex flex-col overflow-hidden">
            <div className={`py-4 text-center transition-all duration-300 ${isCollapsed ? 'mb-2' : 'mb-4'}`}>
                <h1 className={`text-brand-gold text-xl font-bold flex items-center justify-center gap-2 ${isCollapsed ? 'hidden' : 'block'}`}>
                    <IconStore className="text-brand-gold"/> Marketplace
                </h1>
                <h1 className={`text-brand-gold text-xl font-bold ${isCollapsed ? 'block' : 'hidden'}`}><IconStore/></h1>
            </div>
            
            <div className="flex-1 overflow-y-auto pr-1 custom-sidebar-scroll space-y-2">
                <div className="px-2 mb-4">
                    <NavLink to="/consultant/dashboard" className="flex items-center gap-2 text-[10px] uppercase font-black tracking-widest text-gray-500 hover:text-white transition-colors p-2 rounded bg-white/5">
                        <IconChevronLeft size={14}/>
                        {!isCollapsed && "Voltar ao Escritório"}
                    </NavLink>
                </div>

                <nav className="flex flex-col space-y-1">
                    {marketplaceNavItems.map(item => (
                        <NavLink
                            key={item.name}
                            to={item.path}
                            end={item.path === '/marketplace'}
                            onClick={() => closeSidebar?.()}
                            className={({ isActive }) => navLinkClasses(isActive)}
                        >
                            <item.icon className="h-5 w-5 flex-shrink-0" />
                            {!isCollapsed && <span className="text-sm">{item.name}</span>}
                        </NavLink>
                    ))}
                </nav>
            </div>
            
            <div className="mt-auto p-4 text-center text-[10px] text-gray-600 font-bold uppercase tracking-widest border-t border-brand-gray-light">
                {!isCollapsed && <span>RS Marketplace v2.0</span>}
            </div>

            <style>{`
                .custom-sidebar-scroll::-webkit-scrollbar { width: 4px; }
                .custom-sidebar-scroll::-webkit-scrollbar-track { background: transparent; }
                .custom-sidebar-scroll::-webkit-scrollbar-thumb { background: #333; border-radius: 10px; }
                .custom-sidebar-scroll::-webkit-scrollbar-thumb:hover { background: #FFD700; }
            `}</style>
        </aside>
    );
};

const MarketplaceLayout: React.FC = () => {
    const { user } = useUser();
    const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

    return (
        <div className="flex h-screen bg-brand-dark font-sans overflow-hidden">
            {/* Desktop Sidebar */}
            <div className={`hidden md:flex md:flex-shrink-0 transition-all duration-300 ${isSidebarCollapsed ? 'w-20' : 'w-64'}`}>
                <MarketplaceSidebar isCollapsed={isSidebarCollapsed} />
            </div>

            {/* Mobile Sidebar Overlay */}
            {isMobileMenuOpen && (
                <div className="fixed inset-0 bg-black/80 z-[100] md:hidden animate-fade-in" onClick={() => setIsMobileMenuOpen(false)}>
                    <div className="w-64 h-full animate-slide-right" onClick={e => e.stopPropagation()}>
                        <MarketplaceSidebar isCollapsed={false} closeSidebar={() => setIsMobileMenuOpen(false)} />
                    </div>
                </div>
            )}

            <div className="flex-1 flex flex-col overflow-hidden">
                <Topbar 
                    user={user} 
                    onMenuClick={() => setIsMobileMenuOpen(true)} 
                    onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)} 
                    isSidebarCollapsed={isSidebarCollapsed} 
                />
                <main className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 bg-[#0f1115]">
                    <div className="max-w-7xl mx-auto">
                        <Outlet />
                    </div>
                </main>
            </div>
            <style>{`
                @keyframes slide-right { from { transform: translateX(-100%); } to { transform: translateX(0); } }
                .animate-slide-right { animation: slide-right 0.3s ease-out forwards; }
            `}</style>
        </div>
    );
};

export default MarketplaceLayout;
