
import React, { useState, useMemo } from 'react';
import Card from '../../components/Card';
import Modal from '../../components/Modal';
import { 
    IconWallet, IconChart, IconReceipt, IconDownload, IconArrowUp, 
    IconArrowDown, IconFilter, IconSearch, IconCheckCircle, IconFileText 
} from '../../components/icons';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Tipos locais para o financeiro
type TransactionType = 'sale' | 'fee' | 'payout' | 'refund';

interface MarketplaceTransaction {
    id: string;
    date: string;
    type: TransactionType;
    description: string;
    amount: number;
    status: 'completed' | 'pending' | 'processing';
    orderId?: string;
}

// Mock de dados financeiros
const mockTransactions: MarketplaceTransaction[] = [
    { id: 'TX-1001', date: '2023-10-26', type: 'sale', description: 'Venda - Pedido #ORD-001', amount: 1250.00, status: 'completed', orderId: 'ORD-001' },
    { id: 'TX-1002', date: '2023-10-26', type: 'fee', description: 'Taxa de Plataforma (10%)', amount: 125.00, status: 'completed', orderId: 'ORD-001' },
    { id: 'TX-1003', date: '2023-10-25', type: 'sale', description: 'Venda - Pedido #ORD-002', amount: 349.00, status: 'completed', orderId: 'ORD-002' },
    { id: 'TX-1004', date: '2023-10-25', type: 'fee', description: 'Taxa de Plataforma (10%)', amount: 34.90, status: 'completed', orderId: 'ORD-002' },
    { id: 'TX-1005', date: '2023-10-24', type: 'payout', description: 'Saque para Wallet Principal', amount: 2000.00, status: 'completed' },
    { id: 'TX-1006', date: '2023-10-24', type: 'sale', description: 'Venda - Pedido #ORD-003', amount: 2100.00, status: 'completed', orderId: 'ORD-003' },
    { id: 'TX-1007', date: '2023-10-24', type: 'fee', description: 'Taxa de Plataforma (10%)', amount: 210.00, status: 'completed', orderId: 'ORD-003' },
    { id: 'TX-1008', date: '2023-10-23', type: 'sale', description: 'Venda - Pedido #ORD-004', amount: 99.00, status: 'pending', orderId: 'ORD-004' }, // Pendente não conta no saldo disponível
    { id: 'TX-1009', date: '2023-10-22', type: 'refund', description: 'Estorno - Pedido #ORD-000', amount: 150.00, status: 'completed', orderId: 'ORD-000' },
];

const formatCurrency = (value: number) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const MarketplaceFinanceiro: React.FC = () => {
    const [transactions, setTransactions] = useState<MarketplaceTransaction[]>(mockTransactions);
    const [searchTerm, setSearchTerm] = useState('');
    const [typeFilter, setTypeFilter] = useState<'all' | TransactionType>('all');
    
    // Estado do Modal de Saque
    const [isWithdrawModalOpen, setWithdrawModalOpen] = useState(false);
    const [withdrawAmount, setWithdrawAmount] = useState('');
    const [withdrawStatus, setWithdrawStatus] = useState<'idle' | 'processing' | 'success'>('idle');

    // Cálculos Financeiros
    const financials = useMemo(() => {
        let grossSales = 0;
        let totalFees = 0;
        let totalRefunds = 0;
        let totalPayouts = 0;
        let pendingBalance = 0;

        transactions.forEach(t => {
            if (t.status === 'completed') {
                if (t.type === 'sale') grossSales += t.amount;
                if (t.type === 'fee') totalFees += t.amount;
                if (t.type === 'refund') totalRefunds += t.amount;
                if (t.type === 'payout') totalPayouts += t.amount;
            } else if (t.status === 'pending' && t.type === 'sale') {
                pendingBalance += t.amount; // Vendas ainda não liberadas
            }
        });

        // Lucro Líquido Operacional (Vendas - Taxas - Estornos)
        const netProfit = grossSales - totalFees - totalRefunds;
        
        // Saldo Disponível para Saque (Lucro Líquido - O que já foi sacado)
        const availableBalance = netProfit - totalPayouts;

        return { grossSales, totalFees, totalRefunds, netProfit, availableBalance, pendingBalance };
    }, [transactions]);

    // Dados para o Gráfico
    const chartData = useMemo(() => {
        const data: Record<string, { name: string, Vendas: number, Taxas: number }> = {};
        
        // Ordenar transações por data (antigas primeiro para o gráfico)
        const sorted = [...transactions].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

        sorted.forEach(t => {
            if (t.status !== 'completed') return;
            // Formatar data DD/MM
            const dateObj = new Date(t.date);
            const dateKey = `${dateObj.getDate().toString().padStart(2, '0')}/${(dateObj.getMonth() + 1).toString().padStart(2, '0')}`;

            if (!data[dateKey]) data[dateKey] = { name: dateKey, Vendas: 0, Taxas: 0 };

            if (t.type === 'sale') data[dateKey].Vendas += t.amount;
            if (t.type === 'fee') data[dateKey].Taxas += t.amount;
        });

        return Object.values(data);
    }, [transactions]);

    // Filtros da Tabela
    const filteredTransactions = transactions.filter(t => {
        const matchesSearch = t.description.toLowerCase().includes(searchTerm.toLowerCase()) || 
                              t.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                              (t.orderId && t.orderId.toLowerCase().includes(searchTerm.toLowerCase()));
        const matchesType = typeFilter === 'all' || t.type === typeFilter;
        return matchesSearch && matchesType;
    });

    const handleWithdraw = (e: React.FormEvent) => {
        e.preventDefault();
        const amount = parseFloat(withdrawAmount.replace('.', '').replace(',', '.'));
        
        if (isNaN(amount) || amount <= 0) {
            alert("Valor inválido.");
            return;
        }
        if (amount > financials.availableBalance) {
            alert("Saldo insuficiente.");
            return;
        }

        setWithdrawStatus('processing');
        
        // Simulação de processamento
        setTimeout(() => {
            const newTransaction: MarketplaceTransaction = {
                id: `TX-${Date.now()}`,
                date: new Date().toISOString().split('T')[0],
                type: 'payout',
                description: 'Saque para Wallet Principal',
                amount: amount,
                status: 'completed'
            };
            
            setTransactions([newTransaction, ...transactions]);
            setWithdrawStatus('success');
            setWithdrawAmount('');
            
            setTimeout(() => {
                setWithdrawStatus('idle');
                setWithdrawModalOpen(false);
            }, 2000);
        }, 1500);
    };

    return (
        <div className="space-y-6 animate-fade-in pb-20">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-brand-gold flex items-center gap-2"><IconWallet/> Financeiro Marketplace</h1>
                    <p className="text-gray-400 text-sm">Acompanhe seus lucros, taxas e realize saques.</p>
                </div>
                <div className="flex gap-3">
                    <button 
                        onClick={() => setWithdrawModalOpen(true)}
                        className="bg-brand-gold text-brand-dark font-bold py-2 px-6 rounded-lg hover:bg-yellow-400 transition-colors shadow-lg shadow-brand-gold/20 flex items-center gap-2"
                    >
                        <IconArrowUp className="rotate-45" size={20} /> Solicitar Saque
                    </button>
                </div>
            </div>

            {/* Cards de Resumo */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="flex items-center space-x-4 border-l-4 border-green-500">
                    <div className="p-3 bg-green-500/20 rounded-full text-green-400">
                        <IconChart size={24} />
                    </div>
                    <div>
                        <p className="text-gray-400 text-xs uppercase font-bold">Vendas Brutas</p>
                        <p className="text-xl font-bold text-white">{formatCurrency(financials.grossSales)}</p>
                    </div>
                </Card>
                <Card className="flex items-center space-x-4 border-l-4 border-red-500">
                    <div className="p-3 bg-red-500/20 rounded-full text-red-400">
                        <IconReceipt size={24} />
                    </div>
                    <div>
                        <p className="text-gray-400 text-xs uppercase font-bold">Taxas e Estornos</p>
                        <p className="text-xl font-bold text-white">{formatCurrency(financials.totalFees + financials.totalRefunds)}</p>
                    </div>
                </Card>
                <Card className="flex items-center space-x-4 border-l-4 border-brand-gold">
                    <div className="p-3 bg-brand-gold/20 rounded-full text-brand-gold">
                        <IconWallet size={24} />
                    </div>
                    <div>
                        <p className="text-gray-400 text-xs uppercase font-bold">Disponível para Saque</p>
                        <p className="text-xl font-bold text-white">{formatCurrency(financials.availableBalance)}</p>
                    </div>
                </Card>
                <Card className="flex items-center space-x-4 border-l-4 border-yellow-500">
                    <div className="p-3 bg-yellow-500/20 rounded-full text-yellow-400">
                        <IconFileText size={24} />
                    </div>
                    <div>
                        <p className="text-gray-400 text-xs uppercase font-bold">Saldo Pendente</p>
                        <p className="text-xl font-bold text-white">{formatCurrency(financials.pendingBalance)}</p>
                    </div>
                </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Gráfico de Fluxo */}
                <div className="lg:col-span-2">
                    <Card className="h-full min-h-[400px]">
                        <h3 className="text-lg font-bold text-white mb-6">Fluxo de Caixa (Vendas vs Taxas)</h3>
                        <div className="h-80 w-full">
                            <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                                    <defs>
                                        <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#10B981" stopOpacity={0.3}/>
                                            <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                                        </linearGradient>
                                        <linearGradient id="colorFees" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#EF4444" stopOpacity={0.3}/>
                                            <stop offset="95%" stopColor="#EF4444" stopOpacity={0}/>
                                        </linearGradient>
                                    </defs>
                                    <XAxis dataKey="name" stroke="#6B7280" fontSize={12} />
                                    <YAxis stroke="#6B7280" fontSize={12} tickFormatter={(val) => `R$${val}`} />
                                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" vertical={false} />
                                    <Tooltip 
                                        contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151', borderRadius: '8px' }}
                                        itemStyle={{ color: '#fff' }}
                                        formatter={(value: number) => formatCurrency(value)}
                                    />
                                    <Area type="monotone" dataKey="Vendas" stroke="#10B981" fillOpacity={1} fill="url(#colorSales)" strokeWidth={2} />
                                    <Area type="monotone" dataKey="Taxas" stroke="#EF4444" fillOpacity={1} fill="url(#colorFees)" strokeWidth={2} />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>
                    </Card>
                </div>

                {/* Resumo Rápido */}
                <div className="lg:col-span-1 space-y-6">
                    <Card className="bg-brand-gray-light border border-gray-700">
                        <h3 className="font-bold text-white mb-4">Resumo Financeiro Geral</h3>
                        <div className="space-y-4 text-sm">
                            <div className="flex justify-between border-b border-gray-600 pb-2">
                                <span className="text-gray-400">Total Vendas (Histórico)</span>
                                <span className="text-white font-bold">{formatCurrency(financials.grossSales + financials.pendingBalance)}</span>
                            </div>
                            <div className="flex justify-between border-b border-gray-600 pb-2">
                                <span className="text-gray-400">Total Taxas Pagas</span>
                                <span className="text-red-400 font-bold">- {formatCurrency(financials.totalFees)}</span>
                            </div>
                            <div className="flex justify-between border-b border-gray-600 pb-2">
                                <span className="text-gray-400">Total Saques Realizados</span>
                                {/* Fix: Property netAmount changed to netProfit to match memoized financials state */}
                                <span className="text-yellow-400 font-bold">- {formatCurrency(financials.netProfit - financials.availableBalance || 0)}</span>
                            </div>
                            <div className="pt-2">
                                <p className="text-center text-xs text-gray-500">
                                    As taxas são descontadas automaticamente a cada venda aprovada. O saldo fica disponível após o período de segurança (D+X).
                                </p>
                            </div>
                        </div>
                    </Card>
                </div>
            </div>

            {/* Tabela de Extrato */}
            <Card>
                <div className="flex flex-col lg:flex-row justify-between items-end lg:items-center gap-4 mb-6">
                    <h2 className="text-xl font-bold text-white">Extrato de Transações</h2>
                    <div className="flex flex-wrap gap-2 w-full lg:w-auto">
                        <div className="relative flex-grow lg:flex-grow-0">
                            <IconSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
                            <input 
                                type="text" 
                                placeholder="Buscar transação..." 
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                                className="w-full lg:w-64 bg-brand-gray-light border border-gray-600 rounded-lg py-2 pl-9 pr-4 text-sm text-white focus:border-brand-gold focus:outline-none"
                            />
                        </div>
                        <div className="relative">
                            <IconFilter className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
                            <select 
                                value={typeFilter}
                                onChange={e => setTypeFilter(e.target.value as any)}
                                className="bg-brand-gray-light border border-gray-600 rounded-lg py-2 pl-9 pr-8 text-sm text-white focus:border-brand-gold focus:outline-none appearance-none cursor-pointer"
                            >
                                <option value="all">Todos os Tipos</option>
                                <option value="sale">Vendas</option>
                                <option value="fee">Taxas</option>
                                <option value="payout">Saques</option>
                                <option value="refund">Estornos</option>
                            </select>
                        </div>
                        <button className="flex items-center gap-2 text-sm bg-brand-gray-light px-4 py-2 rounded-lg hover:bg-brand-gray hover:text-white transition-colors border border-gray-600">
                            <IconDownload size={16}/> Exportar
                        </button>
                    </div>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                        <thead className="bg-brand-gray-light text-xs font-bold text-gray-400 uppercase">
                            <tr>
                                <th className="p-4 rounded-l-lg">ID</th>
                                <th className="p-4">Data</th>
                                <th className="p-4">Tipo</th>
                                <th className="p-4">Descrição</th>
                                <th className="p-4 text-right">Valor</th>
                                <th className="p-4 rounded-r-lg text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody className="text-sm divide-y divide-gray-800">
                            {filteredTransactions.map(t => (
                                <tr key={t.id} className="hover:bg-brand-gray-light/30 transition-colors">
                                    <td className="p-4 font-mono text-gray-400">{t.id}</td>
                                    <td className="p-4 text-white">{new Date(t.date).toLocaleDateString('pt-BR')}</td>
                                    <td className="p-4">
                                        {t.type === 'sale' && <span className="text-green-400 flex items-center gap-1"><IconArrowUp size={14} className="rotate-45"/> Venda</span>}
                                        {t.type === 'fee' && <span className="text-red-400 flex items-center gap-1"><IconArrowDown size={14} className="rotate-45"/> Taxa</span>}
                                        {t.type === 'payout' && <span className="text-yellow-400 flex items-center gap-1"><IconWallet size={14}/> Saque</span>}
                                        {t.type === 'refund' && <span className="text-red-500 flex items-center gap-1"><IconArrowDown size={14}/> Estorno</span>}
                                    </td>
                                    <td className="p-4 text-gray-300">
                                        {t.description}
                                        {t.orderId && <span className="block text-xs text-gray-500">Ref: {t.orderId}</span>}
                                    </td>
                                    <td className={`p-4 text-right font-bold ${['sale'].includes(t.type) ? 'text-green-400' : 'text-red-400'}`}>
                                        {['sale'].includes(t.type) ? '+' : '-'} {formatCurrency(t.amount)}
                                    </td>
                                    <td className="p-4 text-center">
                                        <span className={`px-2 py-1 rounded text-xs font-bold uppercase ${
                                            t.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                                            t.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                                            'bg-blue-500/20 text-blue-400'
                                        }`}>
                                            {t.status === 'completed' ? 'Concluído' : t.status === 'pending' ? 'Pendente' : 'Processando'}
                                        </span>
                                    </td>
                                </tr>
                            ))}
                            {filteredTransactions.length === 0 && (
                                <tr>
                                    <td colSpan={6} className="p-8 text-center text-gray-500">
                                        Nenhuma transação encontrada.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>

            {/* Modal de Saque */}
            <Modal isOpen={isWithdrawModalOpen} onClose={() => setWithdrawModalOpen(false)} title="Solicitar Saque do Marketplace">
                <form onSubmit={handleWithdraw} className="space-y-6">
                    <div className="bg-brand-gray-light p-4 rounded-lg border border-gray-700">
                        <p className="text-sm text-gray-400 mb-1">Saldo Disponível para Saque</p>
                        <p className="text-3xl font-bold text-brand-gold">{formatCurrency(financials.availableBalance)}</p>
                    </div>

                    <div>
                        <label className="text-sm font-bold text-white block mb-2">Valor do Saque (R$)</label>
                        <input 
                            type="text" 
                            value={withdrawAmount}
                            onChange={(e) => setWithdrawAmount(e.target.value)}
                            placeholder="0,00"
                            className="w-full bg-brand-gray border border-gray-600 rounded-lg p-3 text-white focus:border-brand-gold focus:outline-none text-lg"
                        />
                        <p className="text-xs text-gray-500 mt-2">O valor será transferido para sua Wallet RS Principal.</p>
                    </div>

                    <div className="bg-blue-500/10 border border-blue-500/30 p-4 rounded-lg flex gap-3">
                        <IconCheckCircle className="text-blue-400 flex-shrink-0" size={20} />
                        <p className="text-sm text-blue-200">
                            Saques solicitados até as 14h são processados no mesmo dia útil.
                        </p>
                    </div>

                    <button 
                        type="submit" 
                        disabled={withdrawStatus !== 'idle'}
                        className={`w-full font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition-all ${
                            withdrawStatus === 'success' 
                            ? 'bg-green-500 text-white' 
                            : 'bg-brand-gold text-brand-dark hover:bg-yellow-400'
                        }`}
                    >
                        {withdrawStatus === 'idle' && 'Confirmar Solicitação'}
                        {withdrawStatus === 'processing' && <span className="animate-pulse">Processando...</span>}
                        {withdrawStatus === 'success' && <><IconCheckCircle size={20}/> Solicitação Enviada!</>}
                    </button>
                </form>
            </Modal>
        </div>
    );
};

export default MarketplaceFinanceiro;
