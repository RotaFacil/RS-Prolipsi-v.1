
import React, { useState, useMemo } from 'react';
import Card from '../../components/Card';
import Modal from '../../components/Modal';
import { 
    IconTruck, IconSearch, IconFilter, IconCheckCircle, IconFileText, IconPrinter, 
    IconCalendar, IconChevronDown, IconUser, IconMapPin, IconBox, IconCreditCard,
    IconMail, IconPhone
} from '../../components/icons';
import { mockMarketplaceOrders } from '../data';
import type { MarketplaceOrder } from '../../types';

// Helper to format currency
const formatCurrency = (value: number) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

// Status Configuration
const statusConfig: Record<string, { label: string, color: string, bg: string }> = {
    pending: { label: 'Pendente', color: 'text-yellow-400', bg: 'bg-yellow-500/20' },
    approved: { label: 'Aprovado', color: 'text-blue-400', bg: 'bg-blue-500/20' },
    shipped: { label: 'Enviado', color: 'text-indigo-400', bg: 'bg-indigo-500/20' },
    delivered: { label: 'Entregue', color: 'text-green-400', bg: 'bg-green-500/20' },
    cancelled: { label: 'Cancelado', color: 'text-red-400', bg: 'bg-red-500/20' },
};

const MarketplaceOrders: React.FC = () => {
    const [orders, setOrders] = useState<MarketplaceOrder[]>(mockMarketplaceOrders);
    
    // Filters State
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('all');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    
    // UI State
    const [selectedOrder, setSelectedOrder] = useState<MarketplaceOrder | null>(null);
    const [statusDropdownOpen, setStatusDropdownOpen] = useState<string | null>(null); // ID of the order with open dropdown

    // --- Actions ---
    const handleStatusChange = (orderId: string, newStatus: MarketplaceOrder['status']) => {
        setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
        setStatusDropdownOpen(null);
        if (selectedOrder && selectedOrder.id === orderId) {
            setSelectedOrder(prev => prev ? { ...prev, status: newStatus } : null);
        }
    };

    const handlePrint = () => {
        const printContent = document.getElementById('printable-order-content');
        if (printContent) {
            const printWindow = window.open('', '', 'width=800,height=600');
            if (printWindow) {
                printWindow.document.write('<html><head><title>Imprimir Pedido</title>');
                printWindow.document.write('<style>body{font-family:sans-serif; padding: 20px;} table{width:100%;border-collapse:collapse;} th,td{border:1px solid #ddd;padding:8px;text-align:left;} .no-print{display:none;}</style>');
                printWindow.document.write('</head><body>');
                printWindow.document.write(printContent.innerHTML);
                printWindow.document.write('</body></html>');
                printWindow.document.close();
                printWindow.print();
            }
        }
    };

    // --- Filter Logic ---
    const filteredOrders = useMemo(() => {
        return orders.filter(order => {
            const matchesSearch = 
                order.id.toLowerCase().includes(searchTerm.toLowerCase()) || 
                order.customer.toLowerCase().includes(searchTerm.toLowerCase());
            
            const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
            
            let matchesDate = true;
            if (startDate || endDate) {
                const [day, month, year] = order.date.split('/').map(Number);
                const orderDate = new Date(year, month - 1, day);
                
                if (startDate) {
                    const start = new Date(startDate);
                    if (orderDate < start) matchesDate = false;
                }
                if (endDate) {
                    const end = new Date(endDate);
                    if (orderDate > end) matchesDate = false;
                }
            }

            return matchesSearch && matchesStatus && matchesDate;
        });
    }, [orders, searchTerm, statusFilter, startDate, endDate]);

    return (
        <div className="space-y-6 animate-fade-in pb-20">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-brand-gold flex items-center gap-2"><IconTruck/> Pedidos de Venda</h1>
                    <p className="text-gray-400 text-sm">Gerencie, filtre e processe seus pedidos com eficiência.</p>
                </div>
            </div>

            <Card>
                {/* Filters Toolbar */}
                <div className="flex flex-col lg:flex-row gap-4 mb-6 items-end">
                    <div className="flex-grow w-full">
                        <label className="text-xs text-gray-500 font-bold mb-1 block uppercase">Buscar Pedido</label>
                        <div className="relative">
                            <IconSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                            <input 
                                type="text" 
                                placeholder="ID do pedido, nome do cliente..." 
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                                className="w-full bg-brand-gray-light border border-gray-600 rounded-lg py-2.5 pl-10 pr-4 text-white focus:border-brand-gold focus:outline-none"
                            />
                        </div>
                    </div>
                    
                    <div className="w-full lg:w-48">
                        <label className="text-xs text-gray-500 font-bold mb-1 block uppercase">Status</label>
                        <div className="relative">
                            <IconFilter className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                            <select 
                                value={statusFilter}
                                onChange={e => setStatusFilter(e.target.value)}
                                className="w-full bg-brand-gray-light border border-gray-600 rounded-lg py-2.5 pl-10 pr-4 text-white focus:border-brand-gold focus:outline-none appearance-none cursor-pointer"
                            >
                                <option value="all">Todos os Status</option>
                                <option value="pending">Pendente</option>
                                <option value="approved">Aprovado</option>
                                <option value="shipped">Enviado</option>
                                <option value="delivered">Entregue</option>
                                <option value="cancelled">Cancelado</option>
                            </select>
                        </div>
                    </div>

                    <div className="w-full lg:w-auto flex gap-2">
                        <div>
                            <label className="text-xs text-gray-500 font-bold mb-1 block uppercase">De</label>
                            <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="bg-brand-gray-light border border-gray-600 rounded-lg py-2 px-3 text-white focus:border-brand-gold focus:outline-none text-sm"/>
                        </div>
                        <div>
                            <label className="text-xs text-gray-500 font-bold mb-1 block uppercase">Até</label>
                            <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="bg-brand-gray-light border border-gray-600 rounded-lg py-2 px-3 text-white focus:border-brand-gold focus:outline-none text-sm"/>
                        </div>
                    </div>
                </div>

                {/* Orders Table */}
                <div className="overflow-x-auto min-h-[400px]">
                    <table className="w-full text-left border-collapse">
                        <thead className="bg-brand-gray-light text-xs font-bold text-gray-400 uppercase tracking-wider">
                            <tr>
                                <th className="p-4 rounded-tl-lg">Pedido</th>
                                <th className="p-4">Data</th>
                                <th className="p-4">Cliente</th>
                                <th className="p-4 text-center">Itens</th>
                                <th className="p-4 text-right">Total</th>
                                <th className="p-4 text-center">Status (Alterar)</th>
                                <th className="p-4 text-right rounded-tr-lg">Ações</th>
                            </tr>
                        </thead>
                        <tbody className="text-sm divide-y divide-gray-800">
                            {filteredOrders.length > 0 ? filteredOrders.map(order => {
                                const status = statusConfig[order.status] || statusConfig.pending;
                                return (
                                    <tr key={order.id} className="hover:bg-brand-gray-light/30 transition-colors group">
                                        <td className="p-4 font-mono font-bold text-white cursor-pointer hover:text-brand-gold" onClick={() => setSelectedOrder(order)}>
                                            {order.id}
                                        </td>
                                        <td className="p-4 text-gray-400">{order.date}</td>
                                        <td className="p-4">
                                            <div className="font-semibold text-white">{order.customer}</div>
                                            <div className="text-xs text-gray-500">{order.customerInfo?.email}</div>
                                        </td>
                                        <td className="p-4 text-center text-gray-300">{order.itemsCount}</td>
                                        <td className="p-4 text-right font-bold text-brand-gold">R$ {(order.total || 0).toFixed(2)}</td>
                                        
                                        {/* Status Changer */}
                                        <td className="p-4 text-center relative">
                                            <button 
                                                onClick={(e) => { e.stopPropagation(); setStatusDropdownOpen(statusDropdownOpen === order.id ? null : order.id); }}
                                                className={`px-3 py-1 rounded-full text-xs font-bold uppercase inline-flex items-center gap-1 cursor-pointer hover:opacity-80 transition-opacity ${status.bg} ${status.color}`}
                                            >
                                                {status.label} <IconChevronDown size={12}/>
                                            </button>
                                            
                                            {/* Dropdown Menu */}
                                            {statusDropdownOpen === order.id && (
                                                <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 w-40 bg-brand-gray-dark border border-gray-700 rounded-lg shadow-xl z-20 overflow-hidden">
                                                    {Object.entries(statusConfig).map(([key, config]) => (
                                                        <button 
                                                            key={key}
                                                            onClick={() => handleStatusChange(order.id, key as any)}
                                                            className={`w-full text-left px-4 py-2 text-xs font-bold hover:bg-gray-700 uppercase ${config.color}`}
                                                        >
                                                            {config.label}
                                                        </button>
                                                    ))}
                                                </div>
                                            )}
                                        </td>

                                        <td className="p-4 text-right">
                                            <button 
                                                onClick={() => setSelectedOrder(order)} 
                                                className="p-2 text-gray-400 hover:text-white hover:bg-brand-gray-light rounded transition-colors" 
                                                title="Ver Detalhes Completo"
                                            >
                                                <IconFileText size={20} />
                                            </button>
                                        </td>
                                    </tr>
                                );
                            }) : (
                                <tr>
                                    <td colSpan={7} className="text-center py-12 text-gray-500">
                                        Nenhum pedido encontrado com os filtros atuais.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>

            {/* Modal de Detalhes do Pedido */}
            <Modal 
                isOpen={!!selectedOrder} 
                onClose={() => { setSelectedOrder(null); setStatusDropdownOpen(null); }} 
                title={`Detalhes do Pedido #${selectedOrder?.id}`}
                className="max-w-4xl"
            >
                {selectedOrder && (
                    <div className="space-y-6" id="printable-order-content">
                        {/* Header Actions (No Print) */}
                        <div className="flex flex-wrap justify-between items-center gap-4 border-b border-gray-700 pb-4 no-print">
                            <div className="flex items-center gap-2">
                                <span className="text-sm text-gray-400 uppercase font-bold">Status Atual:</span>
                                <div className="relative">
                                    <button 
                                        onClick={() => setStatusDropdownOpen(statusDropdownOpen === selectedOrder.id ? null : selectedOrder.id)}
                                        className={`px-3 py-1 rounded-full text-sm font-bold uppercase inline-flex items-center gap-2 ${statusConfig[selectedOrder.status].bg} ${statusConfig[selectedOrder.status].color}`}
                                    >
                                        {statusConfig[selectedOrder.status].label} <IconChevronDown size={14}/>
                                    </button>
                                    {statusDropdownOpen === selectedOrder.id && (
                                        <div className="absolute top-full left-0 mt-1 w-40 bg-brand-gray-dark border border-gray-700 rounded-lg shadow-xl z-30 overflow-hidden">
                                            {Object.entries(statusConfig).map(([key, config]) => (
                                                <button 
                                                    key={key}
                                                    onClick={() => handleStatusChange(selectedOrder.id, key as any)}
                                                    className={`w-full text-left px-4 py-3 text-xs font-bold hover:bg-gray-700 uppercase ${config.color}`}
                                                >
                                                    {config.label}
                                                </button>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            </div>
                            <button 
                                onClick={handlePrint}
                                className="flex items-center gap-2 bg-brand-gray text-white px-4 py-2 rounded-lg hover:bg-brand-gray-light border border-gray-600 transition-colors font-bold text-sm"
                            >
                                <IconPrinter size={18} /> Imprimir Pedido
                            </button>
                        </div>

                        {/* Customer & Shipping Info */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="bg-brand-gray-light p-4 rounded-lg border border-gray-700">
                                <h3 className="text-brand-gold font-bold mb-3 flex items-center gap-2"><IconUser size={18}/> Dados do Cliente</h3>
                                <div className="space-y-2 text-sm text-gray-300">
                                    <p><strong className="text-white">Nome:</strong> {selectedOrder.customer}</p>
                                    <p><strong className="text-white">CPF:</strong> {selectedOrder.customerInfo?.cpf || 'Não informado'}</p>
                                    <p className="flex items-center gap-2"><IconMail size={14} className="text-gray-500"/> {selectedOrder.customerInfo?.email}</p>
                                    <p className="flex items-center gap-2"><IconPhone size={14} className="text-gray-500"/> {selectedOrder.customerInfo?.phone}</p>
                                </div>
                            </div>

                            <div className="bg-brand-gray-light p-4 rounded-lg border border-gray-700">
                                <h3 className="text-brand-gold font-bold mb-3 flex items-center gap-2"><IconMapPin size={18}/> Endereço de Entrega</h3>
                                <div className="space-y-1 text-sm text-gray-300">
                                    {selectedOrder.shippingAddress ? (
                                        <>
                                            <p>{selectedOrder.shippingAddress.street}, {selectedOrder.shippingAddress.number}</p>
                                            <p>{selectedOrder.shippingAddress.neighborhood}</p>
                                            <p>{selectedOrder.shippingAddress.city} - {selectedOrder.shippingAddress.state}</p>
                                            <p className="font-mono text-brand-gold mt-2">{selectedOrder.shippingAddress.zipCode}</p>
                                        </>
                                    ) : (
                                        <p className="text-gray-500 italic">Endereço não disponível</p>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Items List */}
                        <div>
                            <h3 className="text-brand-gold font-bold mb-3 flex items-center gap-2"><IconBox size={18}/> Itens do Pedido</h3>
                            <div className="bg-brand-gray-light rounded-lg border border-gray-700 overflow-hidden">
                                <table className="w-full text-left">
                                    <thead className="bg-brand-gray border-b border-gray-700 text-xs font-bold text-gray-400 uppercase">
                                        <tr>
                                            <th className="p-3">Produto</th>
                                            <th className="p-3 text-center">Qtd</th>
                                            <th className="p-3 text-right">Unitário</th>
                                            <th className="p-3 text-right">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-700 text-sm">
                                        {selectedOrder.items && selectedOrder.items.length > 0 ? selectedOrder.items.map((item, idx) => (
                                            <tr key={idx}>
                                                <td className="p-3">
                                                    <div className="flex items-center gap-3">
                                                        <img src={item.image} alt="" className="w-10 h-10 rounded object-cover bg-gray-800"/>
                                                        <span className="font-medium text-white">{item.name}</span>
                                                    </div>
                                                </td>
                                                <td className="p-3 text-center text-white">{item.quantity}</td>
                                                <td className="p-3 text-right text-gray-300">{formatCurrency(item.price)}</td>
                                                <td className="p-3 text-right font-bold text-white">{formatCurrency(item.price * item.quantity)}</td>
                                            </tr>
                                        )) : (
                                            <tr><td colSpan={4} className="p-4 text-center text-gray-500">Detalhes dos itens indisponíveis.</td></tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        {/* Financial Summary */}
                        <div className="flex justify-end">
                            <div className="w-full md:w-1/3 bg-brand-gray-light p-4 rounded-lg border border-gray-700">
                                <h3 className="text-brand-gold font-bold mb-3 flex items-center gap-2"><IconCreditCard size={18}/> Resumo Financeiro</h3>
                                <div className="space-y-2 text-sm">
                                    <div className="flex justify-between text-gray-300">
                                        <span>Subtotal:</span>
                                        <span>{formatCurrency(selectedOrder.total)}</span>
                                    </div>
                                    <div className="flex justify-between text-gray-300">
                                        <span>Frete:</span>
                                        <span>R$ 0,00</span>
                                    </div>
                                    <div className="flex justify-between border-t border-gray-600 pt-2 mt-2 text-lg font-bold text-white">
                                        <span>Total:</span>
                                        <span className="text-green-400">{formatCurrency(selectedOrder.total)}</span>
                                    </div>
                                    <div className="pt-2 text-right">
                                        <span className="text-xs text-gray-500 uppercase font-bold mr-2">Método:</span>
                                        <span className="text-xs bg-gray-700 px-2 py-1 rounded text-white">{selectedOrder.paymentMethod}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </Modal>
        </div>
    );
};

export default MarketplaceOrders;
