
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Card from '../../components/Card';
import { 
    IconArrowLeft, IconSave, IconImage, IconUpload, IconBold, IconItalic, 
    IconLink, IconList, IconTrash, IconCheckCircle, IconEye, IconSparkles,
    IconUnderline, IconType, IconPalette, IconAlignLeft, IconAlignCenter, IconAlignRight,
    IconListOrdered, IconX
} from '../../components/icons';
import { mockMarketplaceProducts } from '../data';
import type { MarketplaceProduct } from '../../types';
import { GoogleGenAI } from "@google/genai";

const RichTextToolbar: React.FC<{ onCommand: (cmd: string, arg?: string) => void }> = ({ onCommand }) => {
    const [inputMode, setInputMode] = useState<'link' | 'image' | null>(null);
    const [urlValue, setUrlValue] = useState('');
    const savedSelection = useRef<Range | null>(null);

    // FUNÇÃO CRUCIAL: Impede que o botão roube o foco do editor de texto
    const preventFocusLoss = (e: React.MouseEvent) => {
        e.preventDefault();
    };

    const startInputMode = (mode: 'link' | 'image') => {
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
            savedSelection.current = selection.getRangeAt(0);
        }
        setInputMode(mode);
        setUrlValue('');
    };

    const applyInput = () => {
        const selection = window.getSelection();
        if (selection && savedSelection.current) {
            selection.removeAllRanges();
            selection.addRange(savedSelection.current);
        }

        if (urlValue.trim()) {
            if (inputMode === 'link') {
                onCommand('createLink', urlValue);
            } else {
                onCommand('insertImage', urlValue);
            }
        }
        cancelInput();
    };

    const cancelInput = () => {
        setInputMode(null);
        setUrlValue('');
        savedSelection.current = null;
    };

    if (inputMode) {
        return (
            <div className="flex items-center gap-2 p-2 bg-brand-gray-light rounded-t-lg border-b border-brand-gray-light w-full animate-fade-in">
                <input 
                    type="text" 
                    autoFocus
                    placeholder={inputMode === 'link' ? "Digite a URL do link..." : "Cole a URL da imagem..."}
                    value={urlValue}
                    onChange={(e) => setUrlValue(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && applyInput()}
                    className="flex-grow bg-brand-dark text-white text-sm px-3 py-1.5 rounded border border-gray-600 focus:border-brand-gold focus:outline-none"
                />
                <button onClick={applyInput} className="p-1.5 bg-green-500/20 text-green-400 rounded hover:bg-green-500/30">
                    <IconCheckCircle size={18} />
                </button>
                <button onClick={cancelInput} className="p-1.5 bg-red-500/20 text-red-400 rounded hover:bg-red-500/30">
                    <IconX size={18} />
                </button>
            </div>
        );
    }

    return (
        <div className="flex flex-wrap items-center gap-1 border-b border-brand-gray-light p-2 bg-brand-gray-light/30 rounded-t-lg sticky top-0 z-10 backdrop-blur-sm">
            {/* Títulos e Parágrafos */}
            <div className="flex items-center gap-1 border-r border-gray-600 pr-2 mr-1">
                <button type="button" onMouseDown={preventFocusLoss} onClick={() => onCommand('formatBlock', 'H2')} className="p-1.5 hover:bg-brand-gray-light rounded text-gray-300 hover:text-white" title="H2"><IconType size={18}/></button>
                <button type="button" onMouseDown={preventFocusLoss} onClick={() => onCommand('formatBlock', 'H3')} className="p-1.5 hover:bg-brand-gray-light rounded text-gray-300 hover:text-white" title="H3"><IconType size={14}/></button>
                <button type="button" onMouseDown={preventFocusLoss} onClick={() => onCommand('formatBlock', 'P')} className="p-1.5 hover:bg-brand-gray-light rounded text-gray-300 hover:text-white" title="Parágrafo"><span className="text-xs font-bold">P</span></button>
            </div>

            {/* Estilos de Texto */}
            <div className="flex items-center gap-1 border-r border-gray-600 pr-2 mr-1">
                <button type="button" onMouseDown={preventFocusLoss} onClick={() => onCommand('bold')} className="p-1.5 hover:bg-brand-gray-light rounded text-gray-300 hover:text-white" title="Negrito"><IconBold size={16}/></button>
                <button type="button" onMouseDown={preventFocusLoss} onClick={() => onCommand('italic')} className="p-1.5 hover:bg-brand-gray-light rounded text-gray-300 hover:text-white" title="Itálico"><IconItalic size={16}/></button>
                <button type="button" onMouseDown={preventFocusLoss} onClick={() => onCommand('underline')} className="p-1.5 hover:bg-brand-gray-light rounded text-gray-300 hover:text-white" title="Sublinhado"><IconUnderline size={16}/></button>
                <label className="p-1.5 hover:bg-brand-gray-light rounded text-gray-300 hover:text-white cursor-pointer relative" title="Cor" onMouseDown={preventFocusLoss}>
                    <IconPalette size={16}/>
                    <input type="color" className="absolute inset-0 opacity-0 cursor-pointer w-full h-full" onChange={(e) => onCommand('foreColor', e.target.value)} />
                </label>
            </div>

            {/* Alinhamento */}
            <div className="flex items-center gap-1 border-r border-gray-600 pr-2 mr-1">
                <button type="button" onMouseDown={preventFocusLoss} onClick={() => onCommand('justifyLeft')} className="p-1.5 hover:bg-brand-gray-light rounded text-gray-300 hover:text-white"><IconAlignLeft size={16}/></button>
                <button type="button" onMouseDown={preventFocusLoss} onClick={() => onCommand('justifyCenter')} className="p-1.5 hover:bg-brand-gray-light rounded text-gray-300 hover:text-white"><IconAlignCenter size={16}/></button>
                <button type="button" onMouseDown={preventFocusLoss} onClick={() => onCommand('justifyRight')} className="p-1.5 hover:bg-brand-gray-light rounded text-gray-300 hover:text-white"><IconAlignRight size={16}/></button>
            </div>

            {/* Listas e Inserções */}
            <div className="flex items-center gap-1">
                <button type="button" onMouseDown={preventFocusLoss} onClick={() => onCommand('insertUnorderedList')} className="p-1.5 hover:bg-brand-gray-light rounded text-gray-300 hover:text-white"><IconList size={16}/></button>
                <button type="button" onMouseDown={preventFocusLoss} onClick={() => onCommand('insertOrderedList')} className="p-1.5 hover:bg-brand-gray-light rounded text-gray-300 hover:text-white"><IconListOrdered size={16}/></button>
                <button type="button" onMouseDown={preventFocusLoss} onClick={() => startInputMode('link')} className="p-1.5 hover:bg-brand-gray-light rounded text-gray-300 hover:text-white"><IconLink size={16}/></button>
                <button type="button" onMouseDown={preventFocusLoss} onClick={() => startInputMode('image')} className="p-1.5 hover:bg-brand-gray-light rounded text-gray-300 hover:text-white"><IconImage size={16}/></button>
            </div>
        </div>
    );
};

const ProductEditor: React.FC = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const isNew = !id;

    const [formData, setFormData] = useState<Partial<MarketplaceProduct> & { 
        description?: string, 
        seoTitle?: string, 
        seoDescription?: string, 
        images?: string[],
        comparePrice?: number,
        vendor?: string,
        tags?: string
    }>({
        title: '',
        price: 0,
        comparePrice: 0,
        stock: 0,
        sku: '',
        category: 'Geral',
        status: 'active',
        description: '',
        seoTitle: '',
        seoDescription: '',
        images: [],
        vendor: 'RS Prólipsi',
        tags: ''
    });

    const [isSaving, setIsSaving] = useState(false);
    const [isGeneratingDesc, setIsGeneratingDesc] = useState(false);
    const contentEditableRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (!isNew && id) {
            const product = mockMarketplaceProducts.find(p => p.id === id);
            if (product) {
                setFormData({
                    ...product,
                    description: product.description || '<p>Descreva o produto...</p>',
                    images: [product.image],
                    comparePrice: product.price * 1.2,
                    vendor: 'RS Prólipsi',
                    tags: 'oferta, destaque'
                });
                if (contentEditableRef.current) {
                    contentEditableRef.current.innerHTML = product.description || '';
                }
            }
        }
    }, [id, isNew]);

    const handleChange = (field: string, value: any) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleRichTextCommand = (command: string, arg?: string) => {
        document.execCommand(command, false, arg);
    };

    const handleSave = () => {
        setIsSaving(true);
        setTimeout(() => {
            setIsSaving(false);
            alert('Salvo com sucesso!');
            navigate('/marketplace/produtos');
        }, 1000);
    };

    const handleAiDescription = async () => {
        if (!formData.title) return alert("Preencha o título.");
        setIsGeneratingDesc(true);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const prompt = `Como um Copywriter Especialista, escreva uma descrição de alta conversão para o produto "${formData.title}". Use HTML limpo (h2, p, ul, li, strong). Não inclua markdown blocks.`;
            const response = await ai.models.generateContent({ model: "gemini-2.5-flash", contents: prompt });
            const text = response.text || "";
            const cleanHtml = text.replace(/```html/g, '').replace(/```/g, '').trim();
            handleChange('description', cleanHtml);
            if (contentEditableRef.current) contentEditableRef.current.innerHTML = cleanHtml;
        } catch (e) {
            alert("Erro ao gerar copy.");
        } finally {
            setIsGeneratingDesc(false);
        }
    };

    return (
        <div className="space-y-6 pb-20 animate-fade-in max-w-6xl mx-auto">
            <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                    <button onClick={() => navigate('/marketplace/produtos')} className="p-2 hover:bg-brand-gray-light rounded-lg text-gray-400 hover:text-white">
                        <IconArrowLeft size={24} />
                    </button>
                    <h1 className="text-2xl font-bold text-white">{isNew ? 'Novo Produto' : 'Editar Produto'}</h1>
                </div>
                <button onClick={handleSave} disabled={isSaving} className="bg-brand-gold text-brand-dark font-bold py-2 px-6 rounded-lg hover:bg-yellow-400 flex items-center gap-2">
                    {isSaving ? <span className="animate-spin rounded-full h-4 w-4 border-2 border-brand-dark border-t-transparent"></span> : <IconSave size={18} />}
                    Salvar
                </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
                    <Card>
                        <div className="space-y-4">
                            <div>
                                <label className="text-sm font-bold text-white block mb-2">Título do Produto</label>
                                <input 
                                    type="text" 
                                    value={formData.title}
                                    onChange={e => handleChange('title', e.target.value)}
                                    className="w-full bg-brand-gray-light border border-gray-600 rounded-lg p-3 text-white focus:border-brand-gold focus:outline-none"
                                />
                            </div>
                            
                            <div>
                                <div className="flex justify-between items-center mb-2">
                                    <label className="text-sm font-bold text-white">Descrição Detalhada</label>
                                    <button onClick={handleAiDescription} disabled={isGeneratingDesc} className="text-xs flex items-center gap-1 bg-purple-600/20 text-purple-400 px-3 py-1 rounded-full hover:bg-purple-600/40 transition-colors">
                                        <IconSparkles size={12}/> {isGeneratingDesc ? 'Criando...' : 'Gerar com IA'}
                                    </button>
                                </div>
                                <div className="border border-gray-600 rounded-lg overflow-hidden bg-brand-gray-light focus-within:border-brand-gold">
                                    <RichTextToolbar onCommand={handleRichTextCommand} />
                                    <div 
                                        ref={contentEditableRef}
                                        contentEditable
                                        className="p-4 min-h-[400px] text-white focus:outline-none prose prose-invert max-w-none"
                                        onBlur={(e) => handleChange('description', e.currentTarget.innerHTML)}
                                    />
                                </div>
                            </div>
                        </div>
                    </Card>
                </div>

                <div className="space-y-6">
                    <Card>
                        <h2 className="text-sm font-bold text-gray-500 uppercase mb-4">Preço e Estoque</h2>
                        <div className="space-y-4">
                            <div>
                                <label className="text-xs font-bold text-gray-400 mb-1 block">Preço de Venda (R$)</label>
                                <input type="number" step="0.01" value={formData.price} onChange={e => handleChange('price', parseFloat(e.target.value))} className="w-full bg-brand-gray-light border border-gray-600 rounded-lg p-2 text-white font-bold text-lg"/>
                            </div>
                            <div>
                                <label className="text-xs font-bold text-gray-400 mb-1 block">Quantidade em Estoque</label>
                                <input type="number" value={formData.stock} onChange={e => handleChange('stock', parseInt(e.target.value))} className="w-full bg-brand-gray-light border border-gray-600 rounded-lg p-2 text-white"/>
                            </div>
                        </div>
                    </Card>
                </div>
            </div>
        </div>
    );
};

export default ProductEditor;
