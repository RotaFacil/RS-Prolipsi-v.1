
// types.ts

// ... (existing interfaces remain the same)

export interface Address {
  zipCode: string;
  street: string;
  number: string;
  complement?: string;
  neighborhood: string;
  city: string;
  state: string;
}

export interface BankAccount {
  bank: string;
  agency: string;
  accountNumber: string;
  accountType: 'checking' | 'savings';
  pixKey: string;
}

export interface User {
  id: string; // Numeric ID (e.g., 9772169)
  username?: string; // The "Indicador" code (e.g., emclaro)
  name: string;
  email: string;
  avatarUrl: string;
  whatsapp: string;
  status: 'active' | 'inactive' | 'pending';
  role?: 'user' | 'admin' | 'super_admin'; 
  pin: string;
  cpfCnpj: string;
  birthDate: string;
  registrationDate: string;
  hasPurchased: boolean;
  address: Address;
  bankAccount: BankAccount;
  idConsultor?: string; // Legacy ID field if needed
  graduacao?: string;
  categoria?: string;
  linkIndicacao?: string;
  linkAfiliado?: string;
  personalVolume?: number;
  groupVolume?: number;
  totalVolume?: number;
  bonusCicloGlobal?: number;
  bonusTopSigme?: number;
  bonusPlanoCarreira?: number;
  totalCycles?: number;
  upline?: {
    id: string;
    username: string; // The sponsor's username code
    name: string;
    avatarUrl: string;
    idConsultor: string;
    whatsapp: string;
  };
}

export interface SystemMessage {
  id: string;
  title: string;
  content: string;
  date: string;
  read: boolean;
  type: 'alert' | 'announcement' | 'promotion';
}

export type WalletTransactionType = 
  | 'commission_cycle'
  | 'commission_shop'
  | 'bonus_career'
  | 'bonus_compensation'
  | 'withdrawal'
  | 'deposit'
  | 'transfer_in'
  | 'transfer_out'
  | 'bonus_sigme'
  | 'bonus_fidelity';

export interface WalletTransaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: WalletTransactionType;
  status: 'completed' | 'pending' | 'failed';
  details?: {
    bonusType: string;
    sourceUser: {
      id: string;
      name: string;
      avatarUrl?: string;
    };
    networkLevel: number;
    dynamicCompressionLevel?: number;
  };
}

export interface ShopOrder {
    id: string;
    date: string;
    product: string;
    status: 'shipped' | 'completed' | 'pending';
    commission: number;
}

export interface UserOrder {
  id: string;
  date: string;
  status: 'pending_payment' | 'paid' | 'shipped' | 'completed';
  total: number;
  items: {
    productId: string;
    name: string;
    imageUrl: string;
    quantity: number;
    unitPrice: number;
  }[];
  shipping: {
    type: 'delivery' | 'pickup';
    cost: number;
    address: string;
    trackingCode?: string;
  };
}


export interface CycleInfo {
    level: number;
    completed: boolean;
    participants: User[];
    personalConsumption: number;
    cycleTotal: number;
    divisionBase: number;
    amountReceived: number;
}

export interface NetworkNode extends User {
    level: number;
    children: NetworkNode[];
    isEmpty?: boolean;
}

export interface Invoice {
    id: string;
    customerName: string;
    dueDate: string;
    amount: number;
    status: 'pending' | 'paid' | 'overdue';
}

export interface Subscription {
    id: string;
    planName: string;
    customerName: string;
    nextBillingDate: string;
    amount: number;
    status: 'active' | 'paused' | 'cancelled';
}

export interface AnticipationRequest {
    id: string;
    requestDate: string;
    requestedAmount: number;
    feeAmount: number;
    netAmount: number;
    status: 'approved' | 'pending' | 'denied';
}

export interface Lesson {
    id: string;
    title: string;
    videoId: string;
    completed: boolean;
}

export interface Module {
    id: string;
    title: string;
    lessons: Lesson[];
}

export interface Course {
    id: string;
    title: string;
    description: string;
    iconName: string;
    modules: Module[];
}

export interface CDInfo {
  id?: string;
  name: string;
  email: string;
  phone: string;
  address: Address;
  isFederalSede?: boolean;
  payment: {
    pixKey: {
      type: 'email' | 'cpf' | 'cnpj' | 'phone' | 'random';
      key: string;
    };
    apiKeys: {
      mercadoPago: string;
      pagSeguro: string;
      cielo: string;
      getnet: string;
      stone: string;
      pagoFacil: string;
      redLink: string;
      emax: string;
    }
  };
  shipping: {
    allowLocalPickup: boolean;
    apiKeys: {
      melhorEnvio: string;
      loggi: string;
      superFrete: string;
      correios: string;
      frenet: string;
    }
  }
}

export interface CDProduct {
    id: string;
    name: string;
    imageUrl: string;
    fullPrice: number;
    discount: number;
    // Optional fields for Marketplace/Dropshipping context
    category?: string;
    price?: number;
    commission?: number;
    details?: {
        mainVideoId: string;
        description: string;
        keyMetrics: { icon: string; value: string; label: string }[];
        videoGallery: { id: string; title: string; thumbnailUrl: string }[];
    };
}

export interface CDConsultantOrder {
  id: string;
  date: string;
  consultant: {
    name: string;
    email: string;
    phone: string;
    avatarUrl: string;
  };
  items: {
    productId: string;
    name: string;
    quantity: number;
    unitPrice: number;
  }[];
  subtotal: number;
  shipping: {
    type: 'delivery' | 'pickup';
    cost: number;
    address?: {
      street: string;
      city: string;
      zipCode: string;
    };
  };
  total: number;
  status: 'pending_payment' | 'paid' | 'shipped' | 'completed';
}

export interface CDInventoryItem {
    productId: string;
    name: string;
    quantity: number;
    unitCost: number;
}

// --- MARKETPLACE TYPES ---
export interface MarketplaceProduct {
    id: string;
    title: string;
    sku: string;
    price: number;
    stock: number;
    status: 'active' | 'inactive' | 'draft';
    image: string;
    category: string;
    lastUpdated: string;
    description?: string;
}

export interface MarketplaceOrder {
    id: string;
    customer: string;
    date: string;
    total: number;
    status: 'pending' | 'approved' | 'shipped' | 'delivered' | 'cancelled';
    itemsCount: number;
    paymentMethod: string;
    // Enhanced Fields
    customerInfo: {
        cpf: string;
        email: string;
        phone: string;
    };
    shippingAddress: {
        street: string;
        number: string;
        neighborhood: string;
        city: string;
        state: string;
        zipCode: string;
    };
    items: {
        id: string;
        name: string;
        quantity: number;
        price: number;
        image: string;
    }[];
}

export interface MarketplaceStats {
    salesMonth: number;
    pendingOrders: number;
    activeProducts: number;
    ticketAverage: number;
    commissionGenerated: number;
    salesHistory: { date: string; value: number }[];
}

export type AspectRatio = '1:1' | '16:9' | '9:16' | '4:3' | '3:4';
export type MediaSubTool = 'Image' | 'Video';

export interface AppState {
  prompt: string;
  negativePrompt: string;
  aspectRatio: AspectRatio;
  baseImage: string | null;
  baseImageMimeType: string | null;
  maskImage: string | null;
  maskImageMimeType: string | null;
  blendImage: string | null;
  blendImageMimeType: string | null;
  mediaSubTool: MediaSubTool;
}

export interface MediaResult {
  type: 'image' | 'video';
  url: string;
  text: string;
  base64: string;
  mimeType: string;
}

export interface Creation {
  id: string;
  prompt: string;
  mediaResult: MediaResult;
  createdAt: string;
  appState: AppState;
}

export type SocialPlatform = 'Instagram' | 'Facebook' | 'X' | 'TikTok' | 'LinkedIn';

export type WorkflowNodeType = 
    | 'start' | 'newUser' | 'schedule' | 'webhook' | 'newSale' | 'pinAchieved' | 'birthday'
    | 'whatsappMessage' | 'instagramPost' | 'facebookPost' | 'tiktokPost' | 'youtubeVideo'
    | 'sendEmail' | 'googleSheetAddRow' | 'discordMessage' | 'linkedInPost'
    | 'delay' | 'condition' | 'loop' | 'aiAction' | 'aiContent' | 'aiDecision';

export interface WorkflowNodeParameter {
    name: string;
    label: string;
    type: 'text' | 'textarea' | 'readonly' | 'select';
    value: string;
    description?: string;
    options?: { value: string; label: string }[];
}

export interface WorkflowNodeOutput {
    name: string; 
    label: string; 
    description?: string;
}

export interface WorkflowNode {
    id: string;
    type: WorkflowNodeType;
    label: string;
    position: { x: number; y: number };
    parameters: WorkflowNodeParameter[];
    outputs?: WorkflowNodeOutput[];
}

export interface WorkflowEdge {
    id: string;
    source: string;
    target: string;
    sourceHandle?: string; 
}
export interface Workflow {
    id: string;
    name: string;
    description: string;
    nodes: WorkflowNode[];
    edges: WorkflowEdge[];
    isActive?: boolean;
}

export interface ImageAdjustments {
    brightness: number;
    contrast: number;
    saturate: number;
    sepia: number;
    grayscale: number;
    invert: number;
    hueRotate: number;
    blur: number;
}

export interface ImageTransform {
    scale: number;
    translateX: number;
    translateY: number;
    rotate: number;
    flipX: boolean;
    flipY: boolean;
}

export interface EditHistory {
    adjustments: ImageAdjustments;
    transform: ImageTransform;
}

export interface Incentive {
  id: string;
  name: string;
  progress: number;
  target: number;
}

// --- GLOBAL ADMIN TYPES ---

export interface CareerPinRule {
    pin: string;
    cycles: number;
    minLines: number;
    vmec: string; // "60/40" or "100%"
    bonus: number;
    iconColor: string;
}

export interface GlobalSystemSettings {
    careerPlan: {
        active: boolean;
        pins: CareerPinRule[];
        cycleValue: number;
        bonusPercentage: number;
        netValuePerCycle: number;
        period: string;
    };
    matrixSigma: {
        cycleValue: number;
        payoutValue: number;
        payoutPercent: number;
        reentry: string;
        reentryLimit: number;
        spillover: string;
        careerPoints: number;
    };
    depthBonus: {
        baseCalculation: number;
        levels: { level: number; percent: number; value: number }[];
    };
    topSigma: {
        baseCalculation: number;
        ranking: { position: number; percent: number }[];
    };
    fidelityBonus: {
        sourcePercent: number;
        baseValue: number;
        levels: { level: number; percent: number; value: number }[];
    };
    financial: {
        withdrawalFee: number;
        minWithdrawal: number;
        currency: 'BRL' | 'USD';
    };
    shop: {
        globalDiscount: number;
    };
}

// --- E-COMMERCE BUILDER TYPES ---
export interface StoreConfig {
    storeName: string;
    slug: string;
    template: 'amazon-pro' | 'minimalist' | 'boutique';
    primaryColor: string;
    secondaryColor: string;
    bannerUrl: string;
    logoUrl: string;
    heroHeadline: string;
    heroSubheadline: string;
    products: string[]; // List of Product IDs to display
    isActive: boolean;
}

export interface Pixel {
    id: string;
    name: string;
    platform: 'facebook' | 'google' | 'pinterest' | 'tiktok' | 'taboola' | 'snapchat' | 'twitter' | 'linkedin';
    status: 'active' | 'inactive';
    pixelId: string;
    accessToken?: string;
    conversionLabel?: string;
}

export interface ShortenedLink {
    id: string;
    short: string;
    original: string;
    clicks: number;
}

export interface AffiliateSeller {
    id: string;
    name: string;
    category: string;
    commissionRate: number;
    logoUrl: string;
}

// --- DASHBOARD CONFIG TYPES ---
export interface ProgressBarConfig {
  id: string; 
  title: string;
  startIcon: string;
  endIcon: string;
  isEndIconFilled?: boolean;
  calculationMode: 'manual' | 'auto';
  targetPin: string | null; 
}

export interface UserInfoField {
  id: string;
  label: string;
  source: string;
}

export interface DashboardLink {
  id: string;
  label: string;
  source: string;
}

export interface PromoBannerConfig {
  id: string;
  preTitle: string;
  title: string;
  price: number;
  imageUrl: string;
  imageDataUrl?: string;
  ctaText: string;
}

export interface DashboardBonusCard {
  id: string;
  source: string;
}

export interface DashboardConfig {
  userInfo: UserInfoField[];
  links: DashboardLink[];
  promoBanners: PromoBannerConfig[];
  bonusCards: DashboardBonusCard[];
  progressBars: Record<string, ProgressBarConfig>;
  pinLogos: { [key: string]: string };
  networkSummary: {
    source: 'top-sigme' | 'global-cycle';
  };
  incentives: Incentive[];
}
