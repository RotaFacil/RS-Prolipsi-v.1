
import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { GlobalSystemSettings, CareerPinRule } from '../types';

// Fallback defaults caso o banco esteja vazio na primeira execução
const defaultSettings: GlobalSystemSettings = {
    careerPlan: {
        active: true,
        cycleValue: 360,
        bonusPercentage: 6.39,
        netValuePerCycle: 23.00,
        period: 'Trimestral',
        pins: [
            { pin: 'Bronze', cycles: 5, minLines: 0, vmec: '—', bonus: 13.50, iconColor: '#cd7f32' },
            { pin: 'Prata', cycles: 15, minLines: 1, vmec: '100', bonus: 40.50, iconColor: '#c0c0c0' },
            { pin: 'Ouro', cycles: 70, minLines: 1, vmec: '100', bonus: 189.00, iconColor: '#ffd700' },
            { pin: 'Safira', cycles: 150, minLines: 2, vmec: '60/40', bonus: 405.00, iconColor: '#0f52ba' },
            { pin: 'Esmeralda', cycles: 300, minLines: 2, vmec: '60/40', bonus: 810.00, iconColor: '#50c878' },
            { pin: 'Topázio', cycles: 500, minLines: 2, vmec: '60/40', bonus: 1350.00, iconColor: '#ffc87c' },
            { pin: 'Rubi', cycles: 750, minLines: 3, vmec: '50/30/20', bonus: 2025.00, iconColor: '#e0115f' },
            { pin: 'Diamante', cycles: 1500, minLines: 3, vmec: '50/30/20', bonus: 4050.00, iconColor: '#b9f2ff' },
            { pin: 'Duplo Diamante', cycles: 3000, minLines: 4, vmec: '40/30/20/10', bonus: 18450.00, iconColor: '#82EEFF' },
            { pin: 'Triplo Diamante', cycles: 5000, minLines: 5, vmec: '35/25/20/10/10', bonus: 36450.00, iconColor: '#00BFFF' },
            { pin: 'Diamante Red', cycles: 15000, minLines: 6, vmec: '30/20/18/12/10/10/1', bonus: 67500.00, iconColor: '#ff4500' },
            { pin: 'Diamante Blue', cycles: 25000, minLines: 6, vmec: '30/20/18/12/10/10/1', bonus: 105300.00, iconColor: '#4169e1' },
            { pin: 'Diamante Black', cycles: 50000, minLines: 6, vmec: '30/20/18/12/10/10/1', bonus: 135000.00, iconColor: '#1a1a1a' },
        ]
    },
    matrixSigma: {
        cycleValue: 360,
        payoutValue: 108.00,
        payoutPercent: 30.00,
        reentry: 'Ativada',
        reentryLimit: 10,
        spillover: 'Linha Ascendente',
        careerPoints: 1
    },
    depthBonus: {
        baseCalculation: 6.81,
        levels: [
            { level: 1, percent: 7, value: 1.72 },
            { level: 2, percent: 8, value: 1.96 },
            { level: 3, percent: 10, value: 2.45 },
            { level: 4, percent: 15, value: 3.68 },
            { level: 5, percent: 25, value: 6.13 },
            { level: 6, percent: 35, value: 8.58 }
        ]
    },
    topSigma: {
        baseCalculation: 4.5,
        ranking: [
            { position: 1, percent: 22.22 },
            { position: 2, percent: 16.67 },
            { position: 3, percent: 13.33 },
            { position: 4, percent: 11.11 },
            { position: 5, percent: 8.89 },
            { position: 6, percent: 7.78 },
            { position: 7, percent: 6.67 },
            { position: 8, percent: 5.56 },
            { position: 9, percent: 4.44 },
            { position: 10, percent: 3.33 }
        ]
    },
    fidelityBonus: {
        sourcePercent: 1.25,
        baseValue: 360,
        levels: [
            { level: 1, percent: 7, value: 0.315 },
            { level: 2, percent: 8, value: 0.360 },
            { level: 3, percent: 10, value: 0.450 },
            { level: 4, percent: 15, value: 0.675 },
            { level: 5, percent: 25, value: 1.125 },
            { level: 6, percent: 35, value: 1.575 }
        ]
    },
    financial: {
        withdrawalFee: 5.00,
        minWithdrawal: 50.00,
        currency: 'BRL',
    },
    shop: {
        globalDiscount: 0,
    }
};

// Mapa de cores fixo para os PINs (pois não está no banco)
const PIN_COLORS: {[key: string]: string} = {
    'Bronze': '#cd7f32',
    'Prata': '#c0c0c0',
    'Ouro': '#ffd700',
    'Safira': '#0f52ba',
    'Esmeralda': '#50c878',
    'Topázio': '#ffc87c',
    'Rubi': '#e0115f',
    'Diamante': '#b9f2ff',
    'Duplo Diamante': '#82EEFF',
    'Triplo Diamante': '#00BFFF',
    'Diamante Red': '#ff4500',
    'Diamante Blue': '#4169e1',
    'Diamante Black': '#1a1a1a',
};

interface SystemSettingsContextType {
    settings: GlobalSystemSettings;
    updateSettings: (newSettings: Partial<GlobalSystemSettings>) => Promise<void>;
    isLoading: boolean;
}

const SystemSettingsContext = createContext<SystemSettingsContextType | null>(null);

export const useSystemSettings = () => {
    const context = useContext(SystemSettingsContext);
    if (!context) {
        throw new Error('useSystemSettings must be used within a SystemSettingsProvider');
    }
    return context;
};

export const SystemSettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [settings, setSettings] = useState<GlobalSystemSettings>(defaultSettings);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchAllSettings = async () => {
            try {
                setIsLoading(true);
                
                // 1. Fetch Sigma Core Settings
                const { data: sigmaSettings, error: sigmaError } = await supabase
                    .from('sigma_settings')
                    .select('*')
                    .limit(1)
                    .single();

                // 2. Fetch Pins
                const { data: pinsData } = await supabase
                    .from('sigma_career_pins')
                    .select('*')
                    .order('order_index', { ascending: true });

                // 3. Fetch Depth Levels
                const { data: depthData } = await supabase
                    .from('sigma_depth_levels')
                    .select('*')
                    .order('level', { ascending: true });

                // 4. Fetch Fidelity Levels
                const { data: fidelityData } = await supabase
                    .from('sigma_fidelity_levels')
                    .select('*')
                    .order('level', { ascending: true });

                // 5. Fetch Top Sigma
                const { data: topSigmaData } = await supabase
                    .from('sigma_top10_levels')
                    .select('*')
                    .order('rank', { ascending: true });

                // Construct new settings object
                const newSettings: GlobalSystemSettings = { ...defaultSettings };

                if (sigmaSettings) {
                    newSettings.matrixSigma = {
                        cycleValue: Number(sigmaSettings.cycle_value),
                        payoutValue: Number(sigmaSettings.cycle_payout_value),
                        payoutPercent: Number(sigmaSettings.cycle_payout_percent),
                        reentry: sigmaSettings.reentry_enabled ? 'Ativada' : 'Desativada',
                        reentryLimit: sigmaSettings.reentry_limit_per_month,
                        spillover: sigmaSettings.spillover_mode,
                        careerPoints: 1 // Default
                    };
                    
                    newSettings.careerPlan = {
                        ...newSettings.careerPlan,
                        cycleValue: Number(sigmaSettings.cycle_value),
                        bonusPercentage: Number(sigmaSettings.career_percent),
                    };

                    newSettings.fidelityBonus = {
                        ...newSettings.fidelityBonus,
                        sourcePercent: Number(sigmaSettings.fidelity_source_percent),
                    };

                    newSettings.topSigma = {
                        ...newSettings.topSigma,
                        baseCalculation: Number(sigmaSettings.top_pool_percent),
                    };
                }

                if (pinsData && pinsData.length > 0) {
                    newSettings.careerPlan.pins = pinsData.map((p: any) => ({
                        pin: p.pin_code, // Or display_name
                        cycles: p.cycles_required,
                        minLines: p.min_lines,
                        vmec: p.vmec_pattern,
                        bonus: Number(p.reward_value),
                        iconColor: PIN_COLORS[p.pin_code] || '#ffffff'
                    }));
                }

                if (depthData && depthData.length > 0) {
                    newSettings.depthBonus.levels = depthData.map((d: any) => ({
                        level: d.level,
                        percent: Number(d.percent),
                        value: Number(d.value_per_cycle)
                    }));
                }

                if (fidelityData && fidelityData.length > 0) {
                    newSettings.fidelityBonus.levels = fidelityData.map((f: any) => ({
                        level: f.level,
                        percent: Number(f.percent),
                        value: Number(f.value_per_cycle)
                    }));
                }

                if (topSigmaData && topSigmaData.length > 0) {
                    newSettings.topSigma.ranking = topSigmaData.map((t: any) => ({
                        position: t.rank,
                        percent: Number(t.percent_of_pool)
                    }));
                }

                setSettings(newSettings);

            } catch (err) {
                console.error("Erro ao carregar configurações do Supabase:", err);
                // Mantém defaultSettings em caso de erro
            } finally {
                setIsLoading(false);
            }
        };

        fetchAllSettings();
    }, []);

    const updateSettings = async (newSettings: Partial<GlobalSystemSettings>) => {
        // Optimistic update
        setSettings({ ...settings, ...newSettings });

        // Nota: A atualização completa das tabelas relacionais via frontend é complexa.
        // Aqui atualizaremos apenas o sigma_settings principal como exemplo.
        // Em produção, isso deve ser feito via API dedicada ou procedures.
        
        if (newSettings.matrixSigma || newSettings.careerPlan || newSettings.fidelityBonus || newSettings.topSigma) {
            try {
                const updatePayload: any = {};
                if (newSettings.matrixSigma) {
                    updatePayload.cycle_value = newSettings.matrixSigma.cycleValue;
                    updatePayload.cycle_payout_value = newSettings.matrixSigma.payoutValue;
                    updatePayload.cycle_payout_percent = newSettings.matrixSigma.payoutPercent;
                    updatePayload.reentry_limit_per_month = newSettings.matrixSigma.reentryLimit;
                }
                if (newSettings.careerPlan) {
                    updatePayload.career_percent = newSettings.careerPlan.bonusPercentage;
                }
                
                // Tenta atualizar se houver payload
                if (Object.keys(updatePayload).length > 0) {
                    // Update the first row, assuming single settings row pattern
                    // Primeiro pegamos o ID
                    const { data } = await supabase.from('sigma_settings').select('id').limit(1).single();
                    if (data?.id) {
                        await supabase.from('sigma_settings').update(updatePayload).eq('id', data.id);
                    }
                }
            } catch (err) {
                console.error("Erro ao salvar configurações no banco:", err);
                alert("Erro ao persistir algumas configurações. Verifique o console.");
            }
        }
    };

    return (
        <SystemSettingsContext.Provider value={{ settings, updateSettings, isLoading }}>
            {children}
        </SystemSettingsContext.Provider>
    );
};
