
import React, { createContext, useContext, useState } from 'react';

export type LayoutMode = 'default' | 'focus';

interface LayoutContextType {
  layoutMode: LayoutMode;
  setLayoutMode: (mode: LayoutMode) => void;
}

const LayoutContext = createContext<LayoutContextType>({ 
    layoutMode: 'default', 
    setLayoutMode: () => {} 
});

export const useLayout = () => useContext(LayoutContext);

export const LayoutProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [layoutMode, setLayoutMode] = useState<LayoutMode>('default');
    return (
        <LayoutContext.Provider value={{ layoutMode, setLayoutMode }}>
            {children}
        </LayoutContext.Provider>
    );
};
