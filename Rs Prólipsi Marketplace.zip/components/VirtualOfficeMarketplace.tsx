// This component is obsolete and has been replaced by StorefrontEditor.tsx
import React from 'react';

const VirtualOfficeMarketplace: React.FC = () => {
    return null;
};

export default VirtualOfficeMarketplace;
