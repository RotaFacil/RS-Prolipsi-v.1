

import React, { useState } from 'react';
import { UserProfile } from '../types';
import { ImageUploader } from './ImageUploader';

interface UserProfileEditorProps {
    userProfile: UserProfile;
    onSave: (updatedProfile: UserProfile) => void;
}

const UserProfileEditor: React.FC<UserProfileEditorProps> = ({ userProfile, onSave }) => {
    const [formData, setFormData] = useState<UserProfile>(userProfile);
    const hasChanges = JSON.stringify(formData) !== JSON.stringify(userProfile);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    
    const handleImageUpload = (url: string) => {
        setFormData(prev => ({ ...prev, avatarUrl: url }));
    };

    const handleSave = () => {
        onSave(formData);
    };

    const handleDiscard = () => {
        setFormData(userProfile);
    }
    
    const ReadOnlyField: React.FC<{ label: string; value: string }> = ({ label, value }) => (
        <div>
            <label className="block text-sm font-medium text-gray-400">{label}</label>
            <p className="mt-1 text-white p-2 bg-gray-800 rounded-md">{value}</p>
        </div>
    );

    return (
        <div className="space-y-6">
            <div className="pb-6 mb-6 flex justify-end items-center border-b border-gray-800">
                <div className="flex items-center gap-4">
                    {hasChanges && <p className="text-sm text-yellow-400">Você tem alterações não salvas.</p>}
                    <button onClick={handleDiscard} disabled={!hasChanges} className="text-sm font-semibold bg-gray-700 text-white py-2 px-4 rounded-md hover:bg-gray-600 disabled:opacity-50">Descartar</button>
                    <button onClick={handleSave} disabled={!hasChanges} className="text-sm font-bold bg-yellow-500 text-black py-2 px-4 rounded-md hover:bg-yellow-400 disabled:opacity-50">Salvar Perfil</button>
                </div>
            </div>
             <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1">
                    <div className="bg-black border border-gray-800 rounded-lg p-6 text-center">
                        <h3 className="text-lg font-semibold text-white mb-4">Foto de Perfil</h3>
                        <ImageUploader 
                            currentImage={formData.avatarUrl}
                            onImageUpload={handleImageUpload}
                            placeholderText="Alterar foto"
                            aspectRatio="square"
                        />
                    </div>
                </div>
                <div className="lg:col-span-2">
                    <div className="bg-black border border-gray-800 rounded-lg p-6 space-y-4">
                         <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="name" className="block text-sm font-medium text-gray-400 mb-1">Nome de Exibição</label>
                                <input id="name" name="name" type="text" value={formData.name} onChange={handleInputChange} className="w-full bg-gray-800 border-2 border-gray-700 rounded-md py-2 px-3 text-white" />
                            </div>
                            <div>
                                <label htmlFor="email" className="block text-sm font-medium text-gray-400 mb-1">E-mail</label>
                                <input id="email" name="email" type="email" value={formData.email} onChange={handleInputChange} className="w-full bg-gray-800 border-2 border-gray-700 rounded-md py-2 px-3 text-white" />
                            </div>
                             <div>
                                <label htmlFor="cpfCnpj" className="block text-sm font-medium text-gray-400 mb-1">CPF/CNPJ</label>
                                <input id="cpfCnpj" name="cpfCnpj" type="text" value={formData.cpfCnpj} onChange={handleInputChange} className="w-full bg-gray-800 border-2 border-gray-700 rounded-md py-2 px-3 text-white" />
                            </div>
                             <div>
                                <label htmlFor="phone" className="block text-sm font-medium text-gray-400 mb-1">Telefone</label>
                                <input id="phone" name="phone" type="tel" value={formData.phone} onChange={handleInputChange} className="w-full bg-gray-800 border-2 border-gray-700 rounded-md py-2 px-3 text-white" />
                            </div>
                         </div>
                         <ReadOnlyField label="ID" value={formData.id} />
                         <ReadOnlyField label="Graduação" value={formData.graduation} />
                         <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <ReadOnlyField label="Status da Conta" value={formData.accountStatus} />
                            <ReadOnlyField label="Atividade Mensal" value={formData.monthlyActivity} />
                         </div>
                         <ReadOnlyField label="Link de Indicação" value={formData.referralLink} />
                         <ReadOnlyField label="Link de Afiliado" value={formData.affiliateLink} />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default UserProfileEditor;