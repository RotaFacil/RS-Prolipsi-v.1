import React from 'react';

export const EloIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <></>
);