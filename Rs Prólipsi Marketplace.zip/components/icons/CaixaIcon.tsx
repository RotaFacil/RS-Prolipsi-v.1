import React from 'react';

export const CaixaIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <></>
);