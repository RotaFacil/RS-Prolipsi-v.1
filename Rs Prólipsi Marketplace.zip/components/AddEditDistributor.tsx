import React from 'react';
import { View } from '../types';

interface AddEditDistributorProps {
    onCancel: () => void;
}

const AddEditDistributor: React.FC<AddEditDistributorProps> = ({ onCancel }) => {
    return (
        <div className="bg-[rgb(var(--color-brand-dark))] border border-[rgb(var(--color-brand-gray-light))] rounded-lg p-6">
            <h2 className="text-xl font-bold text-[rgb(var(--color-brand-text-light))] mb-4">Adicionar/Editar Central de Distribuição</h2>
            <p className="text-[rgb(var(--color-brand-text-dim))]">O formulário para adicionar e editar CDs será implementado aqui.</p>
            <div className="mt-6">
                <button onClick={onCancel} className="text-sm font-semibold bg-[rgb(var(--color-brand-gray))] text-[rgb(var(--color-brand-text-light))] py-2 px-4 rounded-md hover:bg-[rgb(var(--color-brand-gray-light))]">
                    Voltar
                </button>
            </div>
        </div>
    );
};

export default AddEditDistributor;
