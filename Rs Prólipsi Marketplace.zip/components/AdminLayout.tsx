
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { View } from '../types';
import { DashboardIcon } from './icons/DashboardIcon';
import { StorefrontIcon } from './icons/StorefrontIcon';
import { MegaphoneIcon } from './icons/MegaphoneIcon';
import { PaletteIcon } from './icons/PaletteIcon';
import { WalletIcon } from './icons/WalletIcon';
import { ChatBubbleLeftRightIcon } from './icons/ChatBubbleLeftRightIcon';
import { BellIcon } from './icons/BellIcon';
import { UserIcon } from './icons/UserIcon';
import { SparklesIcon } from './icons/SparklesIcon';
import { Cog6ToothIcon } from './icons/Cog6ToothIcon';
import { ChevronDoubleLeftIcon } from './icons/ChevronDoubleLeftIcon';
import { MenuIcon } from './icons/MenuIcon';
import { CloseIcon } from './icons/CloseIcon';
import { DocumentTextIcon } from './icons/DocumentTextIcon';
import { ArrowTopRightOnSquareIcon } from './icons/ArrowTopRightOnSquareIcon';
import { BuildingStorefrontIcon } from './icons/BuildingStorefrontIcon';
import { LogoutIcon } from './icons/LogoutIcon';


interface AdminLayoutProps {
    title?: string;
    children: React.ReactNode;
    currentView: View;
    onNavigate: (view: View, data?: any) => void;
    onLogout: () => void;
}

const navGroups = [
  {
    main: { icon: DashboardIcon, label: "Dashboard", view: "consultantStore" as View }
  },
  {
    main: { icon: SparklesIcon, label: "RS Studio", view: "rsStudio" as View }
  },
  {
    main: { icon: ChatBubbleLeftRightIcon, label: "Comunicação", view: "communication" as View }
  },
  { isSeparator: true, title: "GERENCIAR" },
  { 
    main: { icon: StorefrontIcon, label: "Minha Loja", view: "manageProducts" as View },
    subLinks: [
        { label: 'Produtos', view: 'manageProducts' as View },
        { label: 'Coleções', view: 'manageCollections' as View },
        { label: 'Pedidos', view: 'manageOrders' as View },
        { label: 'Cupons', view: 'managePromotions' as View},
        { label: 'Order Bump', view: 'manageOrderBump' as View },
        { label: 'Upsell', view: 'manageUpsell' as View },
        { label: 'Carrinhos Abandonados', view: 'manageAbandonedCarts' as View },
        { label: 'Avaliações', view: 'manageReviews' as View },
        { label: 'Afiliados', view: 'manageAffiliates' as View },
    ]
  },
  {
    main: { icon: WalletIcon, label: "Wallet Pay", view: "walletOverview" as View },
    subLinks: [
        { label: 'Visão Geral', view: 'walletOverview' as View },
        { label: 'Extrato e Relatórios', view: 'walletReports' as View },
        { label: 'Transferências', view: 'walletTransfers' as View },
        { label: 'Cobranças', view: 'walletCharges' as View },
        { label: 'Configurações', view: 'walletSettings' as View },
    ]
  },
  { 
    main: { icon: BuildingStorefrontIcon, label: "CDs", view: "manageDistributors" as View }
  },
  {
    main: { icon: MegaphoneIcon, label: "Marketing", view: "virtualOfficePixels" as View },
    subLinks: [
        { label: 'Pixels de Marketing', view: 'virtualOfficePixels' as View },
        { label: 'Encurtador de Links', view: 'virtualOfficeLinkShortener' as View },
    ]
  },
  { isSeparator: true, title: "APARÊNCIA" },
  {
    main: { icon: PaletteIcon, label: "Personalização", view: "storeEditor" as View },
    subLinks: [
        { label: 'Meu Perfil', view: 'userProfileEditor' as View},
        { label: 'Aparência da Loja', view: 'storeEditor' as View },
        { label: 'Editor do Painel', view: 'dashboardEditor' as View },
        { label: 'Banners do Painel', view: 'bannerDashboard' as View },
    ]
  },
  {
    main: { icon: DocumentTextIcon, label: "Conteúdo e Mídia", view: "manageAnnouncements" as View },
    subLinks: [
      { label: 'Comunicados', view: 'manageAnnouncements' as View },
      { label: 'Treinamentos', view: 'manageTrainings' as View },
      { label: 'Materiais de Marketing', view: 'manageMarketingAssets' as View },
    ]
  },
  {
    main: { icon: Cog6ToothIcon, label: "Configurações", view: "managePayments" as View },
    subLinks: [
        { label: 'Plano de Compensação', view: 'compensationPlan' as View },
        { label: 'Pagamentos', view: 'managePayments' as View },
        { label: 'Frete', view: 'manageShipping' as View },
    ]
  }
];

const NavItem: React.FC<{
    item: { main: { icon: React.ElementType; label: string; view: View; }, subLinks?: { label: string; view: View; }[] };
    isCollapsed: boolean;
    currentView: View;
    onNavigate: (view: View) => void;
}> = ({ item, isCollapsed, currentView, onNavigate }) => {
    const { main, subLinks } = item;
    const isActive = currentView === main.view || (subLinks && subLinks.some(s => s.view === currentView));
    const [isSubMenuOpen, setIsSubMenuOpen] = useState(isActive);
    const [isPopoverOpen, setIsPopoverOpen] = useState(false);
    const navItemRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (!isActive && !isCollapsed) {
            setIsSubMenuOpen(false);
        }
    }, [isActive, isCollapsed]);
    
    useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
        if (isCollapsed && navItemRef.current && !navItemRef.current.contains(event.target as Node)) {
          setIsPopoverOpen(false);
        }
      };
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }, [isCollapsed]);
    

    const handleMainClick = () => {
        if (isCollapsed) {
            if (subLinks) {
                setIsPopoverOpen(p => !p);
            } else {
                onNavigate(main.view);
            }
        } else {
            if (subLinks) {
                setIsSubMenuOpen(p => !p);
            } else {
                onNavigate(main.view);
            }
        }
    };

    const baseClasses = "w-full flex items-center justify-between text-left px-3 rounded-md text-sm font-medium transition-all duration-200 h-11 relative group";
    const activeClasses = "bg-[rgb(var(--color-brand-gold))]/10 text-white";
    const inactiveClasses = "text-[rgb(var(--color-brand-text-dim))] hover:bg-[rgb(var(--color-brand-gray-light))] hover:text-white";

    return (
        <div ref={navItemRef}>
            <button onClick={handleMainClick} className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses}`}>
                <div className="flex items-center gap-3">
                    <main.icon className={`h-6 w-6 flex-shrink-0 transition-colors ${isActive ? 'text-[rgb(var(--color-brand-gold))]' : ''}`} />
                    {!isCollapsed && <span className="truncate">{main.label}</span>}
                </div>
                {!isCollapsed && subLinks && (
                    <span className={`transform transition-transform text-xs ${isSubMenuOpen ? 'rotate-180' : ''}`}>▼</span>
                )}
                {isActive && <div className="absolute left-0 top-1/2 -translate-y-1/2 h-6 w-1 bg-[rgb(var(--color-brand-gold))] rounded-r-full"></div>}
                {isCollapsed && (
                    <div className="absolute left-full ml-3 px-3 py-1.5 bg-[rgb(var(--color-brand-gray))] text-white text-xs font-bold rounded-md whitespace-nowrap opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity delay-300 z-50">
                        {main.label}
                    </div>
                )}
            </button>
            
            {/* Expanded Submenu */}
            {!isCollapsed && isSubMenuOpen && subLinks && (
                <div className="pl-8 pt-2 space-y-1">
                    {subLinks.map(sub => (
                        <button key={sub.view} onClick={() => onNavigate(sub.view)}
                            className={`w-full text-left pl-5 pr-2 py-2 rounded-md text-sm transition-colors relative ${currentView === sub.view ? 'text-white font-semibold' : 'text-[rgb(var(--color-brand-text-dim))] hover:bg-[rgb(var(--color-brand-gray-light))]'}`}>
                            {currentView === sub.view && <div className="absolute left-0 top-1/2 -translate-y-1/2 h-1.5 w-1.5 bg-[rgb(var(--color-brand-gold))] rounded-full"></div>}
                            {sub.label}
                        </button>
                    ))}
                </div>
            )}
            
            {/* Collapsed Popover Submenu */}
            {isCollapsed && isPopoverOpen && subLinks && (
                 <div className="absolute left-full top-0 ml-2 z-50 w-56 bg-[rgba(30,30,30,0.8)] backdrop-blur-md border border-[rgb(var(--color-brand-gold))]/20 rounded-lg shadow-2xl p-2 animate-fade-in-fast">
                     {subLinks.map(sub => (
                        <button key={sub.view} onClick={() => onNavigate(sub.view)}
                            className={`w-full text-left px-3 py-2 text-sm rounded-md transition-colors ${currentView === sub.view ? 'text-[rgb(var(--color-brand-gold))] font-semibold bg-[rgb(var(--color-brand-gray))]' : 'text-white hover:bg-[rgb(var(--color-brand-gray))]'}`}>
                            {sub.label}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
};

export const AdminLayout: React.FC<AdminLayoutProps> = ({ title, children, currentView, onNavigate, onLogout }) => {
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

    return (
        <div className="flex h-screen bg-[rgb(var(--color-brand-dark))] text-[rgb(var(--color-brand-text-light))]">
            <style>{`
                @keyframes fade-in-fast { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
                .animate-fade-in-fast { animation: fade-in-fast 0.15s ease-out forwards; }
            `}</style>
            
            {/* Overlay for mobile */}
            <div className={`fixed inset-0 bg-black/60 z-30 lg:hidden transition-opacity ${isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={() => setIsMobileMenuOpen(false)}></div>

            {/* Sidebar */}
            <aside className={`fixed lg:relative inset-y-0 left-0 z-40 bg-[rgba(18,18,18,0.6)] backdrop-blur-lg flex-shrink-0 p-3 flex flex-col transition-all duration-300
                ${isMobileMenuOpen ? 'translate-x-0 w-72' : '-translate-x-full w-72'}
                ${isSidebarOpen && !isMobileMenuOpen ? 'w-72' : 'w-20'} lg:translate-x-0 border-r border-[rgb(var(--color-brand-gold))]/15`}>
                
                <div className="flex items-center justify-center h-16 px-3 mb-6 flex-shrink-0">
                    <span className={`font-display text-[rgb(var(--color-brand-gold))] transition-all duration-300 ${isSidebarOpen ? 'text-3xl' : 'text-2xl'}`}>
                        {isSidebarOpen ? 'RS Prólipsi' : 'RS'}
                    </span>
                </div>
                
                <nav className="flex-grow space-y-1 overflow-y-auto pr-1">
                    {navGroups.map((group, index) => {
                        // FIX: Use `in` operator for type guarding. `isSeparator` is not present on all types in the union,
                        // so checking for property existence is a more robust way to narrow the type.
                        if ('isSeparator' in group) {
                            return (
                                <div key={index} className={`pt-4 pb-2 px-3 transition-opacity duration-300 ${isSidebarOpen ? 'opacity-100' : 'opacity-0 h-0 pointer-events-none'}`}>
                                    <p className="text-xs font-bold text-[rgb(var(--color-brand-text-dim))] uppercase tracking-wider">{group.title}</p>
                                </div>
                            );
                        }
                        else {
                            return <NavItem key={index} item={group} isCollapsed={!isSidebarOpen} currentView={currentView} onNavigate={onNavigate} />;
                        }
                    })}
                </nav>

                <div className="flex-shrink-0 mt-auto pt-4 space-y-2">
                    <button onClick={onLogout} className={`w-full flex items-center gap-3 px-3 py-3 rounded-md text-sm font-medium text-[rgb(var(--color-brand-text-dim))] hover:bg-[rgb(var(--color-brand-gray-light))] hover:text-white ${!isSidebarOpen ? 'justify-center': ''}`}>
                        <LogoutIcon className="h-6 w-6"/>
                        {!isSidebarOpen || <span className="truncate">Sair</span>}
                    </button>
                    <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="w-full hidden lg:flex items-center gap-3 px-3 py-3 rounded-md text-sm font-medium text-[rgb(var(--color-brand-text-dim))] hover:bg-[rgb(var(--color-brand-gray-light))] hover:text-white">
                        <ChevronDoubleLeftIcon className={`h-6 w-6 transition-transform ${isSidebarOpen ? '' : 'rotate-180'}`}/>
                        {!isSidebarOpen || <span className="truncate">Recolher</span>}
                    </button>
                </div>
            </aside>
            
            {/* Main Content */}
            <div className="flex-1 flex flex-col overflow-hidden">
                <header className="flex-shrink-0 h-20 flex items-center justify-between px-6 bg-[rgb(var(--color-brand-dark))] border-b border-[rgb(var(--color-brand-gray-light))]">
                    <div className="flex items-center gap-4">
                        <button onClick={() => setIsMobileMenuOpen(true)} className="lg:hidden"> <MenuIcon className="w-6 h-6"/> </button>
                        <h1 className="text-xl md:text-2xl font-bold text-white">{title || 'Painel'}</h1>
                    </div>
                    <div className="flex items-center gap-4">
                        <button onClick={() => onNavigate('home')} className="flex items-center gap-2 text-sm font-semibold bg-[rgb(var(--color-brand-gray))] text-white py-2 px-4 rounded-md hover:bg-[rgb(var(--color-brand-gray-light))]">
                            <ArrowTopRightOnSquareIcon className="w-5 h-5" />
                            <span className="hidden sm:inline">Ver Loja</span>
                        </button>
                        <button className="relative text-[rgb(var(--color-brand-text-dim))] hover:text-white">
                            <BellIcon className="w-6 h-6" />
                            <span className="absolute -top-1 -right-1 bg-red-500 text-white w-3 h-3 rounded-full text-xs"></span>
                        </button>
                        <button onClick={()=>onNavigate('userProfileEditor')}><UserIcon className="w-8 h-8 p-1 rounded-full bg-[rgb(var(--color-brand-gray))]"/></button>
                    </div>
                </header>
                <main className="flex-1 overflow-y-auto p-6">
                    {children}
                </main>
            </div>
        </div>
    );
};
